--
-- PostgreSQL database dump
--

-- Dumped from database version 12.4
-- Dumped by pg_dump version 12.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_address (
    id integer NOT NULL,
    first_name character varying(256) NOT NULL,
    last_name character varying(256) NOT NULL,
    company_name character varying(256) NOT NULL,
    street_address_1 character varying(256) NOT NULL,
    street_address_2 character varying(256) NOT NULL,
    city character varying(256) NOT NULL,
    postal_code character varying(20) NOT NULL,
    country character varying(2) NOT NULL,
    country_area character varying(128) NOT NULL,
    phone character varying(128) NOT NULL,
    city_area character varying(128) NOT NULL
);


ALTER TABLE public.account_address OWNER TO postgres;

--
-- Name: account_customerevent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_customerevent (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    type character varying(255) NOT NULL,
    parameters jsonb NOT NULL,
    order_id integer,
    user_id integer NOT NULL
);


ALTER TABLE public.account_customerevent OWNER TO postgres;

--
-- Name: account_customerevent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_customerevent_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_customerevent_id_seq OWNER TO postgres;

--
-- Name: account_customerevent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_customerevent_id_seq OWNED BY public.account_customerevent.id;


--
-- Name: account_customernote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_customernote (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    content text NOT NULL,
    is_public boolean NOT NULL,
    customer_id integer NOT NULL,
    user_id integer
);


ALTER TABLE public.account_customernote OWNER TO postgres;

--
-- Name: account_customernote_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_customernote_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_customernote_id_seq OWNER TO postgres;

--
-- Name: account_customernote_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_customernote_id_seq OWNED BY public.account_customernote.id;


--
-- Name: account_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_user (
    id integer NOT NULL,
    is_superuser boolean NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    password character varying(128) NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    last_login timestamp with time zone,
    default_billing_address_id integer,
    default_shipping_address_id integer,
    note text,
    token uuid NOT NULL,
    first_name character varying(256) NOT NULL,
    last_name character varying(256) NOT NULL,
    avatar character varying(100),
    private_meta jsonb NOT NULL,
    is_vendor boolean NOT NULL,
    is_supplier boolean NOT NULL,
    jwt_secret uuid NOT NULL,
    activation_token uuid NOT NULL,
    activation_token_has_been_used boolean NOT NULL,
    request_for_reactivation boolean NOT NULL
);


ALTER TABLE public.account_user OWNER TO postgres;

--
-- Name: account_user_addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_user_addresses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    address_id integer NOT NULL
);


ALTER TABLE public.account_user_addresses OWNER TO postgres;

--
-- Name: account_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.account_user_groups OWNER TO postgres;

--
-- Name: account_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.account_user_user_permissions OWNER TO postgres;

--
-- Name: account_userproducts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_userproducts (
    id integer NOT NULL,
    product_id integer,
    user_id integer
);


ALTER TABLE public.account_userproducts OWNER TO postgres;

--
-- Name: account_userproducts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_userproducts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_userproducts_id_seq OWNER TO postgres;

--
-- Name: account_userproducts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_userproducts_id_seq OWNED BY public.account_userproducts.id;


--
-- Name: account_userrequestform; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_userrequestform (
    id integer NOT NULL,
    request_type character varying(8) NOT NULL,
    request_fullfilled boolean NOT NULL,
    user_id integer
);


ALTER TABLE public.account_userrequestform OWNER TO postgres;

--
-- Name: account_userrequestform_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_userrequestform_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_userrequestform_id_seq OWNER TO postgres;

--
-- Name: account_userrequestform_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_userrequestform_id_seq OWNED BY public.account_userrequestform.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO postgres;

--
-- Name: checkout_checkoutline; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.checkout_checkoutline (
    id integer NOT NULL,
    quantity integer NOT NULL,
    checkout_id uuid NOT NULL,
    variant_id integer NOT NULL,
    data jsonb NOT NULL,
    CONSTRAINT cart_cartline_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.checkout_checkoutline OWNER TO postgres;

--
-- Name: cart_cartline_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cart_cartline_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cart_cartline_id_seq OWNER TO postgres;

--
-- Name: cart_cartline_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cart_cartline_id_seq OWNED BY public.checkout_checkoutline.id;


--
-- Name: checkout_checkout; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.checkout_checkout (
    created timestamp with time zone NOT NULL,
    last_change timestamp with time zone NOT NULL,
    email character varying(254) NOT NULL,
    token uuid NOT NULL,
    quantity integer NOT NULL,
    user_id integer,
    billing_address_id integer,
    discount_amount numeric(12,2) NOT NULL,
    discount_name character varying(255),
    note text NOT NULL,
    shipping_address_id integer,
    shipping_method_id integer,
    voucher_code character varying(12),
    translated_discount_name character varying(255),
    CONSTRAINT cart_cart_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.checkout_checkout OWNER TO postgres;

--
-- Name: checkout_checkout_gift_cards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.checkout_checkout_gift_cards (
    id integer NOT NULL,
    checkout_id uuid NOT NULL,
    giftcard_id integer NOT NULL
);


ALTER TABLE public.checkout_checkout_gift_cards OWNER TO postgres;

--
-- Name: checkout_checkout_gift_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.checkout_checkout_gift_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.checkout_checkout_gift_cards_id_seq OWNER TO postgres;

--
-- Name: checkout_checkout_gift_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.checkout_checkout_gift_cards_id_seq OWNED BY public.checkout_checkout_gift_cards.id;


--
-- Name: discount_sale; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discount_sale (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(10) NOT NULL,
    value numeric(12,2) NOT NULL,
    end_date timestamp with time zone,
    start_date timestamp with time zone NOT NULL
);


ALTER TABLE public.discount_sale OWNER TO postgres;

--
-- Name: discount_sale_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discount_sale_categories (
    id integer NOT NULL,
    sale_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.discount_sale_categories OWNER TO postgres;

--
-- Name: discount_sale_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_sale_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discount_sale_categories_id_seq OWNER TO postgres;

--
-- Name: discount_sale_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discount_sale_categories_id_seq OWNED BY public.discount_sale_categories.id;


--
-- Name: discount_sale_collections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discount_sale_collections (
    id integer NOT NULL,
    sale_id integer NOT NULL,
    collection_id integer NOT NULL
);


ALTER TABLE public.discount_sale_collections OWNER TO postgres;

--
-- Name: discount_sale_collections_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_sale_collections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discount_sale_collections_id_seq OWNER TO postgres;

--
-- Name: discount_sale_collections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discount_sale_collections_id_seq OWNED BY public.discount_sale_collections.id;


--
-- Name: discount_sale_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_sale_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discount_sale_id_seq OWNER TO postgres;

--
-- Name: discount_sale_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discount_sale_id_seq OWNED BY public.discount_sale.id;


--
-- Name: discount_sale_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discount_sale_products (
    id integer NOT NULL,
    sale_id integer NOT NULL,
    product_id integer NOT NULL
);


ALTER TABLE public.discount_sale_products OWNER TO postgres;

--
-- Name: discount_sale_products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_sale_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discount_sale_products_id_seq OWNER TO postgres;

--
-- Name: discount_sale_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discount_sale_products_id_seq OWNED BY public.discount_sale_products.id;


--
-- Name: discount_saletranslation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discount_saletranslation (
    id integer NOT NULL,
    language_code character varying(10) NOT NULL,
    name character varying(255),
    sale_id integer NOT NULL
);


ALTER TABLE public.discount_saletranslation OWNER TO postgres;

--
-- Name: discount_saletranslation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_saletranslation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discount_saletranslation_id_seq OWNER TO postgres;

--
-- Name: discount_saletranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discount_saletranslation_id_seq OWNED BY public.discount_saletranslation.id;


--
-- Name: discount_voucher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discount_voucher (
    id integer NOT NULL,
    type character varying(20) NOT NULL,
    name character varying(255),
    code character varying(12) NOT NULL,
    usage_limit integer,
    used integer NOT NULL,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone,
    discount_value_type character varying(10) NOT NULL,
    discount_value numeric(12,2) NOT NULL,
    min_amount_spent numeric(12,2),
    apply_once_per_order boolean NOT NULL,
    countries character varying(749) NOT NULL,
    min_checkout_items_quantity integer,
    CONSTRAINT discount_voucher_min_checkout_items_quantity_check CHECK ((min_checkout_items_quantity >= 0)),
    CONSTRAINT discount_voucher_usage_limit_check CHECK ((usage_limit >= 0)),
    CONSTRAINT discount_voucher_used_check CHECK ((used >= 0))
);


ALTER TABLE public.discount_voucher OWNER TO postgres;

--
-- Name: discount_voucher_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discount_voucher_categories (
    id integer NOT NULL,
    voucher_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.discount_voucher_categories OWNER TO postgres;

--
-- Name: discount_voucher_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_voucher_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discount_voucher_categories_id_seq OWNER TO postgres;

--
-- Name: discount_voucher_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discount_voucher_categories_id_seq OWNED BY public.discount_voucher_categories.id;


--
-- Name: discount_voucher_collections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discount_voucher_collections (
    id integer NOT NULL,
    voucher_id integer NOT NULL,
    collection_id integer NOT NULL
);


ALTER TABLE public.discount_voucher_collections OWNER TO postgres;

--
-- Name: discount_voucher_collections_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_voucher_collections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discount_voucher_collections_id_seq OWNER TO postgres;

--
-- Name: discount_voucher_collections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discount_voucher_collections_id_seq OWNED BY public.discount_voucher_collections.id;


--
-- Name: discount_voucher_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_voucher_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discount_voucher_id_seq OWNER TO postgres;

--
-- Name: discount_voucher_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discount_voucher_id_seq OWNED BY public.discount_voucher.id;


--
-- Name: discount_voucher_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discount_voucher_products (
    id integer NOT NULL,
    voucher_id integer NOT NULL,
    product_id integer NOT NULL
);


ALTER TABLE public.discount_voucher_products OWNER TO postgres;

--
-- Name: discount_voucher_products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_voucher_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discount_voucher_products_id_seq OWNER TO postgres;

--
-- Name: discount_voucher_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discount_voucher_products_id_seq OWNED BY public.discount_voucher_products.id;


--
-- Name: discount_vouchertranslation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discount_vouchertranslation (
    id integer NOT NULL,
    language_code character varying(10) NOT NULL,
    name character varying(255),
    voucher_id integer NOT NULL
);


ALTER TABLE public.discount_vouchertranslation OWNER TO postgres;

--
-- Name: discount_vouchertranslation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_vouchertranslation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discount_vouchertranslation_id_seq OWNER TO postgres;

--
-- Name: discount_vouchertranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discount_vouchertranslation_id_seq OWNED BY public.discount_vouchertranslation.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: drupphuser1
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO drupphuser1;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: drupphuser1
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO drupphuser1;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drupphuser1
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_prices_openexchangerates_conversionrate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_prices_openexchangerates_conversionrate (
    id integer NOT NULL,
    to_currency character varying(3) NOT NULL,
    rate numeric(20,12) NOT NULL,
    modified_at timestamp with time zone NOT NULL
);


ALTER TABLE public.django_prices_openexchangerates_conversionrate OWNER TO postgres;

--
-- Name: django_prices_openexchangerates_conversionrate_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_prices_openexchangerates_conversionrate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_prices_openexchangerates_conversionrate_id_seq OWNER TO postgres;

--
-- Name: django_prices_openexchangerates_conversionrate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_prices_openexchangerates_conversionrate_id_seq OWNED BY public.django_prices_openexchangerates_conversionrate.id;


--
-- Name: django_prices_vatlayer_ratetypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_prices_vatlayer_ratetypes (
    id integer NOT NULL,
    types text NOT NULL
);


ALTER TABLE public.django_prices_vatlayer_ratetypes OWNER TO postgres;

--
-- Name: django_prices_vatlayer_ratetypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_prices_vatlayer_ratetypes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_prices_vatlayer_ratetypes_id_seq OWNER TO postgres;

--
-- Name: django_prices_vatlayer_ratetypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_prices_vatlayer_ratetypes_id_seq OWNED BY public.django_prices_vatlayer_ratetypes.id;


--
-- Name: django_prices_vatlayer_vat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_prices_vatlayer_vat (
    id integer NOT NULL,
    country_code character varying(2) NOT NULL,
    data text NOT NULL
);


ALTER TABLE public.django_prices_vatlayer_vat OWNER TO postgres;

--
-- Name: django_prices_vatlayer_vat_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_prices_vatlayer_vat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_prices_vatlayer_vat_id_seq OWNER TO postgres;

--
-- Name: django_prices_vatlayer_vat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_prices_vatlayer_vat_id_seq OWNED BY public.django_prices_vatlayer_vat.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: drupphuser1
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO drupphuser1;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: drupphuser1
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO drupphuser1;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drupphuser1
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: giftcard_giftcard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.giftcard_giftcard (
    id integer NOT NULL,
    code character varying(16) NOT NULL,
    created timestamp with time zone NOT NULL,
    start_date date NOT NULL,
    end_date date,
    last_used_on timestamp with time zone,
    is_active boolean NOT NULL,
    initial_balance numeric(12,2) NOT NULL,
    current_balance numeric(12,2) NOT NULL,
    user_id integer
);


ALTER TABLE public.giftcard_giftcard OWNER TO postgres;

--
-- Name: giftcard_giftcard_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.giftcard_giftcard_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.giftcard_giftcard_id_seq OWNER TO postgres;

--
-- Name: giftcard_giftcard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.giftcard_giftcard_id_seq OWNED BY public.giftcard_giftcard.id;


--
-- Name: impersonate_impersonationlog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.impersonate_impersonationlog (
    id integer NOT NULL,
    session_key character varying(40) NOT NULL,
    session_started_at timestamp with time zone,
    session_ended_at timestamp with time zone,
    impersonating_id integer NOT NULL,
    impersonator_id integer NOT NULL
);


ALTER TABLE public.impersonate_impersonationlog OWNER TO postgres;

--
-- Name: impersonate_impersonationlog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.impersonate_impersonationlog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.impersonate_impersonationlog_id_seq OWNER TO postgres;

--
-- Name: impersonate_impersonationlog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.impersonate_impersonationlog_id_seq OWNED BY public.impersonate_impersonationlog.id;


--
-- Name: menu_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_menu (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    json_content jsonb NOT NULL
);


ALTER TABLE public.menu_menu OWNER TO postgres;

--
-- Name: menu_menu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_menu_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_menu_id_seq OWNER TO postgres;

--
-- Name: menu_menu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_menu_id_seq OWNED BY public.menu_menu.id;


--
-- Name: menu_menuitem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_menuitem (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    sort_order integer,
    url character varying(256),
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    category_id integer,
    collection_id integer,
    menu_id integer NOT NULL,
    page_id integer,
    parent_id integer,
    CONSTRAINT menu_menuitem_level_check CHECK ((level >= 0)),
    CONSTRAINT menu_menuitem_lft_check CHECK ((lft >= 0)),
    CONSTRAINT menu_menuitem_rght_check CHECK ((rght >= 0)),
    CONSTRAINT menu_menuitem_sort_order_check CHECK ((sort_order >= 0)),
    CONSTRAINT menu_menuitem_tree_id_check CHECK ((tree_id >= 0))
);


ALTER TABLE public.menu_menuitem OWNER TO postgres;

--
-- Name: menu_menuitem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_menuitem_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_menuitem_id_seq OWNER TO postgres;

--
-- Name: menu_menuitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_menuitem_id_seq OWNED BY public.menu_menuitem.id;


--
-- Name: menu_menuitemtranslation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_menuitemtranslation (
    id integer NOT NULL,
    language_code character varying(10) NOT NULL,
    name character varying(128) NOT NULL,
    menu_item_id integer NOT NULL
);


ALTER TABLE public.menu_menuitemtranslation OWNER TO postgres;

--
-- Name: menu_menuitemtranslation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_menuitemtranslation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_menuitemtranslation_id_seq OWNER TO postgres;

--
-- Name: menu_menuitemtranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_menuitemtranslation_id_seq OWNED BY public.menu_menuitemtranslation.id;


--
-- Name: order_fulfillment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_fulfillment (
    id integer NOT NULL,
    tracking_number character varying(255) NOT NULL,
    shipping_date timestamp with time zone NOT NULL,
    order_id integer NOT NULL,
    fulfillment_order integer NOT NULL,
    status character varying(32) NOT NULL,
    CONSTRAINT order_fulfillment_fulfillment_order_check CHECK ((fulfillment_order >= 0))
);


ALTER TABLE public.order_fulfillment OWNER TO postgres;

--
-- Name: order_fulfillment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_fulfillment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_fulfillment_id_seq OWNER TO postgres;

--
-- Name: order_fulfillment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_fulfillment_id_seq OWNED BY public.order_fulfillment.id;


--
-- Name: order_fulfillmentline; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_fulfillmentline (
    id integer NOT NULL,
    order_line_id integer NOT NULL,
    quantity integer NOT NULL,
    fulfillment_id integer NOT NULL,
    CONSTRAINT order_fulfillmentline_quantity_81b787d3_check CHECK ((quantity >= 0))
);


ALTER TABLE public.order_fulfillmentline OWNER TO postgres;

--
-- Name: order_fulfillmentline_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_fulfillmentline_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_fulfillmentline_id_seq OWNER TO postgres;

--
-- Name: order_fulfillmentline_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_fulfillmentline_id_seq OWNED BY public.order_fulfillmentline.id;


--
-- Name: order_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_order (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    tracking_client_id character varying(36) NOT NULL,
    user_email character varying(254) NOT NULL,
    token character varying(36) NOT NULL,
    billing_address_id integer,
    shipping_address_id integer,
    user_id integer,
    total_net numeric(12,2) NOT NULL,
    discount_amount numeric(12,2) NOT NULL,
    discount_name character varying(255) NOT NULL,
    voucher_id integer,
    language_code character varying(35) NOT NULL,
    shipping_price_gross numeric(12,2) NOT NULL,
    total_gross numeric(12,2) NOT NULL,
    shipping_price_net numeric(12,2) NOT NULL,
    status character varying(32) NOT NULL,
    shipping_method_name character varying(255),
    shipping_method_id integer,
    display_gross_prices boolean NOT NULL,
    translated_discount_name character varying(255) NOT NULL,
    customer_note text NOT NULL,
    weight double precision NOT NULL,
    checkout_token character varying(36) NOT NULL,
    pickup_datetime timestamp with time zone NOT NULL
);


ALTER TABLE public.order_order OWNER TO postgres;

--
-- Name: order_order_gift_cards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_order_gift_cards (
    id integer NOT NULL,
    order_id integer NOT NULL,
    giftcard_id integer NOT NULL
);


ALTER TABLE public.order_order_gift_cards OWNER TO postgres;

--
-- Name: order_order_gift_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_order_gift_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_order_gift_cards_id_seq OWNER TO postgres;

--
-- Name: order_order_gift_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_order_gift_cards_id_seq OWNED BY public.order_order_gift_cards.id;


--
-- Name: order_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_order_id_seq OWNER TO postgres;

--
-- Name: order_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_order_id_seq OWNED BY public.order_order.id;


--
-- Name: order_orderline; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_orderline (
    id integer NOT NULL,
    product_name character varying(386) NOT NULL,
    product_sku character varying(32) NOT NULL,
    quantity integer NOT NULL,
    unit_price_net numeric(12,2) NOT NULL,
    unit_price_gross numeric(12,2) NOT NULL,
    is_shipping_required boolean NOT NULL,
    order_id integer NOT NULL,
    quantity_fulfilled integer NOT NULL,
    variant_id integer,
    tax_rate numeric(5,2) NOT NULL,
    translated_product_name character varying(386) NOT NULL
);


ALTER TABLE public.order_orderline OWNER TO postgres;

--
-- Name: order_ordereditem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_ordereditem_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_ordereditem_id_seq OWNER TO postgres;

--
-- Name: order_ordereditem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_ordereditem_id_seq OWNED BY public.order_orderline.id;


--
-- Name: order_orderevent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_orderevent (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    type character varying(255) NOT NULL,
    order_id integer NOT NULL,
    user_id integer,
    parameters jsonb NOT NULL,
    additional_note text NOT NULL
);


ALTER TABLE public.order_orderevent OWNER TO postgres;

--
-- Name: order_orderevent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_orderevent_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_orderevent_id_seq OWNER TO postgres;

--
-- Name: order_orderevent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_orderevent_id_seq OWNED BY public.order_orderevent.id;


--
-- Name: page_page; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.page_page (
    id integer NOT NULL,
    slug character varying(100) NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    created timestamp with time zone NOT NULL,
    is_published boolean NOT NULL,
    publication_date date,
    seo_description character varying(300),
    seo_title character varying(70),
    content_json jsonb NOT NULL
);


ALTER TABLE public.page_page OWNER TO postgres;

--
-- Name: page_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.page_page_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.page_page_id_seq OWNER TO postgres;

--
-- Name: page_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.page_page_id_seq OWNED BY public.page_page.id;


--
-- Name: page_pagetranslation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.page_pagetranslation (
    id integer NOT NULL,
    seo_title character varying(70),
    seo_description character varying(300),
    language_code character varying(10) NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    page_id integer NOT NULL,
    content_json jsonb NOT NULL
);


ALTER TABLE public.page_pagetranslation OWNER TO postgres;

--
-- Name: page_pagetranslation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.page_pagetranslation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.page_pagetranslation_id_seq OWNER TO postgres;

--
-- Name: page_pagetranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.page_pagetranslation_id_seq OWNED BY public.page_pagetranslation.id;


--
-- Name: payment_payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_payment (
    id integer NOT NULL,
    gateway character varying(255) NOT NULL,
    is_active boolean NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    charge_status character varying(20) NOT NULL,
    billing_first_name character varying(256) NOT NULL,
    billing_last_name character varying(256) NOT NULL,
    billing_company_name character varying(256) NOT NULL,
    billing_address_1 character varying(256) NOT NULL,
    billing_address_2 character varying(256) NOT NULL,
    billing_city character varying(256) NOT NULL,
    billing_city_area character varying(128) NOT NULL,
    billing_postal_code character varying(256) NOT NULL,
    billing_country_code character varying(2) NOT NULL,
    billing_country_area character varying(256) NOT NULL,
    billing_email character varying(254) NOT NULL,
    customer_ip_address inet,
    cc_brand character varying(40) NOT NULL,
    cc_exp_month integer,
    cc_exp_year integer,
    cc_first_digits character varying(6) NOT NULL,
    cc_last_digits character varying(4) NOT NULL,
    extra_data text NOT NULL,
    token character varying(128) NOT NULL,
    currency character varying(10) NOT NULL,
    total numeric(12,2) NOT NULL,
    captured_amount numeric(12,2) NOT NULL,
    checkout_id uuid,
    order_id integer,
    CONSTRAINT payment_paymentmethod_cc_exp_month_check CHECK ((cc_exp_month >= 0)),
    CONSTRAINT payment_paymentmethod_cc_exp_year_check CHECK ((cc_exp_year >= 0))
);


ALTER TABLE public.payment_payment OWNER TO postgres;

--
-- Name: payment_paymentmethod_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_paymentmethod_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_paymentmethod_id_seq OWNER TO postgres;

--
-- Name: payment_paymentmethod_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_paymentmethod_id_seq OWNED BY public.payment_payment.id;


--
-- Name: payment_transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_transaction (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    token character varying(128) NOT NULL,
    kind character varying(10) NOT NULL,
    is_success boolean NOT NULL,
    error character varying(256),
    currency character varying(10) NOT NULL,
    amount numeric(12,2) NOT NULL,
    gateway_response jsonb NOT NULL,
    payment_id integer NOT NULL,
    customer_id character varying(256)
);


ALTER TABLE public.payment_transaction OWNER TO postgres;

--
-- Name: payment_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_transaction_id_seq OWNER TO postgres;

--
-- Name: payment_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_transaction_id_seq OWNED BY public.payment_transaction.id;


--
-- Name: portal_carousel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.portal_carousel (
    id integer NOT NULL,
    image character varying(100),
    ppoi character varying(20) NOT NULL,
    title character varying(255),
    description text NOT NULL,
    "order" integer NOT NULL
);


ALTER TABLE public.portal_carousel OWNER TO postgres;

--
-- Name: portal_carousel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.portal_carousel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.portal_carousel_id_seq OWNER TO postgres;

--
-- Name: portal_carousel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.portal_carousel_id_seq OWNED BY public.portal_carousel.id;


--
-- Name: portal_carousellinks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.portal_carousellinks (
    id integer NOT NULL,
    url text NOT NULL,
    caption character varying(255) NOT NULL,
    "order" integer NOT NULL,
    carousel_id integer NOT NULL
);


ALTER TABLE public.portal_carousellinks OWNER TO postgres;

--
-- Name: portal_carousellinks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.portal_carousellinks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.portal_carousellinks_id_seq OWNER TO postgres;

--
-- Name: portal_carousellinks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.portal_carousellinks_id_seq OWNED BY public.portal_carousellinks.id;


--
-- Name: product_attribute; Type: TABLE; Schema: public; Owner: drupphuser1
--

CREATE TABLE public.product_attribute (
    id integer NOT NULL,
    slug character varying(50) NOT NULL,
    name character varying(50) NOT NULL,
    product_type_id integer,
    product_variant_type_id integer
);


ALTER TABLE public.product_attribute OWNER TO drupphuser1;

--
-- Name: product_attributevalue; Type: TABLE; Schema: public; Owner: drupphuser1
--

CREATE TABLE public.product_attributevalue (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    attribute_id integer NOT NULL,
    slug character varying(100) NOT NULL,
    sort_order integer,
    value character varying(100) NOT NULL,
    CONSTRAINT product_attributechoicevalue_sort_order_check CHECK ((sort_order >= 0))
);


ALTER TABLE public.product_attributevalue OWNER TO drupphuser1;

--
-- Name: product_attributechoicevalue_id_seq; Type: SEQUENCE; Schema: public; Owner: drupphuser1
--

CREATE SEQUENCE public.product_attributechoicevalue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_attributechoicevalue_id_seq OWNER TO drupphuser1;

--
-- Name: product_attributechoicevalue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drupphuser1
--

ALTER SEQUENCE public.product_attributechoicevalue_id_seq OWNED BY public.product_attributevalue.id;


--
-- Name: product_attributevaluetranslation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_attributevaluetranslation (
    id integer NOT NULL,
    language_code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    attribute_value_id integer NOT NULL
);


ALTER TABLE public.product_attributevaluetranslation OWNER TO postgres;

--
-- Name: product_attributechoicevaluetranslation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_attributechoicevaluetranslation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_attributechoicevaluetranslation_id_seq OWNER TO postgres;

--
-- Name: product_attributechoicevaluetranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_attributechoicevaluetranslation_id_seq OWNED BY public.product_attributevaluetranslation.id;


--
-- Name: product_attributetranslation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_attributetranslation (
    id integer NOT NULL,
    language_code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    attribute_id integer NOT NULL
);


ALTER TABLE public.product_attributetranslation OWNER TO postgres;

--
-- Name: product_category; Type: TABLE; Schema: public; Owner: drupphuser1
--

CREATE TABLE public.product_category (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    slug character varying(128) NOT NULL,
    description text NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    parent_id integer,
    background_image character varying(100),
    seo_description character varying(300),
    seo_title character varying(70),
    background_image_alt character varying(128) NOT NULL,
    description_json jsonb NOT NULL,
    CONSTRAINT product_category_level_check CHECK ((level >= 0)),
    CONSTRAINT product_category_lft_check CHECK ((lft >= 0)),
    CONSTRAINT product_category_rght_check CHECK ((rght >= 0)),
    CONSTRAINT product_category_tree_id_check CHECK ((tree_id >= 0))
);


ALTER TABLE public.product_category OWNER TO drupphuser1;

--
-- Name: product_category_id_seq; Type: SEQUENCE; Schema: public; Owner: drupphuser1
--

CREATE SEQUENCE public.product_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_category_id_seq OWNER TO drupphuser1;

--
-- Name: product_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drupphuser1
--

ALTER SEQUENCE public.product_category_id_seq OWNED BY public.product_category.id;


--
-- Name: product_categorytranslation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_categorytranslation (
    id integer NOT NULL,
    seo_title character varying(70),
    seo_description character varying(300),
    language_code character varying(10) NOT NULL,
    name character varying(128) NOT NULL,
    description text NOT NULL,
    category_id integer NOT NULL,
    description_json jsonb NOT NULL
);


ALTER TABLE public.product_categorytranslation OWNER TO postgres;

--
-- Name: product_categorytranslation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_categorytranslation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_categorytranslation_id_seq OWNER TO postgres;

--
-- Name: product_categorytranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_categorytranslation_id_seq OWNED BY public.product_categorytranslation.id;


--
-- Name: product_collection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_collection (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    slug character varying(128) NOT NULL,
    background_image character varying(100),
    seo_description character varying(300),
    seo_title character varying(70),
    is_published boolean NOT NULL,
    description text NOT NULL,
    publication_date date,
    background_image_alt character varying(128) NOT NULL,
    description_json jsonb NOT NULL
);


ALTER TABLE public.product_collection OWNER TO postgres;

--
-- Name: product_collection_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_collection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_collection_id_seq OWNER TO postgres;

--
-- Name: product_collection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_collection_id_seq OWNED BY public.product_collection.id;


--
-- Name: product_collectionproduct; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_collectionproduct (
    id integer NOT NULL,
    collection_id integer NOT NULL,
    product_id integer NOT NULL,
    sort_order integer,
    CONSTRAINT product_collection_products_sort_order_check CHECK ((sort_order >= 0))
);


ALTER TABLE public.product_collectionproduct OWNER TO postgres;

--
-- Name: product_collection_products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_collection_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_collection_products_id_seq OWNER TO postgres;

--
-- Name: product_collection_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_collection_products_id_seq OWNED BY public.product_collectionproduct.id;


--
-- Name: product_collectiontranslation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_collectiontranslation (
    id integer NOT NULL,
    seo_title character varying(70),
    seo_description character varying(300),
    language_code character varying(10) NOT NULL,
    name character varying(128) NOT NULL,
    collection_id integer NOT NULL,
    description text NOT NULL,
    description_json jsonb NOT NULL
);


ALTER TABLE public.product_collectiontranslation OWNER TO postgres;

--
-- Name: product_collectiontranslation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_collectiontranslation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_collectiontranslation_id_seq OWNER TO postgres;

--
-- Name: product_collectiontranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_collectiontranslation_id_seq OWNED BY public.product_collectiontranslation.id;


--
-- Name: product_digitalcontent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_digitalcontent (
    id integer NOT NULL,
    use_default_settings boolean NOT NULL,
    automatic_fulfillment boolean NOT NULL,
    content_type character varying(128) NOT NULL,
    content_file character varying(100) NOT NULL,
    max_downloads integer,
    url_valid_days integer,
    product_variant_id integer NOT NULL
);


ALTER TABLE public.product_digitalcontent OWNER TO postgres;

--
-- Name: product_digitalcontent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_digitalcontent_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_digitalcontent_id_seq OWNER TO postgres;

--
-- Name: product_digitalcontent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_digitalcontent_id_seq OWNED BY public.product_digitalcontent.id;


--
-- Name: product_digitalcontenturl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_digitalcontenturl (
    id integer NOT NULL,
    token uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    download_num integer NOT NULL,
    content_id integer NOT NULL,
    line_id integer
);


ALTER TABLE public.product_digitalcontenturl OWNER TO postgres;

--
-- Name: product_digitalcontenturl_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_digitalcontenturl_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_digitalcontenturl_id_seq OWNER TO postgres;

--
-- Name: product_digitalcontenturl_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_digitalcontenturl_id_seq OWNED BY public.product_digitalcontenturl.id;


--
-- Name: product_product; Type: TABLE; Schema: public; Owner: drupphuser1
--

CREATE TABLE public.product_product (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    description text NOT NULL,
    price numeric(12,2),
    publication_date date,
    updated_at timestamp with time zone,
    product_type_id integer NOT NULL,
    attributes public.hstore NOT NULL,
    is_published boolean NOT NULL,
    category_id integer NOT NULL,
    seo_description character varying(300),
    seo_title character varying(70),
    charge_taxes boolean NOT NULL,
    weight double precision,
    description_json jsonb NOT NULL,
    meta jsonb,
    created_at timestamp with time zone
);


ALTER TABLE public.product_product OWNER TO drupphuser1;

--
-- Name: product_product_id_seq; Type: SEQUENCE; Schema: public; Owner: drupphuser1
--

CREATE SEQUENCE public.product_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_product_id_seq OWNER TO drupphuser1;

--
-- Name: product_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drupphuser1
--

ALTER SEQUENCE public.product_product_id_seq OWNED BY public.product_product.id;


--
-- Name: product_productattribute_id_seq; Type: SEQUENCE; Schema: public; Owner: drupphuser1
--

CREATE SEQUENCE public.product_productattribute_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_productattribute_id_seq OWNER TO drupphuser1;

--
-- Name: product_productattribute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drupphuser1
--

ALTER SEQUENCE public.product_productattribute_id_seq OWNED BY public.product_attribute.id;


--
-- Name: product_productattributetranslation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_productattributetranslation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_productattributetranslation_id_seq OWNER TO postgres;

--
-- Name: product_productattributetranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_productattributetranslation_id_seq OWNED BY public.product_attributetranslation.id;


--
-- Name: product_producttype; Type: TABLE; Schema: public; Owner: drupphuser1
--

CREATE TABLE public.product_producttype (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    has_variants boolean NOT NULL,
    is_shipping_required boolean NOT NULL,
    weight double precision NOT NULL,
    is_digital boolean NOT NULL,
    meta jsonb,
    user_id integer,
    is_published boolean NOT NULL,
    publication_date date
);


ALTER TABLE public.product_producttype OWNER TO drupphuser1;

--
-- Name: product_productclass_id_seq; Type: SEQUENCE; Schema: public; Owner: drupphuser1
--

CREATE SEQUENCE public.product_productclass_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_productclass_id_seq OWNER TO drupphuser1;

--
-- Name: product_productclass_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drupphuser1
--

ALTER SEQUENCE public.product_productclass_id_seq OWNED BY public.product_producttype.id;


--
-- Name: product_productimage; Type: TABLE; Schema: public; Owner: drupphuser1
--

CREATE TABLE public.product_productimage (
    id integer NOT NULL,
    image character varying(100) NOT NULL,
    ppoi character varying(20) NOT NULL,
    alt character varying(128) NOT NULL,
    sort_order integer,
    product_id integer NOT NULL,
    CONSTRAINT product_productimage_sort_order_dfda9c19_check CHECK ((sort_order >= 0))
);


ALTER TABLE public.product_productimage OWNER TO drupphuser1;

--
-- Name: product_productimage_id_seq; Type: SEQUENCE; Schema: public; Owner: drupphuser1
--

CREATE SEQUENCE public.product_productimage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_productimage_id_seq OWNER TO drupphuser1;

--
-- Name: product_productimage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drupphuser1
--

ALTER SEQUENCE public.product_productimage_id_seq OWNED BY public.product_productimage.id;


--
-- Name: product_producttranslation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_producttranslation (
    id integer NOT NULL,
    seo_title character varying(70),
    seo_description character varying(300),
    language_code character varying(10) NOT NULL,
    name character varying(128) NOT NULL,
    description text NOT NULL,
    product_id integer NOT NULL,
    description_json jsonb NOT NULL
);


ALTER TABLE public.product_producttranslation OWNER TO postgres;

--
-- Name: product_producttranslation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_producttranslation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_producttranslation_id_seq OWNER TO postgres;

--
-- Name: product_producttranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_producttranslation_id_seq OWNED BY public.product_producttranslation.id;


--
-- Name: product_productvariant; Type: TABLE; Schema: public; Owner: drupphuser1
--

CREATE TABLE public.product_productvariant (
    id integer NOT NULL,
    sku character varying(32) NOT NULL,
    name character varying(255) NOT NULL,
    price_override numeric(12,2),
    product_id integer NOT NULL,
    attributes public.hstore NOT NULL,
    cost_price numeric(12,2),
    quantity integer NOT NULL,
    quantity_allocated integer NOT NULL,
    track_inventory boolean NOT NULL,
    weight double precision
);


ALTER TABLE public.product_productvariant OWNER TO drupphuser1;

--
-- Name: product_productvariant_id_seq; Type: SEQUENCE; Schema: public; Owner: drupphuser1
--

CREATE SEQUENCE public.product_productvariant_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_productvariant_id_seq OWNER TO drupphuser1;

--
-- Name: product_productvariant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drupphuser1
--

ALTER SEQUENCE public.product_productvariant_id_seq OWNED BY public.product_productvariant.id;


--
-- Name: product_productvarianttranslation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_productvarianttranslation (
    id integer NOT NULL,
    language_code character varying(10) NOT NULL,
    name character varying(255) NOT NULL,
    product_variant_id integer NOT NULL
);


ALTER TABLE public.product_productvarianttranslation OWNER TO postgres;

--
-- Name: product_productvarianttranslation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_productvarianttranslation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_productvarianttranslation_id_seq OWNER TO postgres;

--
-- Name: product_productvarianttranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_productvarianttranslation_id_seq OWNED BY public.product_productvarianttranslation.id;


--
-- Name: product_variantimage; Type: TABLE; Schema: public; Owner: drupphuser1
--

CREATE TABLE public.product_variantimage (
    id integer NOT NULL,
    image_id integer NOT NULL,
    variant_id integer NOT NULL
);


ALTER TABLE public.product_variantimage OWNER TO drupphuser1;

--
-- Name: product_variantimage_id_seq; Type: SEQUENCE; Schema: public; Owner: drupphuser1
--

CREATE SEQUENCE public.product_variantimage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_variantimage_id_seq OWNER TO drupphuser1;

--
-- Name: product_variantimage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drupphuser1
--

ALTER SEQUENCE public.product_variantimage_id_seq OWNED BY public.product_variantimage.id;


--
-- Name: shipping_shippingcities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_shippingcities (
    id integer NOT NULL,
    city character varying(256) NOT NULL,
    shipping_province_id integer NOT NULL
);


ALTER TABLE public.shipping_shippingcities OWNER TO postgres;

--
-- Name: shipping_shippingcities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shipping_shippingcities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shipping_shippingcities_id_seq OWNER TO postgres;

--
-- Name: shipping_shippingcities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shipping_shippingcities_id_seq OWNED BY public.shipping_shippingcities.id;


--
-- Name: shipping_shippingmethod; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_shippingmethod (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    maximum_order_price numeric(12,2),
    maximum_order_weight double precision,
    minimum_order_price numeric(12,2),
    minimum_order_weight double precision,
    price numeric(12,2) NOT NULL,
    type character varying(30) NOT NULL,
    shipping_zone_id integer NOT NULL,
    meta jsonb NOT NULL
);


ALTER TABLE public.shipping_shippingmethod OWNER TO postgres;

--
-- Name: shipping_shippingmethod_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shipping_shippingmethod_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shipping_shippingmethod_id_seq OWNER TO postgres;

--
-- Name: shipping_shippingmethod_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shipping_shippingmethod_id_seq OWNED BY public.shipping_shippingmethod.id;


--
-- Name: shipping_shippingmethodtranslation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_shippingmethodtranslation (
    id integer NOT NULL,
    language_code character varying(10) NOT NULL,
    name character varying(255),
    shipping_method_id integer NOT NULL
);


ALTER TABLE public.shipping_shippingmethodtranslation OWNER TO postgres;

--
-- Name: shipping_shippingmethodtranslation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shipping_shippingmethodtranslation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shipping_shippingmethodtranslation_id_seq OWNER TO postgres;

--
-- Name: shipping_shippingmethodtranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shipping_shippingmethodtranslation_id_seq OWNED BY public.shipping_shippingmethodtranslation.id;


--
-- Name: shipping_shippingprovince; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_shippingprovince (
    id integer NOT NULL,
    province character varying(256) NOT NULL,
    shipping_zone_id integer NOT NULL
);


ALTER TABLE public.shipping_shippingprovince OWNER TO postgres;

--
-- Name: shipping_shippingprovince_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shipping_shippingprovince_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shipping_shippingprovince_id_seq OWNER TO postgres;

--
-- Name: shipping_shippingprovince_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shipping_shippingprovince_id_seq OWNED BY public.shipping_shippingprovince.id;


--
-- Name: shipping_shippingzone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_shippingzone (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    countries character varying(2) NOT NULL,
    "default" boolean NOT NULL
);


ALTER TABLE public.shipping_shippingzone OWNER TO postgres;

--
-- Name: shipping_shippingzone_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shipping_shippingzone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shipping_shippingzone_id_seq OWNER TO postgres;

--
-- Name: shipping_shippingzone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shipping_shippingzone_id_seq OWNED BY public.shipping_shippingzone.id;


--
-- Name: shipping_usershippingzone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_usershippingzone (
    id integer NOT NULL,
    shipping_zone_id integer NOT NULL,
    user_id integer
);


ALTER TABLE public.shipping_usershippingzone OWNER TO postgres;

--
-- Name: shipping_usershippingzone_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shipping_usershippingzone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shipping_usershippingzone_id_seq OWNER TO postgres;

--
-- Name: shipping_usershippingzone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shipping_usershippingzone_id_seq OWNED BY public.shipping_usershippingzone.id;


--
-- Name: site_authorizationkey; Type: TABLE; Schema: public; Owner: drupphuser1
--

CREATE TABLE public.site_authorizationkey (
    id integer NOT NULL,
    name character varying(20) NOT NULL,
    key text NOT NULL,
    password text NOT NULL,
    site_settings_id integer NOT NULL
);


ALTER TABLE public.site_authorizationkey OWNER TO drupphuser1;

--
-- Name: site_authorizationkey_id_seq; Type: SEQUENCE; Schema: public; Owner: drupphuser1
--

CREATE SEQUENCE public.site_authorizationkey_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.site_authorizationkey_id_seq OWNER TO drupphuser1;

--
-- Name: site_authorizationkey_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drupphuser1
--

ALTER SEQUENCE public.site_authorizationkey_id_seq OWNED BY public.site_authorizationkey.id;


--
-- Name: site_sitesettings; Type: TABLE; Schema: public; Owner: drupphuser1
--

CREATE TABLE public.site_sitesettings (
    id integer NOT NULL,
    header_text character varying(200) NOT NULL,
    description character varying(500) NOT NULL,
    site_id integer NOT NULL,
    bottom_menu_id integer,
    top_menu_id integer,
    display_gross_prices boolean NOT NULL,
    include_taxes_in_prices boolean NOT NULL,
    charge_taxes_on_shipping boolean NOT NULL,
    track_inventory_by_default boolean NOT NULL,
    homepage_collection_id integer,
    default_weight_unit character varying(10) NOT NULL,
    automatic_fulfillment_digital_products boolean NOT NULL,
    default_digital_max_downloads integer,
    default_digital_url_valid_days integer,
    company_address_id integer
);


ALTER TABLE public.site_sitesettings OWNER TO drupphuser1;

--
-- Name: site_sitesettings_id_seq; Type: SEQUENCE; Schema: public; Owner: drupphuser1
--

CREATE SEQUENCE public.site_sitesettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.site_sitesettings_id_seq OWNER TO drupphuser1;

--
-- Name: site_sitesettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drupphuser1
--

ALTER SEQUENCE public.site_sitesettings_id_seq OWNED BY public.site_sitesettings.id;


--
-- Name: site_sitesettingstranslation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.site_sitesettingstranslation (
    id integer NOT NULL,
    language_code character varying(10) NOT NULL,
    header_text character varying(200) NOT NULL,
    description character varying(500) NOT NULL,
    site_settings_id integer NOT NULL
);


ALTER TABLE public.site_sitesettingstranslation OWNER TO postgres;

--
-- Name: site_sitesettingstranslation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.site_sitesettingstranslation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.site_sitesettingstranslation_id_seq OWNER TO postgres;

--
-- Name: site_sitesettingstranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.site_sitesettingstranslation_id_seq OWNED BY public.site_sitesettingstranslation.id;


--
-- Name: social_auth_association; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.social_auth_association (
    id integer NOT NULL,
    server_url character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    secret character varying(255) NOT NULL,
    issued integer NOT NULL,
    lifetime integer NOT NULL,
    assoc_type character varying(64) NOT NULL
);


ALTER TABLE public.social_auth_association OWNER TO postgres;

--
-- Name: social_auth_association_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.social_auth_association_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.social_auth_association_id_seq OWNER TO postgres;

--
-- Name: social_auth_association_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.social_auth_association_id_seq OWNED BY public.social_auth_association.id;


--
-- Name: social_auth_code; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.social_auth_code (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    code character varying(32) NOT NULL,
    verified boolean NOT NULL,
    "timestamp" timestamp with time zone NOT NULL
);


ALTER TABLE public.social_auth_code OWNER TO postgres;

--
-- Name: social_auth_code_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.social_auth_code_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.social_auth_code_id_seq OWNER TO postgres;

--
-- Name: social_auth_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.social_auth_code_id_seq OWNED BY public.social_auth_code.id;


--
-- Name: social_auth_nonce; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.social_auth_nonce (
    id integer NOT NULL,
    server_url character varying(255) NOT NULL,
    "timestamp" integer NOT NULL,
    salt character varying(65) NOT NULL
);


ALTER TABLE public.social_auth_nonce OWNER TO postgres;

--
-- Name: social_auth_nonce_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.social_auth_nonce_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.social_auth_nonce_id_seq OWNER TO postgres;

--
-- Name: social_auth_nonce_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.social_auth_nonce_id_seq OWNED BY public.social_auth_nonce.id;


--
-- Name: social_auth_partial; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.social_auth_partial (
    id integer NOT NULL,
    token character varying(32) NOT NULL,
    next_step smallint NOT NULL,
    backend character varying(32) NOT NULL,
    data text NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    CONSTRAINT social_auth_partial_next_step_check CHECK ((next_step >= 0))
);


ALTER TABLE public.social_auth_partial OWNER TO postgres;

--
-- Name: social_auth_partial_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.social_auth_partial_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.social_auth_partial_id_seq OWNER TO postgres;

--
-- Name: social_auth_partial_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.social_auth_partial_id_seq OWNED BY public.social_auth_partial.id;


--
-- Name: social_auth_usersocialauth; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.social_auth_usersocialauth (
    id integer NOT NULL,
    provider character varying(32) NOT NULL,
    uid character varying(255) NOT NULL,
    extra_data text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.social_auth_usersocialauth OWNER TO postgres;

--
-- Name: social_auth_usersocialauth_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.social_auth_usersocialauth_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.social_auth_usersocialauth_id_seq OWNER TO postgres;

--
-- Name: social_auth_usersocialauth_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.social_auth_usersocialauth_id_seq OWNED BY public.social_auth_usersocialauth.id;


--
-- Name: storefront_businessdocument; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.storefront_businessdocument (
    id integer NOT NULL,
    image character varying(100),
    ppoi character varying(20) NOT NULL,
    title character varying(255),
    store_id integer
);


ALTER TABLE public.storefront_businessdocument OWNER TO postgres;

--
-- Name: storefront_businessdocument_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.storefront_businessdocument_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.storefront_businessdocument_id_seq OWNER TO postgres;

--
-- Name: storefront_businessdocument_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.storefront_businessdocument_id_seq OWNED BY public.storefront_businessdocument.id;


--
-- Name: storefront_colorthemes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.storefront_colorthemes (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    css character varying(512) NOT NULL,
    order_arrangement integer NOT NULL
);


ALTER TABLE public.storefront_colorthemes OWNER TO postgres;

--
-- Name: storefront_colorthemes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.storefront_colorthemes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.storefront_colorthemes_id_seq OWNER TO postgres;

--
-- Name: storefront_colorthemes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.storefront_colorthemes_id_seq OWNED BY public.storefront_colorthemes.id;


--
-- Name: storefront_store; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.storefront_store (
    id integer NOT NULL,
    storename character varying(32) NOT NULL,
    banner_image character varying(100),
    profile_image character varying(100),
    ppoi character varying(20) NOT NULL,
    alt character varying(128),
    is_publish boolean NOT NULL,
    owner_id integer,
    storeaddress_id integer,
    dsap character varying(32),
    operating_hours jsonb NOT NULL,
    color_themes_id integer,
    latitude numeric(9,6),
    longtitude numeric(9,6),
    storename_sticky boolean NOT NULL
);


ALTER TABLE public.storefront_store OWNER TO postgres;

--
-- Name: storefront_store_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.storefront_store_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.storefront_store_id_seq OWNER TO postgres;

--
-- Name: storefront_store_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.storefront_store_id_seq OWNED BY public.storefront_store.id;


--
-- Name: storefront_temporaryimage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.storefront_temporaryimage (
    id integer NOT NULL,
    procedure integer NOT NULL,
    image character varying(100) NOT NULL,
    store_id integer NOT NULL,
    filename character varying(255) NOT NULL
);


ALTER TABLE public.storefront_temporaryimage OWNER TO postgres;

--
-- Name: storefront_temporaryimage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.storefront_temporaryimage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.storefront_temporaryimage_id_seq OWNER TO postgres;

--
-- Name: storefront_temporaryimage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.storefront_temporaryimage_id_seq OWNED BY public.storefront_temporaryimage.id;


--
-- Name: userprofile_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.userprofile_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.userprofile_address_id_seq OWNER TO postgres;

--
-- Name: userprofile_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.userprofile_address_id_seq OWNED BY public.account_address.id;


--
-- Name: userprofile_user_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.userprofile_user_addresses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.userprofile_user_addresses_id_seq OWNER TO postgres;

--
-- Name: userprofile_user_addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.userprofile_user_addresses_id_seq OWNED BY public.account_user_addresses.id;


--
-- Name: userprofile_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.userprofile_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.userprofile_user_groups_id_seq OWNER TO postgres;

--
-- Name: userprofile_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.userprofile_user_groups_id_seq OWNED BY public.account_user_groups.id;


--
-- Name: userprofile_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.userprofile_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.userprofile_user_id_seq OWNER TO postgres;

--
-- Name: userprofile_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.userprofile_user_id_seq OWNED BY public.account_user.id;


--
-- Name: userprofile_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.userprofile_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.userprofile_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: userprofile_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.userprofile_user_user_permissions_id_seq OWNED BY public.account_user_user_permissions.id;


--
-- Name: account_address id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_address ALTER COLUMN id SET DEFAULT nextval('public.userprofile_address_id_seq'::regclass);


--
-- Name: account_customerevent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_customerevent ALTER COLUMN id SET DEFAULT nextval('public.account_customerevent_id_seq'::regclass);


--
-- Name: account_customernote id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_customernote ALTER COLUMN id SET DEFAULT nextval('public.account_customernote_id_seq'::regclass);


--
-- Name: account_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user ALTER COLUMN id SET DEFAULT nextval('public.userprofile_user_id_seq'::regclass);


--
-- Name: account_user_addresses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_addresses ALTER COLUMN id SET DEFAULT nextval('public.userprofile_user_addresses_id_seq'::regclass);


--
-- Name: account_user_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_groups ALTER COLUMN id SET DEFAULT nextval('public.userprofile_user_groups_id_seq'::regclass);


--
-- Name: account_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.userprofile_user_user_permissions_id_seq'::regclass);


--
-- Name: account_userproducts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_userproducts ALTER COLUMN id SET DEFAULT nextval('public.account_userproducts_id_seq'::regclass);


--
-- Name: account_userrequestform id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_userrequestform ALTER COLUMN id SET DEFAULT nextval('public.account_userrequestform_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: checkout_checkout_gift_cards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkout_gift_cards ALTER COLUMN id SET DEFAULT nextval('public.checkout_checkout_gift_cards_id_seq'::regclass);


--
-- Name: checkout_checkoutline id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkoutline ALTER COLUMN id SET DEFAULT nextval('public.cart_cartline_id_seq'::regclass);


--
-- Name: discount_sale id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale ALTER COLUMN id SET DEFAULT nextval('public.discount_sale_id_seq'::regclass);


--
-- Name: discount_sale_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_categories ALTER COLUMN id SET DEFAULT nextval('public.discount_sale_categories_id_seq'::regclass);


--
-- Name: discount_sale_collections id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_collections ALTER COLUMN id SET DEFAULT nextval('public.discount_sale_collections_id_seq'::regclass);


--
-- Name: discount_sale_products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_products ALTER COLUMN id SET DEFAULT nextval('public.discount_sale_products_id_seq'::regclass);


--
-- Name: discount_saletranslation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_saletranslation ALTER COLUMN id SET DEFAULT nextval('public.discount_saletranslation_id_seq'::regclass);


--
-- Name: discount_voucher id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher ALTER COLUMN id SET DEFAULT nextval('public.discount_voucher_id_seq'::regclass);


--
-- Name: discount_voucher_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_categories ALTER COLUMN id SET DEFAULT nextval('public.discount_voucher_categories_id_seq'::regclass);


--
-- Name: discount_voucher_collections id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_collections ALTER COLUMN id SET DEFAULT nextval('public.discount_voucher_collections_id_seq'::regclass);


--
-- Name: discount_voucher_products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_products ALTER COLUMN id SET DEFAULT nextval('public.discount_voucher_products_id_seq'::regclass);


--
-- Name: discount_vouchertranslation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_vouchertranslation ALTER COLUMN id SET DEFAULT nextval('public.discount_vouchertranslation_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_prices_openexchangerates_conversionrate id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_prices_openexchangerates_conversionrate ALTER COLUMN id SET DEFAULT nextval('public.django_prices_openexchangerates_conversionrate_id_seq'::regclass);


--
-- Name: django_prices_vatlayer_ratetypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_prices_vatlayer_ratetypes ALTER COLUMN id SET DEFAULT nextval('public.django_prices_vatlayer_ratetypes_id_seq'::regclass);


--
-- Name: django_prices_vatlayer_vat id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_prices_vatlayer_vat ALTER COLUMN id SET DEFAULT nextval('public.django_prices_vatlayer_vat_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: giftcard_giftcard id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.giftcard_giftcard ALTER COLUMN id SET DEFAULT nextval('public.giftcard_giftcard_id_seq'::regclass);


--
-- Name: impersonate_impersonationlog id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.impersonate_impersonationlog ALTER COLUMN id SET DEFAULT nextval('public.impersonate_impersonationlog_id_seq'::regclass);


--
-- Name: menu_menu id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_menu ALTER COLUMN id SET DEFAULT nextval('public.menu_menu_id_seq'::regclass);


--
-- Name: menu_menuitem id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_menuitem ALTER COLUMN id SET DEFAULT nextval('public.menu_menuitem_id_seq'::regclass);


--
-- Name: menu_menuitemtranslation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_menuitemtranslation ALTER COLUMN id SET DEFAULT nextval('public.menu_menuitemtranslation_id_seq'::regclass);


--
-- Name: order_fulfillment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_fulfillment ALTER COLUMN id SET DEFAULT nextval('public.order_fulfillment_id_seq'::regclass);


--
-- Name: order_fulfillmentline id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_fulfillmentline ALTER COLUMN id SET DEFAULT nextval('public.order_fulfillmentline_id_seq'::regclass);


--
-- Name: order_order id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_order ALTER COLUMN id SET DEFAULT nextval('public.order_order_id_seq'::regclass);


--
-- Name: order_order_gift_cards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_order_gift_cards ALTER COLUMN id SET DEFAULT nextval('public.order_order_gift_cards_id_seq'::regclass);


--
-- Name: order_orderevent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_orderevent ALTER COLUMN id SET DEFAULT nextval('public.order_orderevent_id_seq'::regclass);


--
-- Name: order_orderline id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_orderline ALTER COLUMN id SET DEFAULT nextval('public.order_ordereditem_id_seq'::regclass);


--
-- Name: page_page id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_page ALTER COLUMN id SET DEFAULT nextval('public.page_page_id_seq'::regclass);


--
-- Name: page_pagetranslation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_pagetranslation ALTER COLUMN id SET DEFAULT nextval('public.page_pagetranslation_id_seq'::regclass);


--
-- Name: payment_payment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_payment ALTER COLUMN id SET DEFAULT nextval('public.payment_paymentmethod_id_seq'::regclass);


--
-- Name: payment_transaction id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_transaction ALTER COLUMN id SET DEFAULT nextval('public.payment_transaction_id_seq'::regclass);


--
-- Name: portal_carousel id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_carousel ALTER COLUMN id SET DEFAULT nextval('public.portal_carousel_id_seq'::regclass);


--
-- Name: portal_carousellinks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_carousellinks ALTER COLUMN id SET DEFAULT nextval('public.portal_carousellinks_id_seq'::regclass);


--
-- Name: product_attribute id; Type: DEFAULT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_attribute ALTER COLUMN id SET DEFAULT nextval('public.product_productattribute_id_seq'::regclass);


--
-- Name: product_attributetranslation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_attributetranslation ALTER COLUMN id SET DEFAULT nextval('public.product_productattributetranslation_id_seq'::regclass);


--
-- Name: product_attributevalue id; Type: DEFAULT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_attributevalue ALTER COLUMN id SET DEFAULT nextval('public.product_attributechoicevalue_id_seq'::regclass);


--
-- Name: product_attributevaluetranslation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_attributevaluetranslation ALTER COLUMN id SET DEFAULT nextval('public.product_attributechoicevaluetranslation_id_seq'::regclass);


--
-- Name: product_category id; Type: DEFAULT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_category ALTER COLUMN id SET DEFAULT nextval('public.product_category_id_seq'::regclass);


--
-- Name: product_categorytranslation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categorytranslation ALTER COLUMN id SET DEFAULT nextval('public.product_categorytranslation_id_seq'::regclass);


--
-- Name: product_collection id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_collection ALTER COLUMN id SET DEFAULT nextval('public.product_collection_id_seq'::regclass);


--
-- Name: product_collectionproduct id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_collectionproduct ALTER COLUMN id SET DEFAULT nextval('public.product_collection_products_id_seq'::regclass);


--
-- Name: product_collectiontranslation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_collectiontranslation ALTER COLUMN id SET DEFAULT nextval('public.product_collectiontranslation_id_seq'::regclass);


--
-- Name: product_digitalcontent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_digitalcontent ALTER COLUMN id SET DEFAULT nextval('public.product_digitalcontent_id_seq'::regclass);


--
-- Name: product_digitalcontenturl id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_digitalcontenturl ALTER COLUMN id SET DEFAULT nextval('public.product_digitalcontenturl_id_seq'::regclass);


--
-- Name: product_product id; Type: DEFAULT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_product ALTER COLUMN id SET DEFAULT nextval('public.product_product_id_seq'::regclass);


--
-- Name: product_productimage id; Type: DEFAULT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_productimage ALTER COLUMN id SET DEFAULT nextval('public.product_productimage_id_seq'::regclass);


--
-- Name: product_producttranslation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_producttranslation ALTER COLUMN id SET DEFAULT nextval('public.product_producttranslation_id_seq'::regclass);


--
-- Name: product_producttype id; Type: DEFAULT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_producttype ALTER COLUMN id SET DEFAULT nextval('public.product_productclass_id_seq'::regclass);


--
-- Name: product_productvariant id; Type: DEFAULT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_productvariant ALTER COLUMN id SET DEFAULT nextval('public.product_productvariant_id_seq'::regclass);


--
-- Name: product_productvarianttranslation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_productvarianttranslation ALTER COLUMN id SET DEFAULT nextval('public.product_productvarianttranslation_id_seq'::regclass);


--
-- Name: product_variantimage id; Type: DEFAULT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_variantimage ALTER COLUMN id SET DEFAULT nextval('public.product_variantimage_id_seq'::regclass);


--
-- Name: shipping_shippingcities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingcities ALTER COLUMN id SET DEFAULT nextval('public.shipping_shippingcities_id_seq'::regclass);


--
-- Name: shipping_shippingmethod id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingmethod ALTER COLUMN id SET DEFAULT nextval('public.shipping_shippingmethod_id_seq'::regclass);


--
-- Name: shipping_shippingmethodtranslation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingmethodtranslation ALTER COLUMN id SET DEFAULT nextval('public.shipping_shippingmethodtranslation_id_seq'::regclass);


--
-- Name: shipping_shippingprovince id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingprovince ALTER COLUMN id SET DEFAULT nextval('public.shipping_shippingprovince_id_seq'::regclass);


--
-- Name: shipping_shippingzone id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingzone ALTER COLUMN id SET DEFAULT nextval('public.shipping_shippingzone_id_seq'::regclass);


--
-- Name: shipping_usershippingzone id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_usershippingzone ALTER COLUMN id SET DEFAULT nextval('public.shipping_usershippingzone_id_seq'::regclass);


--
-- Name: site_authorizationkey id; Type: DEFAULT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.site_authorizationkey ALTER COLUMN id SET DEFAULT nextval('public.site_authorizationkey_id_seq'::regclass);


--
-- Name: site_sitesettings id; Type: DEFAULT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.site_sitesettings ALTER COLUMN id SET DEFAULT nextval('public.site_sitesettings_id_seq'::regclass);


--
-- Name: site_sitesettingstranslation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_sitesettingstranslation ALTER COLUMN id SET DEFAULT nextval('public.site_sitesettingstranslation_id_seq'::regclass);


--
-- Name: social_auth_association id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_association ALTER COLUMN id SET DEFAULT nextval('public.social_auth_association_id_seq'::regclass);


--
-- Name: social_auth_code id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_code ALTER COLUMN id SET DEFAULT nextval('public.social_auth_code_id_seq'::regclass);


--
-- Name: social_auth_nonce id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_nonce ALTER COLUMN id SET DEFAULT nextval('public.social_auth_nonce_id_seq'::regclass);


--
-- Name: social_auth_partial id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_partial ALTER COLUMN id SET DEFAULT nextval('public.social_auth_partial_id_seq'::regclass);


--
-- Name: social_auth_usersocialauth id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_usersocialauth ALTER COLUMN id SET DEFAULT nextval('public.social_auth_usersocialauth_id_seq'::regclass);


--
-- Name: storefront_businessdocument id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_businessdocument ALTER COLUMN id SET DEFAULT nextval('public.storefront_businessdocument_id_seq'::regclass);


--
-- Name: storefront_colorthemes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_colorthemes ALTER COLUMN id SET DEFAULT nextval('public.storefront_colorthemes_id_seq'::regclass);


--
-- Name: storefront_store id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_store ALTER COLUMN id SET DEFAULT nextval('public.storefront_store_id_seq'::regclass);


--
-- Name: storefront_temporaryimage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_temporaryimage ALTER COLUMN id SET DEFAULT nextval('public.storefront_temporaryimage_id_seq'::regclass);


--
-- Data for Name: account_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_address (id, first_name, last_name, company_name, street_address_1, street_address_2, city, postal_code, country, country_area, phone, city_area) FROM stdin;
21	Abet	Cruz		1278 Syson St	Paco Manila	MANILA	1007	PH	Metro Manila	+639989982238	Barangay 671
20				13 Faustino St.		Quezon City		PH		+639291363388	NCR
22				PUBLIC TERMINAL, POBLACION		MATALAM		PH		+639464925138	NORTH COTABATO
19				Bauan Mabini Road				PH			
3						Better Living		PH			Paranaque, Metro Manila
25	sample	sample	sample	sample	sample	SAMPLE	2209	PH	Zambales	+639199560555	sample
14				National Road		Brgy. Dancalan, Ilog		PH		+639501611470	Negros Occidental
23				Block 216 Lot 7C Sampaguita St		Makati City		PH		+639104049100	Metro Manila
16				San Nicolas 2nd Betis		Guagua, Pampanga		PH			
13				9608 Kalayaan Avenue, Guadalupe Nuevo		Makati City		PH		+639261936546	Metro Manila
5				6793 Ayala Avenue		Makati City		PH			Metro Manila
30				San Pascual, San Antonio		Batangas City		PH			
6				Unit 906 9F V. Madrigal Building		Makati City		PH		+6325760503	Metro Manila
31	Albert	Dela Cruz		1278 Syson St.	Salcedo Village	MANILA	1007	PH	Metro Manila	+639989982238	National Capital Region
32	Albert	Dela Cruz		1278 Syson St.	Salcedo Village	MANILA	1007	PH	Metro Manila	+639989982238	National Capital Region
9				Faustino St.		Holy Spirit Quezon City		PH		+639199560555	
18				Stall #1, Promenade Area, Subic Public Market		Subic		PH		+639338648318	Zambales
33	testing	testing	testing		testing	TESTING	4200	PH	Batangas		testing
17				MAYANGAO ST. DAGUPAN CENTRO (POB)		TABUK CITY, KALINGA		PH		+639271648214	CAR
7				92 JP Rizal Ext.		Maypajo Caloocan City		PH		+6325760503	National Capital Region
34	testing	testing	testing		testing	TESTING	4200	PH	Batangas		testing
15				Dumas street		Binalbagan		PH		+639985384639	VI
2				13 Don Macario Street Dona Carmen Subdivision		Quezon City		PH			National Capital Region
10				Block 22 Lot 13B Leo Alejandrino St, BFRV		Las Pinas City		PH		+639178158928	NCR
24				National Highway, Zone 5, Bulua		Cagayan de Oro City		PH		+639066036449	Region 10
35	test	test	test	test	test	BATANGAS CITY	4200	PH	Batangas	+639066243152	test
36	test	test	test	test	test	BATANGAS CITY	4200	PH	Batangas	+639066243152	test
37	test	test	test	test	test	BATANGAS CITY	4200	PH	Batangas	+639066243152	test
38	test	test	test	test	test	BATANGAS CITY	4200	PH	Batangas	+639066243152	test
1				PACO Public Market		Manila		PH		+639989982238	Metro Manila
8				JMT  CORPORATE Condominium, ADB Avenue, Ortigas		Pasig City		PH		+639175698169	National Capital Region
12				Dumas		Binalbagan		PH		+639985384639	VI
4				141 S. J. Zobel St. Barangay Poblacion 1		Calatagan, Batangas		PH		+639178158928	Region 4A
11				Rizal St. Barangay 2		Himamaylan City		PH		+639206186417	Negros Occidental
\.


--
-- Data for Name: account_customerevent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_customerevent (id, date, type, parameters, order_id, user_id) FROM stdin;
193	2020-10-06 07:52:58.451655+00	customer_deleted	{"count": 1}	\N	62
199	2020-10-09 14:35:11.821423+00	customer_deleted	{"count": 1}	\N	65
200	2020-10-09 14:35:23.842282+00	customer_deleted	{"count": 1}	\N	65
8	2020-08-24 23:04:39.801424+00	account_created	{}	\N	7
9	2020-08-24 23:04:42.714356+00	account_activation_link_sent	{}	\N	7
10	2020-08-25 14:50:17.122294+00	account_created	{}	\N	9
11	2020-08-25 14:50:20.03597+00	account_activation_link_sent	{}	\N	9
12	2020-08-26 03:15:56.881451+00	account_created	{}	\N	10
13	2020-08-26 03:15:59.460382+00	account_activation_link_sent	{}	\N	10
203	2020-10-12 01:35:45.057574+00	customer_deleted	{"count": 1}	\N	62
204	2020-10-12 01:35:50.299721+00	customer_deleted	{"count": 1}	\N	62
16	2020-08-29 13:36:41.68776+00	account_created	{}	\N	12
17	2020-08-29 13:36:44.504478+00	account_activation_link_sent	{}	\N	12
18	2020-08-30 05:26:04.756132+00	account_created	{}	\N	13
19	2020-08-30 05:26:07.624526+00	account_activation_link_sent	{}	\N	13
213	2020-10-19 11:17:26.143725+00	password_reset	{}	\N	72
220	2020-10-22 05:54:01.300705+00	password_reset	{}	\N	70
245	2020-11-11 14:51:23.28935+00	password_reset	{}	\N	104
258	2020-11-22 19:49:13.496397+00	password_reset	{}	\N	95
32	2020-09-07 20:07:45.915053+00	customer_deleted	{"count": 1}	\N	1
34	2020-09-07 21:44:47.477169+00	customer_deleted	{"count": 1}	\N	1
36	2020-09-07 21:54:55.732104+00	customer_deleted	{"count": 1}	\N	1
38	2020-09-08 02:53:21.24135+00	customer_deleted	{"count": 1}	\N	1
40	2020-09-08 12:20:00.098699+00	customer_deleted	{"count": 1}	\N	1
42	2020-09-08 12:37:15.126379+00	password_reset_link_sent	{}	\N	1
45	2020-09-08 12:46:46.689042+00	customer_deleted	{"count": 1}	\N	1
46	2020-09-08 13:17:51.407796+00	password_reset_link_sent	{}	\N	1
47	2020-09-08 13:20:47.267125+00	password_reset_link_sent	{}	\N	1
50	2020-09-08 13:57:14.924462+00	customer_deleted	{"count": 1}	\N	1
53	2020-09-08 15:30:24.781901+00	customer_deleted	{"count": 1}	\N	1
54	2020-09-08 23:07:04.634768+00	customer_deleted	{"count": 1}	\N	1
56	2020-09-08 23:14:38.435339+00	customer_deleted	{"count": 1}	\N	1
59	2020-09-09 03:43:51.466682+00	customer_deleted	{"count": 1}	\N	1
62	2020-09-09 05:04:21.840844+00	customer_deleted	{"count": 1}	\N	1
64	2020-09-09 05:38:22.38666+00	customer_deleted	{"count": 1}	\N	1
67	2020-09-09 09:21:25.010116+00	customer_deleted	{"count": 1}	\N	1
70	2020-09-09 12:58:43.250461+00	customer_deleted	{"count": 1}	\N	1
73	2020-09-09 13:05:23.265883+00	customer_deleted	{"count": 1}	\N	1
74	2020-09-09 13:06:15.801974+00	account_created	{}	\N	36
75	2020-09-09 13:06:20.148778+00	account_activation_link_sent	{}	\N	36
76	2020-09-09 18:21:12.899003+00	password_reset_link_sent	{}	\N	9
77	2020-09-09 18:22:02.984691+00	password_reset	{}	\N	9
82	2020-09-12 03:16:29.247267+00	customer_deleted	{"count": 1}	\N	13
83	2020-09-12 03:16:38.015824+00	customer_deleted	{"count": 1}	\N	13
84	2020-09-12 03:16:41.976022+00	customer_deleted	{"count": 1}	\N	13
85	2020-09-12 03:16:46.003771+00	customer_deleted	{"count": 1}	\N	13
86	2020-09-12 03:16:54.586977+00	customer_deleted	{"count": 1}	\N	13
87	2020-09-12 03:17:01.07291+00	customer_deleted	{"count": 1}	\N	13
88	2020-09-12 03:17:07.127137+00	customer_deleted	{"count": 1}	\N	13
89	2020-09-12 03:17:11.891473+00	customer_deleted	{"count": 1}	\N	13
90	2020-09-12 03:17:17.479594+00	customer_deleted	{"count": 1}	\N	13
91	2020-09-12 03:17:41.630142+00	customer_deleted	{"count": 1}	\N	13
92	2020-09-12 03:17:47.225884+00	customer_deleted	{"count": 1}	\N	13
95	2020-09-15 08:44:24.62785+00	account_created	{}	\N	40
96	2020-09-15 08:44:29.040098+00	account_activation_link_sent	{}	\N	40
99	2020-09-15 11:24:59.146666+00	customer_deleted	{"count": 1}	\N	13
102	2020-09-15 11:46:11.429647+00	customer_deleted	{"count": 1}	\N	13
103	2020-09-15 12:13:33.955319+00	password_reset_link_sent	{}	\N	7
104	2020-09-15 12:15:59.508003+00	password_reset	{}	\N	7
109	2020-09-17 00:16:16.858401+00	account_created	{}	\N	45
110	2020-09-17 00:16:19.521126+00	account_activation_link_sent	{}	\N	45
113	2020-09-17 06:56:57.284453+00	customer_deleted	{"count": 1}	\N	13
114	2020-09-17 06:57:23.752515+00	customer_deleted	{"count": 1}	\N	13
116	2020-09-17 06:59:26.664781+00	customer_deleted	{"count": 1}	\N	13
118	2020-09-17 07:01:14.676966+00	customer_deleted	{"count": 1}	\N	13
119	2020-09-17 07:08:53.509123+00	account_created	{}	\N	49
120	2020-09-17 07:08:56.834221+00	account_activation_link_sent	{}	\N	49
121	2020-09-17 07:19:56.687694+00	account_created	{}	\N	50
122	2020-09-17 07:19:59.207741+00	account_activation_link_sent	{}	\N	50
125	2020-09-18 08:06:03.215821+00	account_created	{}	\N	52
126	2020-09-18 08:06:07.039991+00	account_activation_link_sent	{}	\N	52
127	2020-09-19 05:42:40.784687+00	password_reset_link_sent	{}	\N	9
128	2020-09-19 07:13:33.767156+00	account_created	{}	\N	53
129	2020-09-19 07:13:36.320869+00	account_activation_link_sent	{}	\N	53
130	2020-09-19 07:28:58.408497+00	account_created	{}	\N	54
131	2020-09-19 07:29:01.163858+00	account_activation_link_sent	{}	\N	54
132	2020-09-19 15:18:21.590758+00	customer_deleted	{"count": 1}	\N	1
133	2020-09-21 05:20:23.98086+00	account_created	{}	\N	55
134	2020-09-21 05:20:26.375001+00	account_activation_link_sent	{}	\N	55
135	2020-09-21 09:08:25.429131+00	account_created	{}	\N	56
136	2020-09-21 09:08:27.825582+00	account_activation_link_sent	{}	\N	56
137	2020-09-22 06:46:59.206985+00	account_created	{}	\N	57
138	2020-09-22 06:47:01.620652+00	account_activation_link_sent	{}	\N	57
139	2020-09-22 06:47:33.401739+00	account_created	{}	\N	58
140	2020-09-22 06:47:35.781982+00	account_activation_link_sent	{}	\N	58
141	2020-09-22 06:48:39.102114+00	account_created	{}	\N	59
142	2020-09-22 06:48:41.549036+00	account_activation_link_sent	{}	\N	59
143	2020-09-22 07:36:32.040098+00	account_created	{}	\N	60
144	2020-09-22 07:36:34.451511+00	account_activation_link_sent	{}	\N	60
145	2020-09-22 07:46:08.113294+00	account_created	{}	\N	61
146	2020-09-22 07:46:10.577405+00	account_activation_link_sent	{}	\N	61
147	2020-09-22 08:01:35.710422+00	account_created	{}	\N	62
148	2020-09-22 08:01:38.285533+00	account_activation_link_sent	{}	\N	62
149	2020-09-22 08:10:44.209153+00	account_created	{}	\N	64
150	2020-09-22 08:10:46.602114+00	account_activation_link_sent	{}	\N	64
151	2020-09-24 04:59:15.97393+00	account_created	{}	\N	65
152	2020-09-24 04:59:18.619933+00	account_activation_link_sent	{}	\N	65
153	2020-09-24 06:49:02.852216+00	account_created	{}	\N	66
154	2020-09-24 06:49:05.338216+00	account_activation_link_sent	{}	\N	66
155	2020-09-24 08:14:06.514785+00	customer_deleted	{"count": 1}	\N	65
156	2020-09-24 08:14:38.972862+00	customer_deleted	{"count": 1}	\N	65
157	2020-09-24 08:14:58.258768+00	customer_deleted	{"count": 1}	\N	65
158	2020-09-24 08:15:26.494403+00	customer_deleted	{"count": 1}	\N	65
159	2020-09-24 08:20:35.420226+00	customer_deleted	{"count": 1}	\N	65
192	2020-10-06 07:52:46.580757+00	customer_deleted	{"count": 1}	\N	62
194	2020-10-08 02:33:58.373836+00	account_created	{}	\N	80
195	2020-10-08 02:34:01.783379+00	account_activation_link_sent	{}	\N	80
198	2020-10-08 10:12:58.890923+00	email_assigned	{"message": "drupphofficial@gmail.com"}	\N	62
166	2020-09-26 07:10:25.219525+00	account_created	{}	\N	70
167	2020-09-26 07:10:27.710647+00	account_activation_link_sent	{}	\N	70
168	2020-09-26 08:12:50.601904+00	account_created	{}	\N	71
169	2020-09-26 08:12:53.046558+00	account_activation_link_sent	{}	\N	71
170	2020-09-26 09:09:08.455925+00	customer_deleted	{"count": 1}	\N	62
171	2020-09-27 04:12:22.873283+00	customer_deleted	{"count": 1}	\N	65
172	2020-09-28 14:52:58.950384+00	customer_deleted	{"count": 1}	\N	65
173	2020-09-30 02:52:10.520272+00	account_created	{}	\N	72
174	2020-09-30 02:52:12.941979+00	account_activation_link_sent	{}	\N	72
179	2020-10-01 10:03:05.610425+00	email_assigned	{"message": "aph.8888@hotmail.com"}	\N	62
180	2020-10-01 10:27:38.086434+00	account_created	{}	\N	75
181	2020-10-01 10:27:41.331063+00	account_activation_link_sent	{}	\N	75
182	2020-10-01 10:28:17.946387+00	name_assigned	{"message": "Alberto Hechanova"}	\N	62
183	2020-10-03 06:33:47.745755+00	account_created	{}	\N	76
184	2020-10-03 06:33:51.587168+00	account_activation_link_sent	{}	\N	76
189	2020-10-03 07:50:08.109975+00	customer_deleted	{"count": 1}	\N	65
205	2020-10-12 01:46:48.708785+00	account_created	{}	\N	83
206	2020-10-12 01:46:52.034788+00	account_activation_link_sent	{}	\N	83
209	2020-10-13 00:33:17.767303+00	customer_deleted	{"count": 1}	\N	65
212	2020-10-19 11:15:48.448536+00	password_reset_link_sent	{}	\N	72
214	2020-10-22 03:13:33.307678+00	customer_deleted	{"count": 1}	\N	62
217	2020-10-22 03:36:53.665193+00	account_created	{}	\N	87
218	2020-10-22 03:36:56.788119+00	account_activation_link_sent	{}	\N	87
219	2020-10-22 05:45:48.424333+00	password_reset_link_sent	{}	\N	70
221	2020-10-27 05:11:19.726463+00	customer_deleted	{"count": 1}	\N	13
222	2020-10-29 01:42:29.58794+00	account_created	{}	\N	89
223	2020-10-29 01:42:33.336183+00	account_activation_link_sent	{}	\N	89
224	2020-10-31 07:22:43.148546+00	account_created	{}	\N	92
225	2020-10-31 07:22:45.757816+00	account_activation_link_sent	{}	\N	92
228	2020-10-31 19:26:51.622447+00	account_created	{}	\N	94
229	2020-10-31 19:26:54.360475+00	account_activation_link_sent	{}	\N	94
230	2020-11-03 02:17:49.68262+00	account_created	{}	\N	96
231	2020-11-03 02:17:52.374978+00	account_activation_link_sent	{}	\N	96
232	2020-11-04 04:46:09.510814+00	placed_order	{}	1	88
233	2020-11-10 12:26:48.573868+00	password_reset_link_sent	{}	\N	63
234	2020-11-11 05:55:17.031103+00	customer_deleted	{"count": 1}	\N	62
237	2020-11-11 14:38:22.402824+00	customer_deleted	{"count": 1}	\N	1
238	2020-11-11 14:38:35.189163+00	customer_deleted	{"count": 1}	\N	1
239	2020-11-11 14:38:42.481287+00	customer_deleted	{"count": 1}	\N	1
240	2020-11-11 14:39:06.984668+00	customer_deleted	{"count": 1}	\N	1
241	2020-11-11 14:40:04.372704+00	account_created	{}	\N	103
242	2020-11-11 14:40:06.955947+00	account_activation_link_sent	{}	\N	103
243	2020-11-11 14:40:52.014386+00	password_reset_link_sent	{}	\N	103
244	2020-11-11 14:50:45.917616+00	password_reset_link_sent	{}	\N	104
246	2020-11-12 04:56:35.657844+00	placed_order	{}	2	98
247	2020-11-12 12:36:58.877708+00	customer_deleted	{"count": 1}	\N	62
248	2020-11-12 12:38:10.347754+00	account_created	{}	\N	106
249	2020-11-12 12:38:12.900704+00	account_activation_link_sent	{}	\N	106
250	2020-11-12 13:00:00.189371+00	account_created	{}	\N	107
251	2020-11-12 13:00:02.835143+00	account_activation_link_sent	{}	\N	107
252	2020-11-14 15:09:43.275573+00	password_reset_link_sent	{}	\N	106
253	2020-11-14 15:09:50.019961+00	password_reset_link_sent	{}	\N	106
254	2020-11-18 06:18:12.291228+00	placed_order	{}	3	94
255	2020-11-18 06:47:35.358357+00	placed_order	{}	4	95
256	2020-11-20 09:30:53.149697+00	password_reset_link_sent	{}	\N	104
257	2020-11-22 19:47:41.105719+00	password_reset_link_sent	{}	\N	95
\.


--
-- Data for Name: account_customernote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_customernote (id, date, content, is_public, customer_id, user_id) FROM stdin;
\.


--
-- Data for Name: account_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_user (id, is_superuser, email, is_staff, is_active, password, date_joined, last_login, default_billing_address_id, default_shipping_address_id, note, token, first_name, last_name, avatar, private_meta, is_vendor, is_supplier, jwt_secret, activation_token, activation_token_has_been_used, request_for_reactivation) FROM stdin;
50	f	jovelyn.blancaflor@yahoo.com	f	t	pbkdf2_sha256$150000$SUjG9Yhimad7$7+CjOno8mD1QSu+9ox0lqukwDykqU2d6W6HI2u+DK24=	2020-09-17 07:19:56.498842+00	2020-10-06 08:03:58.799676+00	\N	\N		a7eae92d-b496-45f9-adea-60eaab2ac961	BGx	Pharmacy		{}	t	f	9ead39bb-95f3-46dc-8209-060d481221ef	11c1d729-f289-4b44-b4a8-c8d6eddb014a	f	f
62	f	support@drupph.com	t	t	pbkdf2_sha256$150000$195mn35s8K7r$4OB8vxduMYGQlSwGkA09/pFuWsZpVUWNySYYesJYDeY=	2020-09-22 08:01:35.511234+00	2020-11-12 12:35:07.620462+00	\N	\N		cb8080b2-884c-40b0-a914-41dce3ea2f76	Chris	Dela Cruz		{}	f	f	4b9f5b59-124c-437a-8e4f-162799eb737b	dbb28ddc-6fcc-4ad1-ab2c-48afe7b28eaf	f	f
9	f	ihealth@optievo.com	f	t	pbkdf2_sha256$150000$w6IuaN8YTPxH$Qgntbkb59vpCpxlQQw4zVaALByE+bz+88d2iQsczA84=	2020-08-25 14:50:16.865523+00	2020-11-06 06:59:49.644224+00	\N	\N		90b1fe80-4381-4b5f-b93f-1b8ddd6fdf8a	Island	C L		{}	t	f	560453d4-c6c5-44ae-95ab-7623134f4ced	394513db-1362-4464-b509-0dfb5f5a4f29	f	f
58	f	longabarico@yahoo.com	f	t	pbkdf2_sha256$150000$U8TzBYwHTyOH$wEOIzESK7y0PlIUjy1yFP9F2/YrWbf9cYHuiRjGRz08=	2020-09-22 06:47:32.947392+00	\N	\N	\N		5a58a238-e50e-4ddd-bef2-753f21dde741				{}	t	f	0a4bf121-9a53-42f9-b062-0d3f2298c960	49bd3354-f3f2-4759-9b37-15e01e93182d	f	f
70	f	bupharcodrupph@gmail.com	f	t	pbkdf2_sha256$150000$1ziPqqEu1HL2$Xo4poVAeBrMiaoKfB4Bu2l6TZcP/jIQnDLrvfmeZqmg=	2020-09-26 07:10:25.023116+00	2020-11-13 03:05:44.975647+00	\N	\N		a043607f-e0bc-401d-906e-ead79c7bac95				{}	t	f	d2897a74-32b2-498f-b3a4-d26ad158a59a	41b053d8-f140-47d1-a429-855b7e2fc4ef	f	f
57	f	bupharcomarketing@gmail.com	f	t	pbkdf2_sha256$150000$H7FNC6DM18GN$p94S5SblNJfLd0tPZgSWjX49L2Q1fWMi4ZSMDVkzQg0=	2020-09-22 06:46:59.005512+00	2020-10-22 06:31:06.729911+00	\N	\N		11e7e3e2-837c-4db7-a624-40af56863ff3				{}	t	f	1154d001-550e-48f2-95d5-21dc2c67f2af	cd191b80-c50a-4555-9597-84fd44cc927f	f	f
80	f	kristine.dospueblos@yahoo.com	f	t	pbkdf2_sha256$150000$n8XBpsKxB0Ag$fJ7c9bF73Nna+LPHAjMl53Jt/QP17X1jLhuAxe6S4e8=	2020-10-08 02:33:58.070188+00	2020-10-08 02:34:59.39059+00	\N	\N	\N	e12d1266-6378-42dc-b1dd-0ec2b797ce6f				{}	f	f	99d5a0a3-733a-4b5b-b952-9ce7f4cf169d	0b9c9b26-db69-408e-9120-6126444fb2c4	t	f
1	t	pzervoulakus@inmyhouse.net	t	t	pbkdf2_sha256$150000$JJdTnuyBxESj$O/4Gm/Bd0ieKh5p7R3ACD12XdnyzBGlLmyQQ2+YHSTo=	2020-08-21 14:26:13.30097+00	2020-11-28 09:20:31.066841+00	\N	\N	\N	516ef06f-c28d-4205-a332-0926e17be86d	Paulon	Zervoulakus		{}	f	f	401b556e-8a4f-475a-842c-ff365c729217	14be3114-7f4c-49bc-84df-42479563c1dc	f	f
7	f	mar@drupph.com	f	t	pbkdf2_sha256$150000$mLUcN7wyNy8l$JG7Gpsgd4PcRMzIqkNQdiMEAmyHJ5yFrzlbH80+kp30=	2020-08-24 23:04:39.606265+00	2020-10-27 06:10:39.058269+00	\N	\N		8a501998-c851-4b6c-818d-eb3dbd8f739a				{}	t	f	f78d87f2-4a11-403c-bc3f-e79b37043bf8	de8a7d3e-0353-42a7-960c-7014c9bba5fd	f	f
75	f	wellnessglobal2020@gmail.com	f	t	pbkdf2_sha256$150000$EiDiMkLLFPAd$a0OhjFLFiUO5GGQse8bGnSHkphGN0ByJAzjAMsJzYMQ=	2020-10-01 10:27:37.841083+00	2020-11-26 05:13:04.169723+00	\N	\N		f311c609-8659-476d-89f1-64c94605f3f7	Alberto	Hechanova		{}	t	f	fe697268-0695-4b50-8111-a16e2e5e94d8	4671af41-0292-42c3-b9dd-5c82f2908b33	f	f
56	f	evelynvitug@gmail.com	f	t	pbkdf2_sha256$150000$vxh7WsSdA4g3$nQ5qhOu0qTUUk0P33vVZh9F7uwbZc+jV1Rn7CwYJ+X0=	2020-09-21 09:08:25.227861+00	\N	\N	\N		83e3ecdd-0fbe-4198-b161-391ed88d70db				{}	t	f	2b0dd095-bd47-49b7-ad6e-6a4b572f6955	3db0163e-4d25-4f6c-8c1d-1d137d2ef555	f	f
71	f	au@amescodrug.com	f	t	pbkdf2_sha256$150000$jLjdw7zQjjdf$RQ93gtpW8bafg5H62p3LL1i8Wo87vk1YtBR3ESDd22Q=	2020-09-26 08:12:50.40536+00	2020-10-01 07:02:28.368006+00	\N	\N		3815d3ac-1a1a-4279-bc6d-c5ec325ccc52				{}	t	f	73ead349-de7e-461c-a9c5-e7a9008affdf	8f5d7135-c08c-4cf8-85d7-fd05b3c451b7	f	f
72	f	yvetsky123@yahoo.com	f	t	pbkdf2_sha256$150000$AU6W1q8OholE$JjVZOAzP2veqbgOuQdXzt8AEtQ2c07HwjmzTb3l11m0=	2020-09-30 02:52:10.321889+00	\N	\N	\N		8ac4deb7-9a7c-431e-a00c-f180b8f26195				{}	t	f	70bb9334-e184-4477-b9a8-40345750a205	a4d10c41-3123-4520-addd-356181135ad6	f	f
12	f	rov@drupph.com	f	t	pbkdf2_sha256$150000$b4VUlMpvKGr3$duv3UNIq6iCOao2FhwgJn6T8qsuTVIapsRs5A7GMbNA=	2020-08-29 13:36:41.49654+00	2020-11-16 09:36:50.219666+00	\N	\N		aaff2385-3f8f-4ce0-b19c-c89863611d34				{}	t	f	548f3fcb-44c8-4d3f-b092-d931f2ba8953	a8a82443-5adc-4243-8b15-648bc90e6a0f	f	f
10	f	albertdc@codedefy.ph	f	t	pbkdf2_sha256$150000$NfVPboCZFv7w$xw4t7/0ahtq3oeoBLWqEseTmuld4zuYagiTfNOf67kE=	2020-08-26 03:15:56.686909+00	2020-11-26 01:51:15.34718+00	\N	\N		f439d555-724b-40b0-8d44-24a30fb04819	Albert	Dela Cruz		{}	t	f	9cb52005-fe3c-40c8-8855-9f5cae65d18b	248e4c9b-2db9-476c-adc3-ca6e01f2d274	f	f
36	f	paulon.zervoulakus@gmail.com	f	t	pbkdf2_sha256$150000$YxlVDxTnfxMJ$M7LZmvhKGTwIeOxaTHUzN5mid1E4O6ZCmaZaZ9DG3Qk=	2020-09-09 13:06:15.60482+00	2020-11-28 03:40:12.547779+00	\N	\N		3ed2e292-3482-4141-bcdb-5f2534c7d085	paulon	zervoulakus		{}	t	f	b4240741-5a0d-4eb9-9cf7-5477932044e7	910d71e7-e428-43e4-91bf-3663f3012988	f	f
63	f	digitaldelacruz@icloud.com	t	t		2020-09-22 08:02:03.787391+00	\N	\N	\N	\N	103f5f5d-994d-4109-a6cd-27a95c273b8c	Abet	Dela Cruz		{}	f	f	afdbde1a-ee04-4e12-b712-e3580efc6479	b362ff69-237a-40dd-bc8f-c722c4516fde	f	f
65	f	albertopalmahechanova@gmail.com	t	t	pbkdf2_sha256$150000$ybxfJi49deEy$WMmYN2F9ZN75pvONd+O805Gw50OaHKvQpMSsS+urd2Y=	2020-09-24 04:59:15.779765+00	2020-11-12 10:20:52.985106+00	\N	\N		bf70e049-93e6-48dd-bd54-6eb6d9e72c00	Alberto	Hechanova		{}	f	f	a40f767a-f159-4f35-a1f7-bca94280a767	9ad7aa7e-4ca4-4e4b-948b-adc577580aad	t	f
88	f	digitaldelacruz@gmail.com	f	t		2020-10-28 07:58:30.711583+00	2020-11-20 08:58:04.660691+00	32	\N	\N	e9e8fb62-336c-449a-b7d9-310e0bb7e060	Abet	Dela Cruz		{}	f	f	c84dc68c-ff64-4894-b0d9-165fa8447e33	3632de6d-a344-4738-be62-ecd04e3fba7a	f	f
13	f	albertdc@inmyhouse.net	t	t	pbkdf2_sha256$150000$OUcs1HXn14X0$+OJAAxs6LFHOCOk8KXeK6OKDqHq69UfXpQOagliq02g=	2020-08-30 05:26:04.564712+00	2020-11-26 02:04:24.324166+00	\N	\N	\N	60b7e8f9-1fb7-4f1c-9ae4-72419c19581e	Albert	Dela Cruz		{}	f	f	f05bbf1e-fb73-4549-bbeb-325f1ff7d416	5f7a1ffa-200b-4bc8-bc25-8b92db2b73b8	t	f
49	f	kimmeirossflores@yahoo.com	f	t	pbkdf2_sha256$150000$G4hfc0tS2HW1$hV7K3f8s5IBoiIaOftPu+mbSU4y9BKlP3usrxjvbbfw=	2020-09-17 07:08:53.315197+00	2020-09-19 07:10:16.583454+00	\N	\N		063f9a34-b9a5-42fa-9a2b-91dba063f43e				{}	t	f	1f757de5-b704-4d3d-8561-c5ad0100d55b	727c5e51-0b57-4ceb-9cdc-797891b551c3	f	f
52	f	dailymedp@gmail.com	f	t	pbkdf2_sha256$150000$f4JrW3J02LQq$idVowVZLWi+q1Jkx70Kavm9eUIIp7x6umV6OMaS8edw=	2020-09-18 08:06:02.973271+00	2020-09-20 05:17:57.275234+00	\N	\N		6fab02dc-26ae-4a62-a220-985a01bc2251	Abegale	Vingno		{}	t	f	e835a310-b300-4a7f-84f6-3472470e0e55	2d7eadf0-36ba-445f-b58a-e439d32a6adf	f	f
64	f	farmacia4all@gmail.com	f	t	pbkdf2_sha256$150000$fMOXWEg2wsZ1$tLZ1FP84IH2vphVrIc5PXuR8k/6+VvoyHMIv027rPIw=	2020-09-22 08:10:43.950792+00	2020-09-30 06:22:33.813656+00	\N	\N		75f9141e-fe84-4d11-a184-8a74435d6944				{}	t	f	d8b2a1b2-9ae2-44aa-bd13-37d6b433c3c5	f512b4b3-9916-477c-9cd1-87262d8be2ee	f	f
54	f	embtongson@gmail.com	f	t	pbkdf2_sha256$150000$p2roW6KyV5kt$JhHcMN055ldT87Um3915ovT8f1RG5Q8YUodXUWJG4jk=	2020-09-19 07:28:58.220692+00	\N	\N	\N		7bb2d790-999d-4eff-b5d9-468fe7e8ab93				{}	t	f	da94aa3b-518b-46bc-a261-c51ad0206877	aa5d69a4-3e46-46e9-856d-15bfd2f72590	f	f
59	f	f_juruena91@yahoo.com.ph	f	t	pbkdf2_sha256$150000$NeI9jbtn8wqd$wMou3i/TWAqqnL5fBWoLNp9zGikHv2N/0224BKdq3n8=	2020-09-22 06:48:38.858738+00	\N	\N	\N		969f9a1e-6d82-4ca2-b663-9362b2b126ca				{}	t	f	2cdaec37-33e2-4193-9a51-b9fbe35e8d01	af59a809-19d6-4cb9-a36b-65c4ba854a4c	f	f
66	f	siatonjudy2@gmail.com	f	t	pbkdf2_sha256$150000$qnWE5xV9N3as$wpmoUhpolSQgop9HDX86fWXimJcEnA/7Eq/BSe9oy54=	2020-09-24 06:49:02.412326+00	\N	\N	\N		c8e07c2b-f196-4539-ab76-de9b974e81f5				{}	t	f	1eacb035-0beb-4435-9736-a667a00ef3f4	44e4a368-daca-461d-bc83-a11d1f882047	f	f
55	f	ramievillamor70@gmail.com	f	t	pbkdf2_sha256$150000$Bs5C7oQ3CS9k$bB8/3DKP3mHy6Q6vaVzvhPXlPBJV29eo3GSoaf46jg0=	2020-09-21 05:20:23.790734+00	\N	\N	\N		22f58d37-693e-4f77-96c2-45ae0ded1ca7				{}	t	f	e7e3b493-d06a-48b8-a8a0-109826e58973	2dea905e-6b40-4d14-986c-b03dd71c9218	f	f
45	f	supercaramart@gmail.com	f	t	pbkdf2_sha256$150000$wn8T8Bk6T66K$18odHSbq1qSLbPlhqmf07FEQdcCrP1EVhnoaSbJ7uZ0=	2020-09-17 00:16:16.613826+00	2020-09-22 07:01:51.035349+00	\N	\N		2845c7e6-46a0-4726-853c-4235812318c3				{}	t	f	7c082fc2-3565-477a-ad77-9ff3d18a4a4d	f395553c-a211-4b73-abe5-c3937c7dec12	f	f
53	f	triplekpharmacy01@gmail.com	f	t	pbkdf2_sha256$150000$vV6AOtFv9hmN$9Kx7+xRZrVmwHynSXm9QYPaH/sJu5QpBeDQKhSB2fWY=	2020-09-19 07:13:33.524852+00	2020-10-03 07:53:06.39851+00	\N	\N		76d7679e-4167-4cf0-8e9c-24e13b99fd39				{}	t	f	3cf65eac-7a29-453c-a44a-5f92f8d79dd0	bebf5211-83d4-4f4e-86dc-c46533599440	f	f
61	f	m_serrano1968@yahoo.com.ph	f	t	pbkdf2_sha256$150000$8wgXI3b7mRlW$hlEfAhj8ejw1pviJ+1ZXMkemlCllkJig1PDleaTQToQ=	2020-09-22 07:46:07.672542+00	2020-09-22 09:16:31.212168+00	\N	\N		c77fa597-ce5b-42aa-b39a-646f920ffaa3	Mildred	Serrano		{}	t	f	66e8e56e-b07a-4b39-9e7e-7b1996cc949b	12d551de-476e-458a-8112-028b4a482ab8	f	f
60	f	qnm.drugmart@gmail.com	f	t	pbkdf2_sha256$150000$BCbYWkHCGURG$avaTMCtR/aupSF9PLYFCvBYBCCgVeFw110ZJhCI6x7A=	2020-09-22 07:36:31.845595+00	2020-09-22 09:44:19.27227+00	\N	\N		4e8cf198-653a-483b-9bfa-e4423460f458				{}	t	f	63f82478-3778-4fca-a2be-7227cdb93772	ed73de9e-6dbf-4321-96bf-4626080da1f1	f	f
96	f	vivoru2@gmail.com	f	t	pbkdf2_sha256$150000$1FpquSpMclQt$TSbkTHiFb3O8rZspyLMhE8GO6dxAyP7S9kV1gfPf7No=	2020-11-03 02:17:49.251552+00	\N	\N	\N	\N	c81df8a8-1e05-43b6-8f4c-4feeed98c631				{}	f	f	9abeff34-e7a0-4343-bf85-05be675d75f3	d777977c-448a-4f95-abdc-32d74de2d565	t	f
83	f	khemaragon@gmail.com	f	t	pbkdf2_sha256$150000$s79V3uaEqw7M$RwK5CNFwXJWdRWaVLiITLCh6vnRP5HybxX4n6/cNnY8=	2020-10-12 01:46:48.467316+00	2020-10-15 03:05:17.615463+00	\N	\N		2143558c-4759-4788-b4fa-22085e51ac02				{}	t	f	652cfbde-3567-4628-81b3-a3f752a7c146	e9595cd4-4972-4b26-bf3d-7f7f2c163ac6	f	f
76	f	leovendevilles68@gmail.com	f	t	pbkdf2_sha256$150000$TDQpAZg9rWL7$DefZiVgOyu9Zy/mlR0vEI1vCy2ty40xp+yn/7yL6UB0=	2020-10-03 06:33:47.497592+00	2020-10-03 10:35:13.684266+00	\N	\N		db33471c-f91b-48fc-a0c4-1d2c4d8f3703	Leoven	Devilles		{}	t	f	51036ed7-8628-40d0-a713-33cfb826170b	4c1cddef-eda8-4b56-9564-464f9b782357	f	f
97	f	island0288@gmail.com	f	t		2020-11-06 06:56:28.788323+00	2020-11-06 06:56:28.81014+00	\N	\N	\N	6b79d93d-4c1c-4ffa-9e0b-ab21b0c813ca	Is	Landicho		{}	f	f	7f8c922e-3fd0-440c-b9aa-f15c68191c0a	58de7779-da15-4edb-b064-f409e6b341e0	f	f
92	f	alyssaclaire.h@outlook.com	f	t	pbkdf2_sha256$150000$cusnmzmcBVvO$29Y+GdeNJRU19FqQv8/Uagq73BqPmqDwXTdptpCFsUA=	2020-10-31 07:22:42.901999+00	2020-10-31 07:24:42.627237+00	\N	\N		0d6abf8d-a5d5-402c-848a-50ac3598a3a8				{}	f	f	f437d006-dc66-4641-b88d-c452abcf27bd	bc0e4230-15f3-425b-8a67-870a9a9d6365	f	f
40	f	drupphofficial@gmail.com	f	t	pbkdf2_sha256$150000$VJtuFRWXmBeu$cl5GzjFNEvqR8OAaOkU7xtnVfxvWLL+E/7BqzgLpA6s=	2020-09-15 08:44:24.43414+00	2020-11-25 02:52:24.282058+00	\N	\N		0a71741f-6d26-476d-86f7-884ec208e882	Michael Angelo D. Jr.	Malicsi		{}	t	f	0b31c5d3-d337-402c-a214-ee055f81328c	7726b961-a0d1-4656-a043-7acfe4972e50	f	f
90	f	ruedech.rt@gmail.com	f	t		2020-10-29 09:27:07.604777+00	2020-10-29 09:27:07.623696+00	\N	\N	\N	a8d8d7c5-504f-488d-bf62-539a5c89a3e0	Ruedech	Trd.		{}	f	f	ed9c2459-a92d-4e25-b3ca-9c37c5fda81a	90baa1b6-69ec-4416-b44c-0030c6c10146	f	f
95	f	charlie.drupph@gmail.com	f	t	pbkdf2_sha256$150000$lW9kkVapZaTs$kmXqTsbb05Y/4QxmWeNh0eBshuPQzGGXrTL7F65724M=	2020-11-02 22:59:24.710933+00	2020-11-27 15:19:46.188323+00	38	\N	\N	5ae23e9a-36a7-4c57-ae25-e00a63cc5f9e	Charleston	Villegas		{}	f	f	25475f80-7b09-4a64-8954-5deff3eb85d3	873e60f4-fc1c-406b-a790-48e05c79c851	f	f
109	f	2200436@slu.edu.ph	f	t		2020-11-14 15:03:03.586638+00	2020-11-14 15:03:03.605395+00	\N	\N	\N	bbc37b73-24bf-4607-83dc-591550f5ea06	MAVERICK ACE	MALICSI		{}	f	f	3d9c3e00-91b7-4564-8b94-007f5a476510	57418238-1baf-469b-9f6c-0e57c0944bde	f	f
89	f	lee.drupph@gmail.com	f	t	pbkdf2_sha256$150000$LUzHCdj8g99P$vupEba53R3BSfRqzdgs05zdEtiLnqoEyZyna/CjoF4U=	2020-10-29 01:42:29.164412+00	2020-11-27 15:20:09.358472+00	\N	\N		7318a50d-8e22-48fa-bbe4-974f5ec846a0	charleston	villegas		{}	t	f	d09669be-2f0f-4fcf-9497-1371b0befd11	8ddd3217-630c-498c-882a-cea482cde7ec	f	f
106	f	michaelmalicsi090398@gmail.com	f	t	pbkdf2_sha256$150000$G4OwTepK0dYU$a23SBks3Zuof9XQXT41oI5CBISu7k0kiM8XlZDyb2QI=	2020-11-12 12:38:10.16362+00	2020-11-14 15:05:52.387015+00	\N	\N		7dac2857-81f2-490c-9e98-fd8d0b1f74e6	Michael Angelo	Malicsi		{}	f	f	9bb4405f-c1e7-43f8-a261-c62143d1c8e9	eeb4810c-fb38-45ad-ba33-b2ffe69805e4	f	f
103	f	mestanislao@inmyhouse.net	f	t	pbkdf2_sha256$150000$eTMuyW9VqICn$CqS3i484pEovhpeOXc/9NW2PdbsIxCeyv4RAPRzOhsQ=	2020-11-11 14:40:04.185264+00	2020-11-14 09:51:30.843644+00	\N	\N	\N	3b0bfae0-79a1-4a64-8084-20d664f4131f	Michael	Estanislao		{}	f	f	902db9fb-6ebe-49e2-ae1f-9f79b6fbaf61	728ce04d-9750-42ef-8e35-ab472b191b7a	t	f
107	f	michaelangelo_malicsi@yahoo.com.ph	f	t	pbkdf2_sha256$150000$PGVreNrcgBmq$4iK+3bWGqsDSy0Rygg0QnAk5fD5mpzCmUUcYbN+oCVM=	2020-11-12 12:59:59.765862+00	\N	\N	\N		06074360-95cb-4004-8926-a5520dcfc94f				{}	f	f	1d82cd3e-f142-4d5c-b15d-1b29108e96b4	c1ad2afa-7a88-4df7-b554-e5191f3eac2c	f	f
91	f	charlestonvillegas@gmail.com	f	t		2020-10-30 00:40:18.086051+00	2020-11-18 06:49:39.454123+00	\N	\N	\N	4a51ee9e-5d29-4a79-8eaa-1a90e73e48f1	charleston	villegas		{}	f	f	e4a692f7-6af0-4d54-8b43-796bd96bace4	2da01ed9-b303-47d2-a4d8-8362c8986613	f	f
87	f	jacamed2019@gmail.com	f	t	pbkdf2_sha256$150000$uEf6JXMSwCgF$XFeRvw5zE29bSFkR4MdFb6NJJ63bdh50wwA47nmt3WA=	2020-10-22 03:36:53.422413+00	2020-11-28 07:27:19.811729+00	\N	\N		961d5205-fe6a-43fa-aa9f-7fba549fd50b				{}	t	f	811fd8ac-cfc3-4fad-a13e-957d01f5de8a	04d67f0a-a234-4250-b523-94e45d4fe3f0	f	f
94	f	charlestonz3r0@gmail.com	f	t	pbkdf2_sha256$150000$zjJWrNdh4zBH$cT6PeVvae/sdqyADiakNYV9gBK+2Uxe2vVrGjYejBas=	2020-10-31 19:26:51.435601+00	2020-11-18 06:55:14.623335+00	36	\N	\N	90698a7a-7a39-45e9-b881-fa49e8713e58	Charleston	Villegas		{}	f	f	ad6ed85b-507f-4d7e-a743-3ced930b51a8	b7de8ab7-7085-4cbd-bf31-463febb9c0e5	t	f
105	f	meestanislao@rigeltech.ph	f	t		2020-11-11 15:01:16.661997+00	2020-11-20 11:20:53.943424+00	\N	\N	\N	c352a385-9167-4983-8546-944204643939	Michael	Estanislao		{}	f	f	e0abd3c0-11aa-4321-acf1-29b496929f66	14727d31-ba90-4f48-bc39-21d958a2f92f	f	f
104	f	meeyome@gmail.com	f	t	pbkdf2_sha256$150000$YgJsZ1RyvnnP$8hovtBPIFwG00czVE7wiQWhNZeiiTA8/5qD5BpiG3fM=	2020-11-11 14:49:51.723988+00	2020-11-20 11:21:02.727133+00	\N	\N	\N	a6bcacb1-063e-465b-a508-1ac513f69d65	M	Estanislao		{}	f	f	0c04cef4-3b23-49b2-97fc-9e09c90b7f2c	0bad8055-3180-4a24-b8cf-2f0534dcedfc	f	f
98	f	charleston.drupph@gmail.com	f	t		2020-11-06 06:58:22.871685+00	2020-11-14 11:19:37.673118+00	34	\N	\N	fa6d4468-eb0c-4e5d-ad25-1de02d490570	Charleston	Villegas		{}	f	f	31ed72e7-1b52-4d88-9fa5-a5efdd0fdb2c	11fcf477-e50f-41bf-a32b-8462bfb8f8cb	f	f
108	f	doomznyt@gmail.com	f	t		2020-11-14 09:51:21.926124+00	2020-11-14 13:01:49.719428+00	\N	\N	\N	2f5ab730-b2ed-42a9-8283-3d9fbe50d0f6	M	Estanislao		{}	f	f	eca9d8e3-dd0f-4495-b242-3432ce5ca2fd	34af2ea6-f783-49a2-8945-1579c34b16f7	f	f
\.


--
-- Data for Name: account_user_addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_user_addresses (id, user_id, address_id) FROM stdin;
5	88	32
6	98	34
7	94	36
8	95	38
\.


--
-- Data for Name: account_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: account_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_user_user_permissions (id, user_id, permission_id) FROM stdin;
2	10	80
3	9	80
4	7	80
6	12	80
8	13	230
9	13	71
10	13	199
11	13	170
12	13	80
13	13	54
14	13	216
15	13	217
16	13	26
17	13	27
18	13	157
19	13	25
23	40	80
26	36	80
27	50	80
28	49	80
29	45	80
31	53	80
32	54	80
33	52	80
34	56	80
35	55	80
36	57	80
37	58	80
38	59	80
42	60	80
43	61	80
45	66	80
46	64	80
48	62	80
49	62	25
50	65	80
51	65	25
53	70	80
56	71	80
58	72	80
60	75	80
61	76	80
62	87	80
63	89	80
\.


--
-- Data for Name: account_userproducts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_userproducts (id, product_id, user_id) FROM stdin;
186	186	87
187	187	87
188	188	87
189	189	87
190	190	87
191	191	87
198	198	12
199	199	12
15	15	10
16	16	10
17	17	10
200	200	12
19	19	10
20	20	10
21	21	10
201	201	40
23	23	10
24	24	10
25	25	10
26	26	10
202	202	52
203	203	53
204	204	53
205	205	53
206	206	53
207	207	53
208	208	53
209	209	53
210	210	53
211	211	53
212	212	53
213	213	53
214	214	53
215	215	53
216	216	53
217	217	53
218	218	53
219	219	53
220	220	53
221	221	53
222	222	53
223	223	53
224	224	53
225	225	53
226	226	40
229	229	12
232	232	12
234	234	12
235	235	89
63	63	45
64	64	45
65	65	45
66	66	45
67	67	45
68	68	45
69	69	45
70	70	45
72	72	45
73	73	45
74	74	45
236	236	89
237	237	12
238	238	12
239	239	1
244	244	36
245	245	12
246	246	75
247	247	75
248	248	75
249	249	12
83	83	64
250	250	12
253	253	89
254	254	89
255	255	87
256	256	62
257	257	62
258	258	62
259	259	62
260	260	62
261	261	62
262	262	62
263	263	62
264	264	62
265	265	62
266	266	62
267	267	62
268	268	62
269	269	62
270	270	62
271	271	12
272	272	12
107	107	64
108	108	64
273	273	62
110	110	64
274	274	62
275	275	62
276	276	62
277	277	62
278	278	12
280	280	62
281	281	62
282	282	62
283	283	62
115	115	64
284	284	62
285	285	62
118	118	64
286	286	62
287	287	62
288	288	62
289	289	62
290	290	62
291	291	62
292	292	62
293	293	62
294	294	62
295	295	62
296	296	62
297	297	62
298	298	62
299	299	62
300	300	62
301	301	62
302	302	62
303	303	62
304	304	62
305	305	62
306	306	62
307	307	62
308	308	75
309	309	75
310	310	75
311	311	75
312	312	75
313	313	75
314	314	75
315	315	75
316	316	75
317	317	75
318	318	75
319	319	75
320	320	75
321	321	75
322	322	75
323	323	75
324	324	75
325	325	75
326	326	75
327	327	75
329	329	12
330	330	12
332	332	12
333	333	12
336	336	12
337	337	12
338	338	12
339	339	12
341	341	12
342	342	12
344	344	89
345	345	75
346	346	75
347	347	75
348	348	75
349	349	75
350	350	75
351	351	75
352	352	75
354	354	62
355	355	62
356	356	62
357	357	62
358	358	62
359	359	62
360	360	62
361	361	62
362	362	62
363	363	62
364	364	62
365	365	62
366	366	62
367	367	62
368	368	62
369	369	62
370	370	62
371	371	62
372	372	62
373	373	62
374	374	62
375	375	62
376	376	89
380	380	75
\.


--
-- Data for Name: account_userrequestform; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_userrequestform (id, request_type, request_fullfilled, user_id) FROM stdin;
55	Vendor	t	60
56	Vendor	t	61
7	Vendor	t	10
6	Vendor	t	9
5	Vendor	t	7
10	Customer	f	13
60	Vendor	t	66
58	Vendor	t	64
57	Vendor	t	62
9	Vendor	t	12
59	Customer	t	65
17	Vendor	f	\N
36	Vendor	t	\N
18	Vendor	f	\N
12	Vendor	t	\N
19	Vendor	f	\N
46	Vendor	t	\N
20	Vendor	f	\N
2	Vendor	t	\N
22	Vendor	f	\N
23	Vendor	f	\N
24	Vendor	f	\N
21	Vendor	f	\N
25	Vendor	f	\N
26	Vendor	f	\N
28	Vendor	f	\N
27	Vendor	f	\N
30	Vendor	f	\N
65	Vendor	t	71
31	Vendor	f	\N
63	Vendor	t	\N
32	Vendor	f	\N
62	Vendor	t	\N
16	Vendor	t	\N
8	Customer	t	\N
11	Customer	f	\N
1	Customer	t	\N
13	Customer	f	\N
14	Vendor	f	\N
4	Customer	f	\N
35	Vendor	f	\N
15	Customer	f	\N
29	Vendor	f	\N
34	Vendor	f	\N
3	Customer	t	\N
38	Vendor	t	\N
39	Vendor	t	\N
37	Vendor	t	40
69	Vendor	t	75
33	Vendor	t	36
43	Vendor	f	\N
40	Vendor	t	\N
45	Vendor	t	50
42	Vendor	t	45
49	Vendor	t	54
47	Vendor	t	52
41	Vendor	t	\N
51	Vendor	t	56
50	Vendor	t	55
52	Vendor	t	57
53	Vendor	t	58
54	Vendor	t	59
72	Vendor	f	\N
73	Vendor	f	\N
68	Vendor	t	\N
67	Vendor	t	\N
61	Vendor	t	\N
74	Customer	t	80
66	Vendor	t	72
70	Vendor	t	76
75	Vendor	f	\N
76	Vendor	f	\N
77	Vendor	f	\N
78	Vendor	f	\N
80	Vendor	t	87
71	Customer	f	\N
81	Vendor	t	89
82	Customer	t	92
48	Vendor	t	53
44	Vendor	t	49
64	Vendor	t	70
84	Customer	f	94
85	Customer	f	96
83	Customer	f	\N
86	Customer	f	\N
87	Customer	f	103
79	Vendor	t	\N
88	Customer	t	106
89	Customer	t	107
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add content type	1	add_contenttype
2	Can change content type	1	change_contenttype
3	Can delete content type	1	delete_contenttype
4	Can view content type	1	view_contenttype
5	Can add session	2	add_session
6	Can change session	2	change_session
7	Can delete session	2	delete_session
8	Can view session	2	view_session
9	Can add site	3	add_site
10	Can change site	3	change_site
11	Can delete site	3	delete_site
12	Can view site	3	view_site
13	Can add permission	4	add_permission
14	Can change permission	4	change_permission
15	Can delete permission	4	delete_permission
16	Can view permission	4	view_permission
17	Can add group	5	add_group
18	Can change group	5	change_group
19	Can delete group	5	delete_group
20	Can view group	5	view_group
21	Can add user	6	add_user
22	Can change user	6	change_user
23	Can delete user	6	delete_user
24	Can view user	6	view_user
25	Manage customers.	6	manage_users
26	Manage staff.	6	manage_staff
27	Impersonate customers.	6	impersonate_users
28	User is Vendor	6	is_vendor
29	User is Supplier	6	is_supplier
30	Can add address	7	add_address
31	Can change address	7	change_address
32	Can delete address	7	delete_address
33	Can view address	7	view_address
34	Can add customer note	8	add_customernote
35	Can change customer note	8	change_customernote
36	Can delete customer note	8	delete_customernote
37	Can view customer note	8	view_customernote
38	Can add customer event	9	add_customerevent
39	Can change customer event	9	change_customerevent
40	Can delete customer event	9	delete_customerevent
41	Can view customer event	9	view_customerevent
42	Can add user products	10	add_userproducts
43	Can change user products	10	change_userproducts
44	Can delete user products	10	delete_userproducts
45	Can view user products	10	view_userproducts
46	Can add user request form	11	add_userrequestform
47	Can change user request form	11	change_userrequestform
48	Can delete user request form	11	delete_userrequestform
49	Can view user request form	11	view_userrequestform
50	Can add sale	12	add_sale
51	Can change sale	12	change_sale
52	Can delete sale	12	delete_sale
53	Can view sale	12	view_sale
54	Manage sales and vouchers.	12	manage_discounts
55	Can add voucher	13	add_voucher
56	Can change voucher	13	change_voucher
57	Can delete voucher	13	delete_voucher
58	Can view voucher	13	view_voucher
59	Can add voucher translation	14	add_vouchertranslation
60	Can change voucher translation	14	change_vouchertranslation
61	Can delete voucher translation	14	delete_vouchertranslation
62	Can view voucher translation	14	view_vouchertranslation
63	Can add sale translation	15	add_saletranslation
64	Can change sale translation	15	change_saletranslation
65	Can delete sale translation	15	delete_saletranslation
66	Can view sale translation	15	view_saletranslation
67	Can add gift card	16	add_giftcard
68	Can change gift card	16	change_giftcard
69	Can delete gift card	16	delete_giftcard
70	Can view gift card	16	view_giftcard
71	Manage gift cards.	16	manage_gift_card
72	Can add category	17	add_category
73	Can change category	17	change_category
74	Can delete category	17	delete_category
75	Can view category	17	view_category
76	Can add product	18	add_product
77	Can change product	18	change_product
78	Can delete product	18	delete_product
79	Can view product	18	view_product
80	Manage products.	18	manage_products
81	Can add product image	19	add_productimage
82	Can change product image	19	change_productimage
83	Can delete product image	19	delete_productimage
84	Can view product image	19	view_productimage
85	Can add product variant	20	add_productvariant
86	Can change product variant	20	change_productvariant
87	Can delete product variant	20	delete_productvariant
88	Can view product variant	20	view_productvariant
89	Can add variant image	21	add_variantimage
90	Can change variant image	21	change_variantimage
91	Can delete variant image	21	delete_variantimage
92	Can view variant image	21	view_variantimage
93	Can add product type	22	add_producttype
94	Can change product type	22	change_producttype
95	Can delete product type	22	delete_producttype
96	Can view product type	22	view_producttype
97	Can add collection product	23	add_collectionproduct
98	Can change collection product	23	change_collectionproduct
99	Can delete collection product	23	delete_collectionproduct
100	Can view collection product	23	view_collectionproduct
101	Can add collection	24	add_collection
102	Can change collection	24	change_collection
103	Can delete collection	24	delete_collection
104	Can view collection	24	view_collection
105	Can add category translation	25	add_categorytranslation
106	Can change category translation	25	change_categorytranslation
107	Can delete category translation	25	delete_categorytranslation
108	Can view category translation	25	view_categorytranslation
109	Can add collection translation	26	add_collectiontranslation
110	Can change collection translation	26	change_collectiontranslation
111	Can delete collection translation	26	delete_collectiontranslation
112	Can view collection translation	26	view_collectiontranslation
113	Can add product translation	27	add_producttranslation
114	Can change product translation	27	change_producttranslation
115	Can delete product translation	27	delete_producttranslation
116	Can view product translation	27	view_producttranslation
117	Can add product variant translation	28	add_productvarianttranslation
118	Can change product variant translation	28	change_productvarianttranslation
119	Can delete product variant translation	28	delete_productvarianttranslation
120	Can view product variant translation	28	view_productvarianttranslation
121	Can add attribute	29	add_attribute
122	Can change attribute	29	change_attribute
123	Can delete attribute	29	delete_attribute
124	Can view attribute	29	view_attribute
125	Can add attribute value translation	30	add_attributevaluetranslation
126	Can change attribute value translation	30	change_attributevaluetranslation
127	Can delete attribute value translation	30	delete_attributevaluetranslation
128	Can view attribute value translation	30	view_attributevaluetranslation
129	Can add attribute value	31	add_attributevalue
130	Can change attribute value	31	change_attributevalue
131	Can delete attribute value	31	delete_attributevalue
132	Can view attribute value	31	view_attributevalue
133	Can add attribute translation	32	add_attributetranslation
134	Can change attribute translation	32	change_attributetranslation
135	Can delete attribute translation	32	delete_attributetranslation
136	Can view attribute translation	32	view_attributetranslation
137	Can add digital content	33	add_digitalcontent
138	Can change digital content	33	change_digitalcontent
139	Can delete digital content	33	delete_digitalcontent
140	Can view digital content	33	view_digitalcontent
141	Can add digital content url	34	add_digitalcontenturl
142	Can change digital content url	34	change_digitalcontenturl
143	Can delete digital content url	34	delete_digitalcontenturl
144	Can view digital content url	34	view_digitalcontenturl
145	Can add checkout	35	add_checkout
146	Can change checkout	35	change_checkout
147	Can delete checkout	35	delete_checkout
148	Can view checkout	35	view_checkout
149	Can add checkout line	36	add_checkoutline
150	Can change checkout line	36	change_checkoutline
151	Can delete checkout line	36	delete_checkoutline
152	Can view checkout line	36	view_checkoutline
153	Can add menu	37	add_menu
154	Can change menu	37	change_menu
155	Can delete menu	37	delete_menu
156	Can view menu	37	view_menu
157	Manage navigation.	37	manage_menus
158	Can add menu item	38	add_menuitem
159	Can change menu item	38	change_menuitem
160	Can delete menu item	38	delete_menuitem
161	Can view menu item	38	view_menuitem
162	Can add menu item translation	39	add_menuitemtranslation
163	Can change menu item translation	39	change_menuitemtranslation
164	Can delete menu item translation	39	delete_menuitemtranslation
165	Can view menu item translation	39	view_menuitemtranslation
166	Can add order	40	add_order
167	Can change order	40	change_order
168	Can delete order	40	delete_order
169	Can view order	40	view_order
170	Manage orders.	40	manage_orders
171	Can add order line	41	add_orderline
172	Can change order line	41	change_orderline
173	Can delete order line	41	delete_orderline
174	Can view order line	41	view_orderline
175	Can add fulfillment	42	add_fulfillment
176	Can change fulfillment	42	change_fulfillment
177	Can delete fulfillment	42	delete_fulfillment
178	Can view fulfillment	42	view_fulfillment
179	Can add fulfillment line	43	add_fulfillmentline
180	Can change fulfillment line	43	change_fulfillmentline
181	Can delete fulfillment line	43	delete_fulfillmentline
182	Can view fulfillment line	43	view_fulfillmentline
183	Can add order event	44	add_orderevent
184	Can change order event	44	change_orderevent
185	Can delete order event	44	delete_orderevent
186	Can view order event	44	view_orderevent
187	Can add shipping method	45	add_shippingmethod
188	Can change shipping method	45	change_shippingmethod
189	Can delete shipping method	45	delete_shippingmethod
190	Can view shipping method	45	view_shippingmethod
191	Can add shipping method translation	46	add_shippingmethodtranslation
192	Can change shipping method translation	46	change_shippingmethodtranslation
193	Can delete shipping method translation	46	delete_shippingmethodtranslation
194	Can view shipping method translation	46	view_shippingmethodtranslation
195	Can add shipping zone	47	add_shippingzone
196	Can change shipping zone	47	change_shippingzone
197	Can delete shipping zone	47	delete_shippingzone
198	Can view shipping zone	47	view_shippingzone
199	Manage shipping.	47	manage_shipping
200	Can add shipping province	48	add_shippingprovince
201	Can change shipping province	48	change_shippingprovince
202	Can delete shipping province	48	delete_shippingprovince
203	Can view shipping province	48	view_shippingprovince
204	Can add shipping cities	49	add_shippingcities
205	Can change shipping cities	49	change_shippingcities
206	Can delete shipping cities	49	delete_shippingcities
207	Can view shipping cities	49	view_shippingcities
208	Can add user shipping zone	50	add_usershippingzone
209	Can change user shipping zone	50	change_usershippingzone
210	Can delete user shipping zone	50	delete_usershippingzone
211	Can view user shipping zone	50	view_usershippingzone
212	Can add site settings	51	add_sitesettings
213	Can change site settings	51	change_sitesettings
214	Can delete site settings	51	delete_sitesettings
215	Can view site settings	51	view_sitesettings
216	Manage settings.	51	manage_settings
217	Manage translations.	51	manage_translations
218	Can add authorization key	52	add_authorizationkey
219	Can change authorization key	52	change_authorizationkey
220	Can delete authorization key	52	delete_authorizationkey
221	Can view authorization key	52	view_authorizationkey
222	Can add site settings translation	53	add_sitesettingstranslation
223	Can change site settings translation	53	change_sitesettingstranslation
224	Can delete site settings translation	53	delete_sitesettingstranslation
225	Can view site settings translation	53	view_sitesettingstranslation
226	Can add page	54	add_page
227	Can change page	54	change_page
228	Can delete page	54	delete_page
229	Can view page	54	view_page
230	Manage pages.	54	manage_pages
231	Can add page translation	55	add_pagetranslation
232	Can change page translation	55	change_pagetranslation
233	Can delete page translation	55	delete_pagetranslation
234	Can view page translation	55	view_pagetranslation
235	Can add transaction	56	add_transaction
236	Can change transaction	56	change_transaction
237	Can delete transaction	56	delete_transaction
238	Can view transaction	56	view_transaction
239	Can add payment	57	add_payment
240	Can change payment	57	change_payment
241	Can delete payment	57	delete_payment
242	Can view payment	57	view_payment
243	Can add store	58	add_store
244	Can change store	58	change_store
245	Can delete store	58	delete_store
246	Can view store	58	view_store
247	Can add business document	59	add_businessdocument
248	Can change business document	59	change_businessdocument
249	Can delete business document	59	delete_businessdocument
250	Can view business document	59	view_businessdocument
251	Can add temporary image	60	add_temporaryimage
252	Can change temporary image	60	change_temporaryimage
253	Can delete temporary image	60	delete_temporaryimage
254	Can view temporary image	60	view_temporaryimage
255	Can add color themes	61	add_colorthemes
256	Can change color themes	61	change_colorthemes
257	Can delete color themes	61	delete_colorthemes
258	Can view color themes	61	view_colorthemes
259	Can add carousel	62	add_carousel
260	Can change carousel	62	change_carousel
261	Can delete carousel	62	delete_carousel
262	Can view carousel	62	view_carousel
263	Can add carousel links	63	add_carousellinks
264	Can change carousel links	63	change_carousellinks
265	Can delete carousel links	63	delete_carousellinks
266	Can view carousel links	63	view_carousellinks
267	Can add conversion rate	64	add_conversionrate
268	Can change conversion rate	64	change_conversionrate
269	Can delete conversion rate	64	delete_conversionrate
270	Can view conversion rate	64	view_conversionrate
271	Can add vat	65	add_vat
272	Can change vat	65	change_vat
273	Can delete vat	65	delete_vat
274	Can view vat	65	view_vat
275	Can add rate types	66	add_ratetypes
276	Can change rate types	66	change_ratetypes
277	Can delete rate types	66	delete_ratetypes
278	Can view rate types	66	view_ratetypes
279	Can add association	67	add_association
280	Can change association	67	change_association
281	Can delete association	67	delete_association
282	Can view association	67	view_association
283	Can add code	68	add_code
284	Can change code	68	change_code
285	Can delete code	68	delete_code
286	Can view code	68	view_code
287	Can add nonce	69	add_nonce
288	Can change nonce	69	change_nonce
289	Can delete nonce	69	delete_nonce
290	Can view nonce	69	view_nonce
291	Can add user social auth	70	add_usersocialauth
292	Can change user social auth	70	change_usersocialauth
293	Can delete user social auth	70	delete_usersocialauth
294	Can view user social auth	70	view_usersocialauth
295	Can add partial	71	add_partial
296	Can change partial	71	change_partial
297	Can delete partial	71	delete_partial
298	Can view partial	71	view_partial
299	Can add impersonation log	72	add_impersonationlog
300	Can change impersonation log	72	change_impersonationlog
301	Can delete impersonation log	72	delete_impersonationlog
302	Can view impersonation log	72	view_impersonationlog
303	Can add Token	73	add_token
304	Can change Token	73	change_token
305	Can delete Token	73	delete_token
306	Can view Token	73	view_token
\.


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.


--
-- Data for Name: checkout_checkout; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.checkout_checkout (created, last_change, email, token, quantity, user_id, billing_address_id, discount_amount, discount_name, note, shipping_address_id, shipping_method_id, voucher_code, translated_discount_name) FROM stdin;
2020-10-02 11:14:04.541999+00	2020-10-02 11:14:04.54203+00		eff8e257-23e6-4968-9e29-716f2a286051	0	65	\N	0.00	\N		\N	\N	\N	\N
2020-11-18 06:52:56.061835+00	2020-11-18 06:52:56.061865+00		7caba231-ce48-43c7-8bd8-333c2b558db6	1	95	38	0.00	\N		\N	\N	\N	\N
2020-11-18 06:55:48.951201+00	2020-11-18 06:55:48.951229+00		7c44f8c7-bbd8-4d46-98b6-d972bf38b6d3	2	94	36	0.00	\N		\N	\N	\N	\N
2020-09-10 11:07:35.569923+00	2020-09-10 11:07:35.569953+00		91f37284-a5ea-453d-9c8c-2ac8c0789eb0	32	1	\N	0.00	\N		\N	\N	\N	\N
2020-10-31 07:25:09.042457+00	2020-10-31 07:25:09.042484+00		484da968-c0e1-40cc-83e6-9c534a5a9f7d	2	92	25	0.00	\N	1231321321	\N	\N	\N	\N
\.


--
-- Data for Name: checkout_checkout_gift_cards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.checkout_checkout_gift_cards (id, checkout_id, giftcard_id) FROM stdin;
\.


--
-- Data for Name: checkout_checkoutline; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.checkout_checkoutline (id, quantity, checkout_id, variant_id, data) FROM stdin;
14	1	484da968-c0e1-40cc-83e6-9c534a5a9f7d	232	{}
15	1	484da968-c0e1-40cc-83e6-9c534a5a9f7d	199	{}
20	1	7caba231-ce48-43c7-8bd8-333c2b558db6	233	{}
21	1	7c44f8c7-bbd8-4d46-98b6-d972bf38b6d3	233	{}
22	1	7c44f8c7-bbd8-4d46-98b6-d972bf38b6d3	16	{}
23	7	91f37284-a5ea-453d-9c8c-2ac8c0789eb0	269	{}
9	6	91f37284-a5ea-453d-9c8c-2ac8c0789eb0	184	{}
10	8	91f37284-a5ea-453d-9c8c-2ac8c0789eb0	186	{}
11	11	91f37284-a5ea-453d-9c8c-2ac8c0789eb0	65	{}
\.


--
-- Data for Name: discount_sale; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discount_sale (id, name, type, value, end_date, start_date) FROM stdin;
\.


--
-- Data for Name: discount_sale_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discount_sale_categories (id, sale_id, category_id) FROM stdin;
\.


--
-- Data for Name: discount_sale_collections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discount_sale_collections (id, sale_id, collection_id) FROM stdin;
\.


--
-- Data for Name: discount_sale_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discount_sale_products (id, sale_id, product_id) FROM stdin;
\.


--
-- Data for Name: discount_saletranslation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discount_saletranslation (id, language_code, name, sale_id) FROM stdin;
\.


--
-- Data for Name: discount_voucher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discount_voucher (id, type, name, code, usage_limit, used, start_date, end_date, discount_value_type, discount_value, min_amount_spent, apply_once_per_order, countries, min_checkout_items_quantity) FROM stdin;
\.


--
-- Data for Name: discount_voucher_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discount_voucher_categories (id, voucher_id, category_id) FROM stdin;
\.


--
-- Data for Name: discount_voucher_collections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discount_voucher_collections (id, voucher_id, collection_id) FROM stdin;
\.


--
-- Data for Name: discount_voucher_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discount_voucher_products (id, voucher_id, product_id) FROM stdin;
\.


--
-- Data for Name: discount_vouchertranslation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discount_vouchertranslation (id, language_code, name, voucher_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	contenttypes	contenttype
2	sessions	session
3	sites	site
4	auth	permission
5	auth	group
6	account	user
7	account	address
8	account	customernote
9	account	customerevent
10	account	userproducts
11	account	userrequestform
12	discount	sale
13	discount	voucher
14	discount	vouchertranslation
15	discount	saletranslation
16	giftcard	giftcard
17	product	category
18	product	product
19	product	productimage
20	product	productvariant
21	product	variantimage
22	product	producttype
23	product	collectionproduct
24	product	collection
25	product	categorytranslation
26	product	collectiontranslation
27	product	producttranslation
28	product	productvarianttranslation
29	product	attribute
30	product	attributevaluetranslation
31	product	attributevalue
32	product	attributetranslation
33	product	digitalcontent
34	product	digitalcontenturl
35	checkout	checkout
36	checkout	checkoutline
37	menu	menu
38	menu	menuitem
39	menu	menuitemtranslation
40	order	order
41	order	orderline
42	order	fulfillment
43	order	fulfillmentline
44	order	orderevent
45	shipping	shippingmethod
46	shipping	shippingmethodtranslation
47	shipping	shippingzone
48	shipping	shippingprovince
49	shipping	shippingcities
50	shipping	usershippingzone
51	site	sitesettings
52	site	authorizationkey
53	site	sitesettingstranslation
54	page	page
55	page	pagetranslation
56	payment	transaction
57	payment	payment
58	storefront	store
59	storefront	businessdocument
60	storefront	temporaryimage
61	storefront	colorthemes
62	portal	carousel
63	portal	carousellinks
64	django_prices_openexchangerates	conversionrate
65	django_prices_vatlayer	vat
66	django_prices_vatlayer	ratetypes
67	social_django	association
68	social_django	code
69	social_django	nonce
70	social_django	usersocialauth
71	social_django	partial
72	impersonate	impersonationlog
73	authtoken	token
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: drupphuser1
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	sites	0001_initial	2020-08-21 02:02:41.887745+00
2	sites	0002_alter_domain_unique	2020-08-21 02:02:41.899781+00
3	site	0001_initial	2020-08-21 02:02:41.913167+00
4	site	0002_add_default_data	2020-08-21 02:02:41.926359+00
5	site	0003_sitesettings_description	2020-08-21 02:02:41.936515+00
6	site	0004_auto_20170221_0426	2020-08-21 02:02:41.953644+00
7	site	0005_auto_20170906_0556	2020-08-21 02:02:41.964374+00
8	site	0006_auto_20171025_0454	2020-08-21 02:02:41.974992+00
9	site	0007_auto_20171027_0856	2020-08-21 02:02:41.992485+00
10	site	0008_auto_20171027_0856	2020-08-21 02:02:42.021749+00
11	site	0009_auto_20171109_0849	2020-08-21 02:02:42.029749+00
12	site	0010_auto_20171113_0958	2020-08-21 02:02:42.036488+00
13	site	0011_auto_20180108_0814	2020-08-21 02:02:42.059249+00
14	product	0001_initial	2020-08-21 02:02:42.181679+00
15	product	0002_auto_20150722_0545	2020-08-21 02:02:42.249204+00
16	product	0003_auto_20150820_2016	2020-08-21 02:02:42.271698+00
17	product	0003_auto_20150820_1955	2020-08-21 02:02:42.284049+00
18	product	0004_merge	2020-08-21 02:02:42.287534+00
19	product	0005_auto_20150825_1433	2020-08-21 02:02:42.339891+00
20	product	0006_product_updated_at	2020-08-21 02:02:42.352501+00
21	product	0007_auto_20160112_1025	2020-08-21 02:02:42.37315+00
22	product	0008_auto_20160114_0733	2020-08-21 02:02:42.408489+00
23	product	0009_discount_categories	2020-08-21 02:02:42.425185+00
24	product	0010_auto_20160129_0826	2020-08-21 02:02:42.460578+00
25	product	0011_stock_quantity_allocated	2020-08-21 02:02:42.473196+00
26	product	0012_auto_20160218_0812	2020-08-21 02:02:42.506137+00
27	product	0013_auto_20161207_0555	2020-08-21 02:02:42.534505+00
28	product	0014_auto_20161207_0840	2020-08-21 02:02:42.551557+00
29	product	0015_transfer_locations	2020-08-21 02:02:42.569393+00
30	product	0016_auto_20161207_0843	2020-08-21 02:02:42.588435+00
31	product	0017_remove_stock_location	2020-08-21 02:02:42.60224+00
32	product	0018_auto_20161207_0844	2020-08-21 02:02:42.634773+00
33	product	0019_auto_20161212_0230	2020-08-21 02:02:42.676988+00
34	product	0020_attribute_data_to_class	2020-08-21 02:02:42.717832+00
35	product	0021_add_hstore_extension	2020-08-21 05:00:55.64359+00
36	product	0022_auto_20161212_0301	2020-08-21 05:00:55.694519+00
37	product	0023_auto_20161211_1912	2020-08-21 05:00:55.709922+00
38	product	0024_migrate_json_data	2020-08-21 05:00:55.749836+00
39	product	0025_auto_20161219_0517	2020-08-21 05:00:55.759412+00
40	product	0026_auto_20161230_0347	2020-08-21 05:00:55.77225+00
41	product	0027_auto_20170113_0435	2020-08-21 05:00:55.823578+00
42	product	0013_auto_20161130_0608	2020-08-21 05:00:55.830387+00
43	product	0014_remove_productvariant_attributes	2020-08-21 05:00:55.844732+00
44	product	0015_productvariant_attributes	2020-08-21 05:00:55.860154+00
45	product	0016_auto_20161204_0311	2020-08-21 05:00:55.876233+00
46	product	0017_attributechoicevalue_slug	2020-08-21 05:00:55.887153+00
47	product	0018_auto_20161212_0725	2020-08-21 05:00:55.910784+00
48	product	0026_merge_20161221_0845	2020-08-21 05:00:55.914424+00
49	product	0028_merge_20170116_1016	2020-08-21 05:00:55.917641+00
50	product	0029_product_is_featured	2020-08-21 05:00:55.932565+00
51	product	0030_auto_20170206_0407	2020-08-21 05:00:56.091555+00
52	product	0031_auto_20170206_0601	2020-08-21 05:00:56.118287+00
53	product	0032_auto_20170216_0438	2020-08-21 05:00:56.129514+00
54	product	0033_auto_20170227_0757	2020-08-21 05:00:56.161158+00
55	product	0034_product_is_published	2020-08-21 05:00:56.176371+00
56	product	0035_auto_20170919_0846	2020-08-21 05:00:56.196964+00
57	product	0036_auto_20171115_0608	2020-08-21 05:00:56.207324+00
58	product	0037_auto_20171124_0847	2020-08-21 05:00:56.220366+00
59	product	0038_auto_20171129_0616	2020-08-21 05:00:56.250179+00
60	product	0037_auto_20171129_1004	2020-08-21 05:00:56.305724+00
61	product	0039_merge_20171130_0727	2020-08-21 05:00:56.309306+00
62	product	0040_auto_20171205_0428	2020-08-21 05:00:56.323935+00
63	product	0041_auto_20171205_0546	2020-08-21 05:00:56.338183+00
64	product	0042_auto_20171206_0501	2020-08-21 05:00:56.346983+00
65	product	0043_auto_20171207_0839	2020-08-21 05:00:56.358913+00
66	product	0044_auto_20180108_0814	2020-08-21 05:00:56.736389+00
67	product	0045_md_to_html	2020-08-21 05:00:56.756461+00
68	product	0046_product_category	2020-08-21 05:00:56.791628+00
69	product	0047_auto_20180117_0359	2020-08-21 05:00:56.828823+00
70	product	0048_product_class_to_type	2020-08-21 05:00:56.924914+00
71	product	0049_collection	2020-08-21 05:00:56.964644+00
72	product	0050_auto_20180131_0746	2020-08-21 05:00:56.992761+00
73	product	0051_auto_20180202_1106	2020-08-21 05:00:57.004691+00
74	product	0052_slug_field_length	2020-08-21 05:00:57.04087+00
75	page	0001_initial	2020-08-21 05:00:57.054526+00
76	menu	0001_initial	2020-08-21 05:00:57.085627+00
77	menu	0002_auto_20180319_0412	2020-08-21 05:00:57.138981+00
78	site	0012_auto_20180405_0757	2020-08-21 05:00:57.308968+00
79	menu	0003_auto_20180405_0854	2020-08-21 05:00:57.352942+00
80	site	0013_assign_default_menus	2020-08-21 05:00:57.381323+00
81	site	0014_handle_taxes	2020-08-21 05:00:57.408287+00
82	site	0015_sitesettings_handle_stock_by_default	2020-08-21 05:00:57.418878+00
83	site	0016_auto_20180719_0520	2020-08-21 05:00:57.427733+00
84	site	0017_auto_20180803_0528	2020-08-21 05:00:57.457542+00
85	product	0053_product_seo_description	2020-08-21 05:00:57.496176+00
86	product	0053_auto_20180305_1002	2020-08-21 05:00:57.516243+00
87	product	0054_merge_20180320_1108	2020-08-21 05:00:57.519413+00
88	product	0055_auto_20180321_0417	2020-08-21 05:00:57.572109+00
89	product	0056_auto_20180330_0321	2020-08-21 05:00:57.598506+00
90	product	0057_auto_20180403_0852	2020-08-21 05:00:57.614872+00
91	shipping	0001_initial	2020-08-21 05:00:57.637781+00
92	shipping	0002_auto_20160906_0741	2020-08-21 05:00:57.656861+00
93	shipping	0003_auto_20170116_0700	2020-08-21 05:00:57.663915+00
94	shipping	0004_auto_20170206_0407	2020-08-21 05:00:57.691953+00
95	shipping	0005_auto_20170906_0556	2020-08-21 05:00:57.699794+00
96	shipping	0006_auto_20171109_0908	2020-08-21 05:00:57.706061+00
97	shipping	0007_auto_20171129_1004	2020-08-21 05:00:57.715768+00
98	shipping	0008_auto_20180108_0814	2020-08-21 05:00:57.741186+00
99	contenttypes	0001_initial	2020-08-21 05:00:57.755008+00
100	contenttypes	0002_remove_content_type_name	2020-08-21 05:00:57.791295+00
101	auth	0001_initial	2020-08-21 05:00:57.823297+00
102	auth	0002_alter_permission_name_max_length	2020-08-21 05:00:57.848897+00
103	auth	0003_alter_user_email_max_length	2020-08-21 05:00:57.858958+00
104	auth	0004_alter_user_username_opts	2020-08-21 05:00:57.868522+00
105	auth	0005_alter_user_last_login_null	2020-08-21 05:00:57.878198+00
106	auth	0006_require_contenttypes_0002	2020-08-21 05:00:57.881623+00
107	userprofile	0001_initial	2020-08-21 05:00:57.951311+00
108	order	0001_initial	2020-08-21 05:00:58.125985+00
109	order	0002_auto_20150820_1955	2020-08-21 05:00:58.18194+00
110	order	0003_auto_20150825_1433	2020-08-21 05:00:58.212881+00
111	order	0004_order_total	2020-08-21 05:00:58.232413+00
112	order	0005_deliverygroup_last_updated	2020-08-21 05:00:58.250342+00
113	order	0006_deliverygroup_shipping_method	2020-08-21 05:00:58.267941+00
114	order	0007_deliverygroup_tracking_number	2020-08-21 05:00:58.294793+00
115	order	0008_auto_20151026_0820	2020-08-21 05:00:58.346867+00
116	order	0009_auto_20151201_0820	2020-08-21 05:00:58.418836+00
117	order	0010_auto_20160119_0541	2020-08-21 05:00:58.47345+00
118	discount	0001_initial	2020-08-21 05:00:58.516206+00
119	discount	0002_voucher	2020-08-21 05:00:58.57319+00
120	discount	0003_auto_20160207_0534	2020-08-21 05:00:58.732289+00
121	order	0011_auto_20160207_0534	2020-08-21 05:00:58.94392+00
122	order	0012_auto_20160216_1032	2020-08-21 05:00:58.999206+00
123	order	0013_auto_20160906_0741	2020-08-21 05:00:59.086808+00
124	order	0014_auto_20161028_0955	2020-08-21 05:00:59.113115+00
125	order	0015_auto_20170206_0407	2020-08-21 05:00:59.641399+00
126	order	0016_order_language_code	2020-08-21 05:00:59.666808+00
127	order	0017_auto_20170906_0556	2020-08-21 05:00:59.689041+00
128	order	0018_auto_20170919_0839	2020-08-21 05:00:59.711768+00
129	order	0019_auto_20171109_1423	2020-08-21 05:01:00.040103+00
130	order	0020_auto_20171123_0609	2020-08-21 05:01:00.112616+00
131	order	0021_auto_20171129_1004	2020-08-21 05:01:00.210476+00
132	order	0022_auto_20171205_0428	2020-08-21 05:01:00.248034+00
133	order	0023_auto_20171206_0506	2020-08-21 05:01:00.302554+00
134	order	0024_remove_order_status	2020-08-21 05:01:00.329461+00
135	order	0025_auto_20171214_1015	2020-08-21 05:01:00.364706+00
136	order	0026_auto_20171218_0428	2020-08-21 05:01:00.431815+00
137	order	0027_auto_20180108_0814	2020-08-21 05:01:01.308733+00
138	order	0028_status_fsm	2020-08-21 05:01:01.330121+00
139	order	0029_auto_20180111_0845	2020-08-21 05:01:01.386981+00
140	order	0030_auto_20180118_0605	2020-08-21 05:01:01.450555+00
141	order	0031_auto_20180119_0405	2020-08-21 05:01:01.534274+00
142	order	0032_orderline_is_shipping_required	2020-08-21 05:01:01.601885+00
143	order	0033_auto_20180123_0832	2020-08-21 05:01:01.625898+00
144	order	0034_auto_20180221_1056	2020-08-21 05:01:01.682989+00
145	order	0035_auto_20180221_1057	2020-08-21 05:01:01.731723+00
146	order	0036_remove_order_total_tax	2020-08-21 05:01:01.758901+00
147	order	0037_auto_20180228_0450	2020-08-21 05:01:01.844647+00
148	order	0038_auto_20180228_0451	2020-08-21 05:01:01.894611+00
149	order	0039_auto_20180312_1203	2020-08-21 05:01:01.952553+00
150	order	0040_auto_20180210_0422	2020-08-21 05:01:02.215126+00
151	order	0041_auto_20180222_0458	2020-08-21 05:01:02.465666+00
152	order	0042_auto_20180227_0436	2020-08-21 05:01:02.595612+00
153	order	0043_auto_20180322_0655	2020-08-21 05:01:02.641241+00
154	order	0044_auto_20180326_1055	2020-08-21 05:01:02.815435+00
155	order	0045_auto_20180329_0142	2020-08-21 05:01:02.988914+00
156	product	0058_auto_20180329_0142	2020-08-21 05:01:03.128987+00
157	product	0059_generate_variant_name_from_attrs	2020-08-21 05:01:03.176289+00
158	product	0060_collection_is_published	2020-08-21 05:01:03.196076+00
159	product	0061_product_taxes	2020-08-21 05:01:03.241839+00
160	product	0062_sortable_models	2020-08-21 05:01:03.351228+00
161	product	0063_required_attr_value_order	2020-08-21 05:01:03.373335+00
162	product	0064_productvariant_handle_stock	2020-08-21 05:01:03.390063+00
163	product	0065_auto_20180719_0520	2020-08-21 05:01:03.408615+00
164	product	0066_auto_20180803_0528	2020-08-21 05:01:03.595959+00
165	site	0018_sitesettings_homepage_collection	2020-08-21 05:01:03.885149+00
166	product	0067_remove_product_is_featured	2020-08-21 05:01:03.908923+00
167	product	0068_auto_20180822_0720	2020-08-21 05:01:03.951873+00
168	product	0069_auto_20180912_0326	2020-08-21 05:01:03.965019+00
169	product	0070_auto_20180912_0329	2020-08-21 05:01:03.98909+00
170	product	0071_attributechoicevalue_value	2020-08-21 05:01:04.003687+00
171	product	0072_auto_20180925_1048	2020-08-21 05:01:04.316547+00
172	product	0073_auto_20181010_0729	2020-08-21 05:01:04.372599+00
173	product	0074_auto_20181010_0730	2020-08-21 05:01:04.531242+00
174	product	0075_auto_20181010_0842	2020-08-21 05:01:04.576749+00
175	product	0076_auto_20181012_1146	2020-08-21 05:01:04.592687+00
176	product	0077_generate_versatile_background_images	2020-08-21 05:01:04.649723+00
177	product	0078_auto_20181120_0437	2020-08-21 05:01:04.679119+00
178	product	0079_default_tax_rate_instead_of_empty_field	2020-08-21 05:01:04.735434+00
179	product	0080_collection_published_date	2020-08-21 05:01:04.751962+00
180	product	0080_auto_20181214_0440	2020-08-21 05:01:04.781766+00
181	product	0081_merge_20181215_1659	2020-08-21 05:01:04.785773+00
182	product	0081_auto_20181218_0024	2020-08-21 05:01:04.80091+00
183	product	0082_merge_20181219_1440	2020-08-21 05:01:04.804808+00
184	product	0083_auto_20190104_0443	2020-08-21 05:01:04.82983+00
185	product	0084_auto_20190122_0113	2020-08-21 05:01:04.850243+00
186	product	0085_auto_20190125_0025	2020-08-21 05:01:04.860685+00
187	product	0086_product_publication_date	2020-08-21 05:01:04.88278+00
188	product	0087_auto_20190208_0326	2020-08-21 05:01:04.902381+00
189	product	0088_auto_20190220_1928	2020-08-21 05:01:04.918155+00
190	product	0089_auto_20190225_0252	2020-08-21 05:01:05.014241+00
191	product	0090_auto_20190328_0608	2020-08-21 05:01:05.035659+00
192	order	0046_order_line_taxes	2020-08-21 05:01:05.087024+00
193	order	0047_order_line_name_length	2020-08-21 05:01:05.111921+00
194	order	0048_auto_20180629_1055	2020-08-21 05:01:05.381932+00
195	order	0049_auto_20180719_0520	2020-08-21 05:01:05.411843+00
196	order	0050_auto_20180803_0528	2020-08-21 05:01:05.461801+00
197	order	0050_auto_20180803_0337	2020-08-21 05:01:05.508607+00
198	order	0051_merge_20180807_0704	2020-08-21 05:01:05.514528+00
199	order	0052_auto_20180822_0720	2020-08-21 05:01:05.576571+00
200	order	0053_orderevent	2020-08-21 05:01:05.612151+00
201	order	0054_move_data_to_order_events	2020-08-21 05:01:05.72141+00
202	order	0055_remove_order_note_order_history_entry	2020-08-21 05:01:05.860119+00
203	order	0056_auto_20180911_1541	2020-08-21 05:01:05.882188+00
204	order	0057_orderevent_parameters_new	2020-08-21 05:01:05.954238+00
205	order	0058_remove_orderevent_parameters	2020-08-21 05:01:05.97627+00
206	order	0059_auto_20180913_0841	2020-08-21 05:01:06.008505+00
207	order	0060_auto_20180919_0731	2020-08-21 05:01:06.033825+00
208	order	0061_auto_20180920_0859	2020-08-21 05:01:06.055694+00
209	order	0062_auto_20180921_0949	2020-08-21 05:01:06.107303+00
210	order	0063_auto_20180926_0446	2020-08-21 05:01:06.130937+00
211	order	0064_auto_20181016_0819	2020-08-21 05:01:06.165715+00
212	cart	0001_initial	2020-08-21 05:01:06.252844+00
213	cart	0002_auto_20161014_1221	2020-08-21 05:01:06.320971+00
214	cart	fix_empty_data_in_lines	2020-08-21 05:01:06.576491+00
215	cart	0001_auto_20170113_0435	2020-08-21 05:01:06.632753+00
216	cart	0002_auto_20170206_0407	2020-08-21 05:01:06.821454+00
217	cart	0003_auto_20170906_0556	2020-08-21 05:01:06.84302+00
218	cart	0004_auto_20171129_1004	2020-08-21 05:01:06.876676+00
219	cart	0005_auto_20180108_0814	2020-08-21 05:01:07.181019+00
220	cart	0006_auto_20180221_0825	2020-08-21 05:01:07.20608+00
221	userprofile	0002_auto_20150907_0602	2020-08-21 05:01:07.247411+00
222	userprofile	0003_auto_20151104_1102	2020-08-21 05:01:07.274953+00
223	userprofile	0004_auto_20160114_0419	2020-08-21 05:01:07.292322+00
224	userprofile	0005_auto_20160205_0651	2020-08-21 05:01:07.319207+00
225	userprofile	0006_auto_20160829_0819	2020-08-21 05:01:07.35371+00
226	userprofile	0007_auto_20161115_0940	2020-08-21 05:01:07.382189+00
227	userprofile	0008_auto_20161115_1011	2020-08-21 05:01:07.400483+00
228	userprofile	0009_auto_20170206_0407	2020-08-21 05:01:07.484379+00
229	userprofile	0010_auto_20170919_0839	2020-08-21 05:01:07.507178+00
230	userprofile	0011_auto_20171110_0552	2020-08-21 05:01:07.528459+00
231	userprofile	0012_auto_20171117_0846	2020-08-21 05:01:07.549569+00
232	userprofile	0013_auto_20171120_0521	2020-08-21 05:01:07.614357+00
233	userprofile	0014_auto_20171129_1004	2020-08-21 05:01:07.643729+00
234	userprofile	0015_auto_20171213_0734	2020-08-21 05:01:07.659879+00
235	userprofile	0016_auto_20180108_0814	2020-08-21 05:01:08.168344+00
236	account	0017_auto_20180206_0957	2020-08-21 05:01:08.20205+00
237	account	0018_auto_20180426_0641	2020-08-21 05:01:08.287054+00
238	account	0019_auto_20180528_1205	2020-08-21 05:01:08.341976+00
239	checkout	0007_merge_cart_with_checkout	2020-08-21 05:01:08.722254+00
240	checkout	0008_rename_tables	2020-08-21 05:01:08.777606+00
241	checkout	0009_cart_translated_discount_name	2020-08-21 05:01:08.79935+00
242	checkout	0010_auto_20180822_0720	2020-08-21 05:01:08.837901+00
243	checkout	0011_auto_20180913_0817	2020-08-21 05:01:08.935909+00
244	checkout	0012_remove_cartline_data	2020-08-21 05:01:08.962104+00
245	checkout	0013_auto_20180913_0841	2020-08-21 05:01:09.016192+00
246	checkout	0014_auto_20180921_0751	2020-08-21 05:01:09.271498+00
247	checkout	0015_auto_20181017_1346	2020-08-21 05:01:09.293117+00
248	payment	0001_initial	2020-08-21 05:01:09.37138+00
249	payment	0002_transfer_payment_to_payment_method	2020-08-21 05:01:09.440906+00
250	order	0065_auto_20181017_1346	2020-08-21 05:01:09.594416+00
251	order	0066_auto_20181023_0319	2020-08-21 05:01:09.648852+00
252	order	0067_auto_20181102_1054	2020-08-21 05:01:09.672218+00
253	order	0068_order_checkout_token	2020-08-21 05:01:09.697897+00
254	order	0069_auto_20190225_2305	2020-08-21 05:01:09.714153+00
255	product	0091_auto_20190402_0853	2020-08-21 05:01:09.7949+00
256	product	0092_auto_20190507_0309	2020-08-21 05:01:09.844336+00
257	product	0093_auto_20190521_0124	2020-08-21 05:01:09.930855+00
258	product	0094_auto_20190618_0430	2020-08-21 05:01:09.963383+00
259	product	0095_auto_20190618_0842	2020-08-21 05:01:10.041977+00
260	order	0070_drop_update_event_and_rename_events	2020-08-21 05:01:10.187374+00
261	account	0020_user_token	2020-08-21 05:01:10.210438+00
262	account	0021_unique_token	2020-08-21 05:01:10.485799+00
263	account	0022_auto_20180718_0956	2020-08-21 05:01:10.508027+00
264	account	0023_auto_20180719_0520	2020-08-21 05:01:10.527142+00
265	account	0024_auto_20181011_0737	2020-08-21 05:01:10.568528+00
266	account	0025_auto_20190314_0550	2020-08-21 05:01:10.584651+00
267	account	0026_user_avatar	2020-08-21 05:01:10.607138+00
268	account	0027_customerevent	2020-08-21 05:01:10.641208+00
269	account	0028_user_private_meta	2020-08-21 05:01:10.671111+00
270	account	0029_userproducts	2020-08-21 05:01:10.70149+00
271	account	0030_auto_20190718_1911	2020-08-21 05:01:10.742967+00
272	account	0031_user_is_vendor	2020-08-21 05:01:10.766996+00
273	account	0032_userstore	2020-08-21 05:01:10.799561+00
274	account	0033_auto_20190802_0608	2020-08-21 05:01:10.849866+00
275	account	0034_delete_userstore	2020-08-21 05:01:10.861691+00
276	account	0035_user_is_supplier	2020-08-21 05:01:10.885105+00
277	account	0036_userrequestform	2020-08-21 05:01:10.916037+00
278	account	0037_auto_20190821_1444	2020-08-21 05:01:10.955049+00
279	account	0038_auto_20190827_1410	2020-08-21 05:01:10.977439+00
280	account	0039_auto_20190924_0221	2020-08-21 05:01:11.013041+00
281	account	0040_user_jwt_secret	2020-08-21 05:01:11.037826+00
282	account	0041_auto_20191107_0956	2020-08-21 05:01:11.084475+00
283	account	0042_auto_20191107_1000	2020-08-21 05:01:11.129356+00
284	account	0043_auto_20191107_1318	2020-08-21 05:01:11.192056+00
285	account	0044_auto_20191107_1533	2020-08-21 05:01:11.240527+00
286	account	0045_auto_20191107_2120	2020-08-21 05:01:11.283114+00
287	auth	0007_alter_validators_add_error_messages	2020-08-21 05:01:11.300693+00
288	auth	0008_alter_user_username_max_length	2020-08-21 05:01:11.31725+00
289	auth	0009_alter_user_last_name_max_length	2020-08-21 05:01:11.336945+00
290	auth	0010_alter_group_name_max_length	2020-08-21 05:01:11.354908+00
291	auth	0011_update_proxy_permissions	2020-08-21 05:01:11.415106+00
292	authtoken	0001_initial	2020-08-21 05:01:11.448721+00
293	authtoken	0002_auto_20160226_1747	2020-08-21 05:01:11.538584+00
294	giftcard	0001_initial	2020-08-21 05:01:11.575955+00
295	shipping	0009_auto_20180629_1055	2020-08-21 05:01:11.59465+00
296	shipping	0010_auto_20180719_0520	2020-08-21 05:01:11.60517+00
297	shipping	0011_auto_20180802_1238	2020-08-21 05:01:11.617477+00
298	shipping	0012_remove_legacy_shipping_methods	2020-08-21 05:01:11.680306+00
299	shipping	0013_auto_20180822_0721	2020-08-21 05:01:11.882458+00
300	shipping	0014_auto_20180920_0956	2020-08-21 05:01:11.913654+00
301	shipping	0015_auto_20190305_0640	2020-08-21 05:01:11.926284+00
302	payment	0003_rename_payment_method_to_payment	2020-08-21 05:01:12.350573+00
303	payment	0004_auto_20181206_0031	2020-08-21 05:01:12.374484+00
304	payment	0005_auto_20190104_0443	2020-08-21 05:01:12.400102+00
305	payment	0006_auto_20190109_0358	2020-08-21 05:01:12.415059+00
306	payment	0007_auto_20190206_0938	2020-08-21 05:01:12.434854+00
307	payment	0007_auto_20190125_0242	2020-08-21 05:01:12.459747+00
308	payment	0008_merge_20190214_0447	2020-08-21 05:01:12.464198+00
309	payment	0009_convert_to_partially_charged_and_partially_refunded	2020-08-21 05:01:12.528406+00
310	payment	0010_auto_20190220_2001	2020-08-21 05:01:12.552243+00
311	checkout	0016_auto_20190112_0506	2020-08-21 05:01:12.579356+00
312	checkout	0017_auto_20190130_0207	2020-08-21 05:01:12.603936+00
313	checkout	0018_auto_20190410_0132	2020-08-21 05:01:12.947338+00
314	checkout	0019_checkout_gift_cards	2020-08-21 05:01:12.992971+00
315	discount	0004_auto_20170206_0407	2020-08-21 05:01:13.52978+00
316	discount	0005_auto_20170919_0839	2020-08-21 05:01:13.562056+00
317	discount	0006_auto_20171129_1004	2020-08-21 05:01:13.595869+00
318	discount	0007_auto_20180108_0814	2020-08-21 05:01:13.994153+00
319	discount	0008_sale_collections	2020-08-21 05:01:14.048607+00
320	discount	0009_auto_20180719_0520	2020-08-21 05:01:14.095566+00
321	discount	0010_auto_20180724_1251	2020-08-21 05:01:14.693444+00
322	discount	0011_auto_20180803_0528	2020-08-21 05:01:14.801026+00
323	discount	0012_auto_20190329_0836	2020-08-21 05:01:14.874768+00
324	discount	0013_auto_20190618_0733	2020-08-21 05:01:14.971905+00
325	discount	0014_auto_20190701_0402	2020-08-21 05:01:15.064531+00
326	discount	0015_voucher_min_quantity_of_products	2020-08-21 05:01:15.091305+00
327	django_prices_openexchangerates	0001_initial	2020-08-21 05:01:15.103856+00
328	django_prices_openexchangerates	0002_auto_20160329_0702	2020-08-21 05:01:15.12061+00
329	django_prices_openexchangerates	0003_auto_20161018_0707	2020-08-21 05:01:15.141942+00
330	django_prices_openexchangerates	0004_auto_20170316_0944	2020-08-21 05:01:15.154322+00
331	django_prices_vatlayer	0001_initial	2020-08-21 05:01:15.167501+00
332	django_prices_vatlayer	0002_ratetypes	2020-08-21 05:01:15.180809+00
333	django_prices_vatlayer	0003_auto_20180316_1053	2020-08-21 05:01:15.194588+00
334	giftcard	0002_auto_20190720_2041	2020-08-21 05:01:15.243764+00
335	giftcard	0003_auto_20191114_0152	2020-08-21 05:01:15.290302+00
336	giftcard	0004_auto_20191129_1109	2020-08-21 05:01:15.338445+00
337	giftcard	0005_auto_20191201_0113	2020-08-21 05:01:15.387737+00
338	giftcard	0006_auto_20191222_1813	2020-08-21 05:01:15.435442+00
339	giftcard	0007_auto_20191223_1839	2020-08-21 05:01:15.482519+00
340	giftcard	0008_auto_20191230_1047	2020-08-21 05:01:15.530348+00
341	giftcard	0009_auto_20200116_2330	2020-08-21 05:01:15.57995+00
342	giftcard	0010_auto_20200121_1035	2020-08-21 05:01:15.626543+00
343	giftcard	0011_auto_20200129_0131	2020-08-21 05:01:15.675638+00
344	giftcard	0012_auto_20200206_0641	2020-08-21 05:01:15.724189+00
345	impersonate	0001_initial	2020-08-21 05:01:15.772873+00
346	menu	0004_sort_order_index	2020-08-21 05:01:16.003322+00
347	menu	0005_auto_20180719_0520	2020-08-21 05:01:16.01571+00
348	menu	0006_auto_20180803_0528	2020-08-21 05:01:16.073001+00
349	menu	0007_auto_20180807_0547	2020-08-21 05:01:16.162216+00
350	menu	0008_menu_json_content_new	2020-08-21 05:01:16.245079+00
351	menu	0009_remove_menu_json_content	2020-08-21 05:01:16.256333+00
352	menu	0010_auto_20180913_0841	2020-08-21 05:01:16.283885+00
353	menu	0011_auto_20181204_0004	2020-08-21 05:01:16.295163+00
354	menu	0012_auto_20190104_0443	2020-08-21 05:01:16.306173+00
355	menu	0013_auto_20190507_0309	2020-08-21 05:01:16.384003+00
356	menu	0014_auto_20190523_0759	2020-08-21 05:01:16.409364+00
357	order	0071_order_gift_cards	2020-08-21 05:01:16.465097+00
358	order	0072_order_pickup_datetime	2020-08-21 05:01:16.51745+00
359	order	0073_orderevent_additional_note	2020-08-21 05:01:16.551549+00
360	page	0002_auto_20180321_0417	2020-08-21 05:01:16.570093+00
361	page	0003_auto_20180719_0520	2020-08-21 05:01:16.580561+00
362	page	0004_auto_20180803_0528	2020-08-21 05:01:16.640783+00
363	page	0005_auto_20190208_0456	2020-08-21 05:01:16.73437+00
364	page	0006_auto_20190220_1928	2020-08-21 05:01:16.746639+00
365	page	0007_auto_20190225_0252	2020-08-21 05:01:16.78439+00
366	payment	0011_auto_20190516_0901	2020-08-21 05:01:16.801374+00
367	payment	0012_transaction_customer_id	2020-08-21 05:01:16.821007+00
368	payment	0013_auto_20190827_1410	2020-08-21 05:01:16.851563+00
369	portal	0001_initial	2020-08-21 05:01:16.865143+00
370	portal	0002_auto_20200121_1242	2020-08-21 05:01:16.888929+00
371	product	0096_auto_20190724_1702	2020-08-21 05:01:16.919953+00
372	product	0097_auto_20190729_0554	2020-08-21 05:01:16.943973+00
373	product	0098_auto_20190729_0610	2020-08-21 05:01:16.966265+00
374	product	0099_producttype_user	2020-08-21 05:01:17.013946+00
375	product	0100_auto_20191015_0750	2020-08-21 05:01:17.070543+00
376	product	0101_auto_20200124_2309	2020-08-21 05:01:17.098714+00
377	product	0102_auto_20200129_0131	2020-08-21 05:01:17.121678+00
378	product	0103_auto_20200206_0641	2020-08-21 05:01:17.167273+00
379	sessions	0001_initial	2020-08-21 05:01:17.18042+00
380	shipping	0016_shippingmethod_meta	2020-08-21 05:01:17.203569+00
381	shipping	0017_shippingcities	2020-08-21 05:01:17.245041+00
382	shipping	0018_delete_shippingcities	2020-08-21 05:01:17.259387+00
383	shipping	0019_shippingcities_shippingprovince	2020-08-21 05:01:17.540416+00
384	shipping	0020_usershippingzone	2020-08-21 05:01:17.592601+00
385	shipping	0021_auto_20190822_1704	2020-08-21 05:01:17.616687+00
386	site	0019_sitesettings_default_weight_unit	2020-08-21 05:01:17.64192+00
387	site	0020_auto_20190301_0336	2020-08-21 05:01:17.662771+00
388	site	0021_auto_20190326_0521	2020-08-21 05:01:17.72235+00
389	site	0022_sitesettings_company_address	2020-08-21 05:01:17.770747+00
390	default	0001_initial	2020-08-21 05:01:17.897098+00
391	social_auth	0001_initial	2020-08-21 05:01:17.899379+00
392	default	0002_add_related_name	2020-08-21 05:01:17.960253+00
393	social_auth	0002_add_related_name	2020-08-21 05:01:17.962422+00
394	default	0003_alter_email_max_length	2020-08-21 05:01:17.973959+00
395	social_auth	0003_alter_email_max_length	2020-08-21 05:01:17.975965+00
396	default	0004_auto_20160423_0400	2020-08-21 05:01:18.003132+00
397	social_auth	0004_auto_20160423_0400	2020-08-21 05:01:18.005484+00
398	social_auth	0005_auto_20160727_2333	2020-08-21 05:01:18.018458+00
399	social_django	0006_partial	2020-08-21 05:01:18.036269+00
400	social_django	0007_code_timestamp	2020-08-21 05:01:18.053955+00
401	social_django	0008_partial_timestamp	2020-08-21 05:01:18.068012+00
402	storefront	0001_initial	2020-08-21 05:01:18.122528+00
403	storefront	0002_auto_20190804_0006	2020-08-21 05:01:18.157638+00
404	storefront	0003_auto_20190804_0029	2020-08-21 05:01:18.1911+00
405	storefront	0004_auto_20190804_0552	2020-08-21 05:01:18.278001+00
406	storefront	0005_auto_20190804_0613	2020-08-21 05:01:18.307315+00
407	storefront	0006_auto_20190807_1349	2020-08-21 05:01:18.362683+00
408	storefront	0007_auto_20190814_1056	2020-08-21 05:01:18.44331+00
409	storefront	0008_store_store_address	2020-08-21 05:01:18.494013+00
410	storefront	0009_auto_20190815_0035	2020-08-21 05:01:18.553924+00
411	storefront	0010_auto_20190815_1130	2020-08-21 05:01:18.610285+00
412	storefront	0011_auto_20190815_1132	2020-08-21 05:01:18.665287+00
413	storefront	0012_auto_20190819_1636	2020-08-21 05:01:18.696236+00
414	storefront	0013_delete_store	2020-08-21 05:01:18.705714+00
415	storefront	0014_store	2020-08-21 05:01:18.993482+00
416	storefront	0015_businessdocument	2020-08-21 05:01:19.05646+00
417	storefront	0016_auto_20190902_0659	2020-08-21 05:01:19.090919+00
418	storefront	0016_auto_20190901_2002	2020-08-21 05:01:19.120665+00
419	storefront	0017_merge_20190902_0709	2020-08-21 05:01:19.124374+00
420	storefront	0018_store_dsap	2020-08-21 05:01:19.157418+00
421	storefront	0019_temporaryimage	2020-08-21 05:01:19.212475+00
422	storefront	0020_auto_20191012_0941	2020-08-21 05:01:19.251051+00
423	storefront	0021_auto_20191016_1229	2020-08-21 05:01:19.403411+00
424	storefront	0022_auto_20191017_1958	2020-08-21 05:01:19.431908+00
425	storefront	0023_store_operating_hours	2020-08-21 05:01:19.459383+00
426	storefront	0024_auto_20191022_1959	2020-08-21 05:01:19.491897+00
427	storefront	0025_auto_20191024_0028	2020-08-21 05:01:19.517444+00
428	storefront	0026_auto_20191024_1045	2020-08-21 05:01:19.540071+00
429	storefront	0027_auto_20191223_0125	2020-08-21 05:01:19.574322+00
430	storefront	0028_auto_20191223_0139	2020-08-21 05:01:19.609036+00
431	storefront	0029_auto_20191223_0221	2020-08-21 05:01:19.643909+00
432	storefront	0030_auto_20191230_1047	2020-08-21 05:01:19.690097+00
433	storefront	0031_auto_20200101_0104	2020-08-21 05:01:19.737836+00
434	storefront	0032_store_storename_sticky	2020-08-21 05:01:19.763092+00
435	account	0010_auto_20170919_0839	2020-08-21 05:01:19.76891+00
436	account	0012_auto_20171117_0846	2020-08-21 05:01:19.774286+00
437	account	0014_auto_20171129_1004	2020-08-21 05:01:19.779386+00
438	account	0005_auto_20160205_0651	2020-08-21 05:01:19.782126+00
439	account	0007_auto_20161115_0940	2020-08-21 05:01:19.784505+00
440	account	0009_auto_20170206_0407	2020-08-21 05:01:19.786948+00
441	account	0016_auto_20180108_0814	2020-08-21 05:01:19.7894+00
442	account	0002_auto_20150907_0602	2020-08-21 05:01:19.792+00
443	account	0003_auto_20151104_1102	2020-08-21 05:01:19.794312+00
444	account	0008_auto_20161115_1011	2020-08-21 05:01:19.796997+00
445	account	0015_auto_20171213_0734	2020-08-21 05:01:19.799368+00
446	account	0011_auto_20171110_0552	2020-08-21 05:01:19.801722+00
447	account	0001_initial	2020-08-21 05:01:19.804273+00
448	account	0013_auto_20171120_0521	2020-08-21 05:01:19.806866+00
449	account	0004_auto_20160114_0419	2020-08-21 05:01:19.809396+00
450	account	0006_auto_20160829_0819	2020-08-21 05:01:19.811831+00
451	checkout	0004_auto_20171129_1004	2020-08-21 05:01:19.814302+00
452	checkout	0002_auto_20161014_1221	2020-08-21 05:01:19.816787+00
453	checkout	0002_auto_20170206_0407	2020-08-21 05:01:19.81915+00
454	checkout	0001_auto_20170113_0435	2020-08-21 05:01:19.82157+00
455	checkout	0001_initial	2020-08-21 05:01:19.824112+00
456	checkout	0005_auto_20180108_0814	2020-08-21 05:01:19.826812+00
457	checkout	fix_empty_data_in_lines	2020-08-21 05:01:19.829486+00
458	checkout	0006_auto_20180221_0825	2020-08-21 05:01:19.831941+00
459	checkout	0003_auto_20170906_0556	2020-08-21 05:01:19.836672+00
460	social_django	0003_alter_email_max_length	2020-08-21 05:01:19.83938+00
461	social_django	0004_auto_20160423_0400	2020-08-21 05:01:19.842166+00
462	social_django	0002_add_related_name	2020-08-21 05:01:19.844636+00
463	social_django	0005_auto_20160727_2333	2020-08-21 05:01:19.84716+00
464	social_django	0001_initial	2020-08-21 05:01:19.849647+00
\.


--
-- Data for Name: django_prices_openexchangerates_conversionrate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_prices_openexchangerates_conversionrate (id, to_currency, rate, modified_at) FROM stdin;
\.


--
-- Data for Name: django_prices_vatlayer_ratetypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_prices_vatlayer_ratetypes (id, types) FROM stdin;
\.


--
-- Data for Name: django_prices_vatlayer_vat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_prices_vatlayer_vat (id, country_code, data) FROM stdin;
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
tjbws4hc9ws1g4cgy0xxm6gvwjto7uo5	MjJkYmNhMWFmMzRkY2YxNDk2M2JiNTA5NWY2MmQyZjc1NjA1OTljNTp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJmc2hyeDRpV0ZRVFhheVNrUmRIU001WFQzTWNvSGdPdSJ9	2020-12-03 02:06:56.658211+00
gsackouzahs0ox2spol1435ilas5xmpx	YjM0YWNhMGRiMGFiNzI0NzQ4ZGJkNzI1MWNjMmY5MjZlOWE2YTk4Yzp7Il9hdXRoX3VzZXJfaWQiOiI1MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDViNjNjMDFhZDNjMjk0MDUwOTZhYjc4OGEwODk2ZmI3NjkyZDU4MCJ9	2020-10-03 07:50:41.25361+00
tmcax0pui352gu0wyqktaveq3gn6ckt3	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-03 13:14:48.662026+00
ht5u6ehegknjaz04q8g33lgq050oznxc	ODA0MjU2YmI5MzEwNzAyNThjMmY4NTc5ZGI0MDBmZGJhNjdjM2YyYjp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJZa3lPb21sVDc2aHhESkFBU0h4dzlYcmdvV2lyeVFCVCJ9	2020-09-19 13:46:48.683836+00
vanm8vip3tjhe36v4ysfo9gsoaqrsj5g	ZGY0MjRmOWIyYzU4YWJmN2FmNGQzZDhjNGM3NjBlMGVlNzdiNjFlOTp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJnUFRaQjU1TzhHbk4zQ1lYR2pWU3hkMEZQMGhpNXJTcyJ9	2020-09-10 21:05:41.957717+00
fmibryhna15pigssl3ecyodk6umq5f8c	ODAyZmI5NmRjOTA3YjZhZTU0Y2ViOGM1YjExMWIzZWQ1YzUzYjIwMTp7Il9hdXRoX3VzZXJfaWQiOiIxOSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMjk4ZWYyMGE1NmNkZWM2NzBkNTc4YjFhOGQ2NzZlYTliOGE5NGViMiJ9	2020-09-25 04:19:56.849472+00
hn5hsxgkz2py63d2plv7mh2wqgytgszk	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-01 07:19:59.458737+00
cnz7djwojf58g6q2zfp2gm64hspcvmt9	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-06 06:47:01.767075+00
p5hjcdtrlesz5vfod6di4elsblvxar8x	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-06 06:48:41.830556+00
kcx2d9c9p21mymqiand2fnoavmeb2vxs	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-10 08:12:53.268808+00
evas7ge09bo9josiqi59a6ceha612xzw	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-09-05 06:39:51.289518+00
7qekcqoxo93c3tp3t2iaefvpqjp2k3bf	OGNlYzQ4MzU1NjdlZjg2YTUwYTc3NDZlNDg4YzUzOWQwMjJlZjc4MTp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJmdHVwaWhuS0NrYlQzcExueVh1cFV6aGZweHQyQnZLaCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoic29jaWFsX2NvcmUuYmFja2VuZHMuZ29vZ2xlLkdvb2dsZU9BdXRoMiIsIl9hdXRoX3VzZXJfaGFzaCI6IjcxMmQwNzc5MGRjZmUyOTU4ODcyOTVhZGVhNWU2ZjkzZDFhZWM4MzciLCJzb2NpYWxfYXV0aF9sYXN0X2xvZ2luX2JhY2tlbmQiOiJnb29nbGUtb2F1dGgyIn0=	2020-09-23 14:47:17.514523+00
thmxvkjucz3bf6wrl6bnv3qe4y8apnzo	MDE4NmQ5ODcwNzQ1ZWRkZmJkOTZjZGJiOTRhNjY1MWNlYzk5OTE0Yjp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMmY0NGNkMzNiN2QzYmJhZTMzODhjNmY0NTQ4MDQ4NjRlYTZiMTEyOSJ9	2020-09-18 08:26:47.317439+00
dwtbqfkpqj5654ufl8ungy8tigkee00r	ODAyZmI5NmRjOTA3YjZhZTU0Y2ViOGM1YjExMWIzZWQ1YzUzYjIwMTp7Il9hdXRoX3VzZXJfaWQiOiIxOSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMjk4ZWYyMGE1NmNkZWM2NzBkNTc4YjFhOGQ2NzZlYTliOGE5NGViMiJ9	2020-09-24 01:46:02.176951+00
9ddq066ej3uv2sbrtq66bmw0b3xup4iv	YmFmMGE1YTIwMGJiZWUyODY0MDkyYWEyM2ViNzk4NzliYzAwNzM1ZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3MTJkMDc3OTBkY2ZlMjk1ODg3Mjk1YWRlYTVlNmY5M2QxYWVjODM3In0=	2020-09-07 01:12:35.4278+00
pssmk19du90jo0cf6rpuhtbbco811rj6	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-09-30 02:14:36.078012+00
yxo2hj0a4zhssspojvej01ppo92t1g1y	NmVjYjgwOTk1Y2MwMTc0ZjlkYmU5ZTI3MzA1ZjFkMTUyZDZjMDBjZjp7Il9hdXRoX3VzZXJfaWQiOiI2MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNzE2OTE0YTEyNTdhNDA5NzQxNTc5NGI4YWQ0YjlhMzM2MTBkY2Q5NiJ9	2020-10-06 09:11:32.086926+00
7tr72sglwafr7qv07n18yr61ptf9sidq	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-09-07 04:02:05.395162+00
6st25ulps6zc2jzhn2367u7foouuc7f4	MTExZGQyZmMxODc4NTZjOTI0MWI5NGFkNzY0MDRiZDM3NzY0ZGExMjp7Il9hdXRoX3VzZXJfaWQiOiI3MSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDAxZTU5NDcwMDcwYjhlMTgwOTA3YmVhM2I0ZTY3MGYwMzg1MTAxZCJ9	2020-10-15 07:02:28.37096+00
rks6iawblh4dahqzkyfg174wqpqqe40d	YjJmNDFlN2ZlMzExOWY3MGM4ZTA5MGNiNWM2N2ViOGM5ZDVhM2Q4ZDp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjZDY4NjFkZDgwYjQyMTc3MmFhYjViMTQwMjY3OTBhMjA2ZDk3OWI4In0=	2020-10-07 12:56:27.360658+00
kgcvykz5q26z37pv9bsxo1kd6sm882mo	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-09-24 09:46:46.859327+00
eyns3f43zf57gzcd86zkuxzalefsrr8c	NjJmNWE0YTkzY2VlOTY1MmE2NjVlMzI5MGZmNDBjMGNjODFjZjc2Yzp7Il9hdXRoX3VzZXJfaWQiOiI0MyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNmI2OWJhYmVjMjY1MDhmZjk3NWQ0MzEzMzkwMTc1MDFlNjA4ZjIxNiJ9	2020-09-29 14:02:39.250214+00
y4aps67fa3lvxvmvionufwq2bg61qi5j	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-13 15:10:57.083009+00
nj71pb9vgauqztpdd3x6tomsnd5o2eyy	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-09-29 12:15:59.510527+00
p4714edervc4ku3mzkr44q4vlfp3v7vf	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-09-07 12:33:58.331049+00
h2882q75rj7wyv70obtl6z6hq334fxux	NmUwYzU4ZGZlNDM1MmM2YmMyM2MzYzVlN2M5NDM4ZDcwZWM5NzY0Mjp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJSakd3UnowOVNNMVpvZjZCU2RzRlkzQnhhSmdaZENwayJ9	2020-09-09 05:39:08.074521+00
lih34xftrlesulr92ezagf9humy41eml	MDE4NmQ5ODcwNzQ1ZWRkZmJkOTZjZGJiOTRhNjY1MWNlYzk5OTE0Yjp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMmY0NGNkMzNiN2QzYmJhZTMzODhjNmY0NTQ4MDQ4NjRlYTZiMTEyOSJ9	2020-09-18 15:01:21.734269+00
vjyvmvyisys62z984ta54s6jr4qt15az	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-09-07 23:04:42.918677+00
jjlnqndzfwgevgqey1om7i7yt79ijh8y	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-01 03:22:59.39295+00
zlypxl1klfdojff8hnovp467os3j4ron	OGEzYjU2YTFjNDdkNTUzNDU5MDVhZTFlNDZkMWQ3MzM1NzEwMmFiNTp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJHN2pkR09oaTJpVml3MWFJRzlzUUR0bkxmcGRBb1ZvdiJ9	2020-09-11 14:22:41.507262+00
8w4pec4a2bx131yr9dht8mk4fu0zw4uk	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-09-13 16:44:20.004981+00
iuebnedtimbxyoge8y2uuwdqqag7wvb0	Njc1YTYzMTI1NzI1ZmE1MWNmMzU4OTZkZWFjOTk4ZGE5MGQxNTAxZDp7Il9hdXRoX3VzZXJfaWQiOiI0NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMjQ5NmFlN2MzNGY0YmFkODE4ZTYwNTMwZjg5ZjhiYmZlM2I0OTdhMiJ9	2020-10-07 09:23:22.65877+00
com5tn4jh51puxh6gnng2t22haaexlfp	YmFmMGE1YTIwMGJiZWUyODY0MDkyYWEyM2ViNzk4NzliYzAwNzM1ZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3MTJkMDc3OTBkY2ZlMjk1ODg3Mjk1YWRlYTVlNmY5M2QxYWVjODM3In0=	2020-09-10 07:55:08.394778+00
q2v9u38cvx513www97zb6pgf9cwn8dkq	MDFkZDA5ZTRhZGI0NmNlNzhlNWQ1ODdiMTYxNzQ0ZDNlNzJjMjA0ODp7Il9hdXRoX3VzZXJfaWQiOiIxMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiM2NkN2I1NTgyNjBiY2Y2MDBlZmVmMWYwMzFjYzdkMTc5MDJlZDdlMyJ9	2020-09-11 14:47:31.229557+00
p1gc222oq0663wvpcddnv0wvdj1sjy7g	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-09-29 15:45:21.494218+00
oicklben6ek9ky9n3wfrn78wc4zle4d3	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-05 05:20:26.603012+00
tmmxyktvm28fpd6msko4pjneg0tni6pr	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-12 15:48:25.818114+00
81kidibaqbq5n1ewlv1h81tq9dx3oxhp	NmVjYjgwOTk1Y2MwMTc0ZjlkYmU5ZTI3MzA1ZjFkMTUyZDZjMDBjZjp7Il9hdXRoX3VzZXJfaWQiOiI2MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNzE2OTE0YTEyNTdhNDA5NzQxNTc5NGI4YWQ0YjlhMzM2MTBkY2Q5NiJ9	2020-10-06 09:44:19.275191+00
l86a9nx2k464d56410uoqq0hu3wurkc2	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-05 09:08:27.99073+00
5zcfxiflsef7fimipnjr72vszxx323lz	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-06 06:47:35.914444+00
2998mrbg9qj71xdkig98117fo57wj40t	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-10 00:55:50.829848+00
i1ivw9whlwvlpe5w2yvp26ltpnzhwen7	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-15 09:54:59.57003+00
j3e1zxyuzpy4m3nj1ylwmxoham7b65hz	N2M3YTZmM2JmZGRmZjQ2YjZhMWFjODZjMmUzZWMwZTZhMDE1OWJhMjp7Il9hdXRoX3VzZXJfaWQiOiI2NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzMwMjI5MTNjODhhZWM1ODBhMGE2NjYzODJhMWUyNmEyYzA4MmIxNSJ9	2020-10-18 08:03:00.702128+00
u9hcyusx4x8oiweqdn5jiiwjjcmm3lw1	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-09-17 00:14:18.816803+00
728h1kiu8lx8b7dhrlu1jr66m77eef1a	NWMzOGI4Mjc4Nzg0YmUyYjA1MjhjYzkxZDZkMzc5NGE2ZDNhNTU1Nzp7Il9hdXRoX3VzZXJfaWQiOiIxMyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNjExZTA3MzhjZjU4YjBiMGI4YmY3YTJmNGI5MmIwMzg3YmVjNWFmNyJ9	2020-09-19 05:17:29.031382+00
d2qq76ni4x8dt9mxkaf5ka1r9kw4uh0j	YzQxYzE4OTdlOWU2NTM0Yjg4OWU0M2Y3ZmIyODBmMDRlYjY5YjM4Mzp7Il9hdXRoX3VzZXJfaWQiOiI0MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWRlNTJiMmU0MjdmOTlhYWI0OGNmZDJiMDBmYjM3NmNjMTk5YzU4YiJ9	2020-09-30 12:37:01.455531+00
whnbz2enja7svihxxsp5egrl0ord4twr	YWUzNzZmYmEwZTNhMDM5YjNjZGFjOGU2OTZlZTYwNTkyMWRlOTlhNzp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJRamJYVmNFZVZOT1lIbFpWRUFac0dlcWNNcjFTbW03USIsIl9hdXRoX3VzZXJfaWQiOiI5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIwNjBkNmRlY2UxZGRmYTgzZjk5MzEyNjczNTk2NzkyZDg4MWMzZmY5In0=	2020-09-29 21:56:11.681706+00
echuzghlon97pwu0huddr888d4nvjbk4	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-03 07:29:01.427484+00
9fg7dgcp0qbdy85cukwd821v3svg0va0	ODAyZmI5NmRjOTA3YjZhZTU0Y2ViOGM1YjExMWIzZWQ1YzUzYjIwMTp7Il9hdXRoX3VzZXJfaWQiOiIxOSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMjk4ZWYyMGE1NmNkZWM2NzBkNTc4YjFhOGQ2NzZlYTliOGE5NGViMiJ9	2020-09-24 10:02:25.61776+00
00jxuaj90c67la0l26gp7ymv0hou6thb	Mzk4MjRiNzcyZGFiMThkYmJiNDllNzQ4ODA5Yjg2MjBhZjgxNTgwMjp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiI3b3Nwd2tGM2NDVFF6QWNDT0NLaUNHNUVwQVdWaUVOTCJ9	2020-10-10 06:15:00.773746+00
m010m2lvgb4j4zvv7ew1ylh2ng6qbnmu	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-01 09:59:16.272857+00
04ok8wsy0lekd2kvb6zvrrtwhaw7qw1b	MDE4NmQ5ODcwNzQ1ZWRkZmJkOTZjZGJiOTRhNjY1MWNlYzk5OTE0Yjp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMmY0NGNkMzNiN2QzYmJhZTMzODhjNmY0NTQ4MDQ4NjRlYTZiMTEyOSJ9	2020-09-29 15:35:42.780308+00
zz2r1xltf6lqh1ybdpackk790dpurk91	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-17 06:42:11.183456+00
628jvwf8lomvfsywld2prjmesu8bvjh7	N2JiNDY0MmFjNTYyNTVmNGU1N2IyZjg4NThmZDc0ODMyMjM1ZTZmODp7Il9hdXRoX3VzZXJfaWQiOiI3NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYWUxOWU5OTEwOGI5MjgwZTcxYjg2NjI1MDBiZTNhMjk4NzcwYWQxNiJ9	2020-10-17 06:43:08.839371+00
fefd14lbb1mlp2ap5vtg5r818qqzvezb	YmFmMGE1YTIwMGJiZWUyODY0MDkyYWEyM2ViNzk4NzliYzAwNzM1ZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3MTJkMDc3OTBkY2ZlMjk1ODg3Mjk1YWRlYTVlNmY5M2QxYWVjODM3In0=	2020-10-05 17:17:40.905355+00
zrucu7r5bbk3l6wv5jjg3xy9u51v2e99	MzFlODdiZTI1MWYxZDExN2QyYjcxZDFjM2E3Zjg1MjczNzU2MGVkOTp7Il9hdXRoX3VzZXJfaWQiOiIxMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiY2E2OGUzMjZjOGE4NzhiMjllYTJhMjkzNWNiM2YxYTBhOWFlOWIyMCJ9	2020-10-06 03:37:02.25056+00
l5fhus8g5z1ttj8s2ytundgj8rjktxrf	ODAyZmI5NmRjOTA3YjZhZTU0Y2ViOGM1YjExMWIzZWQ1YzUzYjIwMTp7Il9hdXRoX3VzZXJfaWQiOiIxOSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMjk4ZWYyMGE1NmNkZWM2NzBkNTc4YjFhOGQ2NzZlYTliOGE5NGViMiJ9	2020-09-25 08:10:28.082043+00
hps0eb0yfa9l028txo881z5bf8qopk46	Njc1YTYzMTI1NzI1ZmE1MWNmMzU4OTZkZWFjOTk4ZGE5MGQxNTAxZDp7Il9hdXRoX3VzZXJfaWQiOiI0NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMjQ5NmFlN2MzNGY0YmFkODE4ZTYwNTMwZjg5ZjhiYmZlM2I0OTdhMiJ9	2020-10-06 07:11:59.773259+00
us1sx0v5sj8m1ajg2b0l74i2yeift1ml	MTEwNWUwNzcxOTUxN2MyOWQ4OWQ4YmZiMGU1YjUzYzkzOGQ1MWVmMzp7Il9hdXRoX3VzZXJfaWQiOiI1MyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiN2JmNTExMjAxYzkxNjlhYmVhYTJjZTRkYTczZjI3OTg0NGFhMjAwMyJ9	2020-10-09 02:57:57.301795+00
4hitbt17na6ok9eced7emfnumuqv7y4r	ODNhNTM2ZWYyY2E1MWJmNzM2ZWY2OWM2YjEzNDYzZDc5M2Q5ZjJiYjp7Il9hdXRoX3VzZXJfaWQiOiI1MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNWI3ZTFlNTA2NTVlM2NhNzk5YmJjYzM1NzFjODIzZjA2NTFhNTc3OCJ9	2020-10-04 05:43:17.024592+00
v9uavibadm6nqk5531tmwo1n9nmwzwud	Yjc3MGNkMDNhMDhlYzkzZWNiNjQ0ZmQzMDFhZjI5ZTUxNmRjYWI3Nzp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJvUUk5YzZhakhHOXd6WlcyTncxUGtwSUFVT3lzNkxSaSJ9	2020-10-04 06:32:25.391313+00
sg1guqfv33homr3wzfzzfs2m3t9vygr4	YjM0YWNhMGRiMGFiNzI0NzQ4ZGJkNzI1MWNjMmY5MjZlOWE2YTk4Yzp7Il9hdXRoX3VzZXJfaWQiOiI1MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDViNjNjMDFhZDNjMjk0MDUwOTZhYjc4OGEwODk2ZmI3NjkyZDU4MCJ9	2020-10-03 07:44:34.677357+00
cgp1wzppvk0gvrgcfgcwhjxufiwdyag5	MDE4NmQ5ODcwNzQ1ZWRkZmJkOTZjZGJiOTRhNjY1MWNlYzk5OTE0Yjp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMmY0NGNkMzNiN2QzYmJhZTMzODhjNmY0NTQ4MDQ4NjRlYTZiMTEyOSJ9	2020-10-06 06:24:50.58171+00
pp96tgufo0flj977q8df1g2tojldyc7k	Njc1YTYzMTI1NzI1ZmE1MWNmMzU4OTZkZWFjOTk4ZGE5MGQxNTAxZDp7Il9hdXRoX3VzZXJfaWQiOiI0NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMjQ5NmFlN2MzNGY0YmFkODE4ZTYwNTMwZjg5ZjhiYmZlM2I0OTdhMiJ9	2020-10-06 06:31:27.271634+00
tdky02su1dtr8ir2wh6b4xijhlc2ctuo	Njc1YTYzMTI1NzI1ZmE1MWNmMzU4OTZkZWFjOTk4ZGE5MGQxNTAxZDp7Il9hdXRoX3VzZXJfaWQiOiI0NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMjQ5NmFlN2MzNGY0YmFkODE4ZTYwNTMwZjg5ZjhiYmZlM2I0OTdhMiJ9	2020-10-06 06:35:57.516395+00
stuttox38fhpwy8ru7ry053my3bk8z32	MzEzYjVlMjJhODZiMGE4NWRkYmUyMmIyZGU0ZWZiMDg5OThiZDg3MDp7Il9hdXRoX3VzZXJfaWQiOiI1NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMGE1NWRmMmZlNGU0OGM5ZDZjMzZmOGQ3MGI1N2VlMWNkY2IyYmJkNSJ9	2020-11-05 06:31:06.733739+00
qn8ahimkrfmjlgpfhfvtr5x93b2qa68v	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-17 07:14:31.321942+00
8w4cfno0v46ivjftev40ctv8fl7j6cvs	MmMwNDIwNWMxODFmOTYyOWQzNDU4YmMzM2RiOGVmNGE5ZTk0NzhjYTp7Il9hdXRoX3VzZXJfaWQiOiI3NiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNjZmNjkzZTgzMDk5MjFlMThlMzZmYjBlMjA3NGUwNzk4NTBmY2ViYSJ9	2020-10-17 07:42:52.322658+00
bz5o5bzk3qm6hplu30qaq7rvbhml6zpb	NjZjMzc3NmE0ZjhmY2NlNDI0NDQ5ZjgwOGVhZmYyMjRmNTlmZWJjMjp7Il9hdXRoX3VzZXJfaWQiOiI4MyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNmI1YThkMzBiMjM5OTM0NDMyNmJmMTkzMTUyZjNlZjQyMDg5Y2ZhYiJ9	2020-10-26 02:38:01.657087+00
emmbilmpgq96hkn82ta8xvcjapcv6mql	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-17 07:50:54.227784+00
0gdy82rfkujgimj4dyifsk8xqjzv5yq8	Zjc2Mzc3NTllMDE0NGZjYjM4YTY5M2EyYWYyY2Y5YzhiOWMzMWQ5ODp7Il9hdXRoX3VzZXJfaWQiOiI3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkYmY2N2ZmMjAzMTZlZTJlMDMzYjgwNDllZWJlNDAyOGFjZTUzNDczIn0=	2020-11-10 06:10:39.061495+00
yswo4x16hlno0il7otiqbjcix8ayesmh	MGY1ODhmY2MyYzgzM2VmMDY1MGZkMDFlMjYxMDZmNjJjZTczOGUyZjp7Il9hdXRoX3VzZXJfaWQiOiI3NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNmM2M2UxY2M4MDgzZmYzZDc0MjI3ZWE4ODlhMmRkZTY1ZmQ3NWUzYiJ9	2020-11-15 10:51:23.808044+00
u7n3hsv3g6yja3q195gieuxcp1lmt7kz	NzhkODhjZDMyODU2YjU0YjQ4OWFhOWQ0ZjgxY2MxNTgyOTFlNjhlMDp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJJU3hLV1pWM1pzSzlKMFIxb0hWYk51RzYwTnNwamFraCJ9	2020-10-09 23:12:26.207006+00
bptlw0yqlqfpn4fibixevs0de53pxtus	MDE4NmQ5ODcwNzQ1ZWRkZmJkOTZjZGJiOTRhNjY1MWNlYzk5OTE0Yjp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMmY0NGNkMzNiN2QzYmJhZTMzODhjNmY0NTQ4MDQ4NjRlYTZiMTEyOSJ9	2020-10-06 14:37:04.60952+00
o11s0ecn2zry2wfi0k2dn0ibsricf5zy	ZWMzOGZlNzRlMGY5YzdiMzIwMDkzNWE5NjIzODJiOTNiNzgxZDFiZTp7Il9hdXRoX3VzZXJfaWQiOiI0MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZmM4MjZhZjgyNWE1ZDE2NmI0YTVlN2Q2ZTIxY2M1MTE1YjFkNTNkOCJ9	2020-11-10 00:51:17.940297+00
om7kzb21pms258acea3qlac0yg84fsle	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-06 14:38:02.057729+00
as3mtwumnxhc8yj75datzdyd8t5bvx8y	MmEyZDE0NjhmMDU0MTFjZGIzNWYxZjI0MjZjZjYyM2RiMTg0NDA0Mzp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJHd2wyT2lFTXNmT1dRN0t0OHpVSG9ndXlwa1dXbnlCTSJ9	2020-10-06 16:24:45.471756+00
dml2cbibaad9jizniyas1vgr1bnr73js	MWYxYzE1YTJkNTQ5MmRjODJmZDZkM2IzYTNlZjY5NTA0NjdmODIzNTp7Il9hdXRoX3VzZXJfaWQiOiI4NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZTMwZDM5ZWQxYzk3MjU0ZmI4ZWQ0YmM5NmNkMDBjNWE1MzJmZGEwMiJ9	2020-11-05 04:21:33.867985+00
oy1ep0gafavm4voayx06hxe5vn1xylbb	NzUzNmNmNjEwOTU4M2UyZDVlYzg5YzExZGI1NTA2MmE5ZGRhZGIxZjp7Il9tZXNzYWdlcyI6IltbXCJfX2pzb25fbWVzc2FnZVwiLDAsMjUsXCJUaGFuayB5b3UgZm9yIFJlZ2lzdGVyaW5nIGFzIGEgU2VsbGVyLiBZb3VyIEFwcGxpY2F0aW9uIGhhcyBiZWVuIHJlY2VpdmVkIGFuZCBhbiBhY2tub3dsZWRnZW1lbnQgaGFzIGJlZW4gc2VudCB0byB5b3VyIHJlZ2lzdGVyZWQgZW1haWwgYWRkcmVzcy5cIl1dIn0=	2020-10-17 06:33:51.600487+00
50l5tk379yx9bi90tkdqpq7l2b2s43u3	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-11-14 07:30:05.499028+00
xr8xkf92nh2v1nyxg69e9mj1bdedj8nm	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-14 02:52:13.133874+00
mrxz530gwq1zix9rmsm6bm4ks3ti98pd	NDQ4ZDQxZGZkNGQ4MTgzM2EzYzI4NDg3MGJjMjhiMWRjYjAyMGMwMDp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJhRWFBazFGVXZKcTJoNkVTZEttMnZxWU1zWmN3ZjVQSCJ9	2020-10-10 06:15:45.547745+00
5u29l7bllviaqn1o9spb9t9hcvzlhs94	MjMyMTE0ZWE4YjJlYWQwZjE3NzA4YmFiYmMwMDQ1NTU5ZWUwOWY2Nzp7Il9hdXRoX3VzZXJfaWQiOiI2NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYmMyOWFkYjBlN2RiMDE0NjFmY2QzNWM4YWFiNmFmOTg2NmYxNjUyOSJ9	2020-10-08 08:20:35.712593+00
cxkg4yfjonetcr50bt2pruepv4re8br3	MzRjYzJjZjA1YTlkZDUwMzdiNjYwZmI1MGQ5NmQ5NWRmNTRjZTFjMTp7Il9hdXRoX3VzZXJfaWQiOiI2MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzdiNDc4NjI0ZWI1ZmZlZTQyNTdkZTNiMGRiY2JlZjVmMjIxNzMxMyJ9	2020-10-14 06:15:14.41596+00
oj6lpchlk232vjx4hmgeqmue3ew43r0s	MzRjYzJjZjA1YTlkZDUwMzdiNjYwZmI1MGQ5NmQ5NWRmNTRjZTFjMTp7Il9hdXRoX3VzZXJfaWQiOiI2MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzdiNDc4NjI0ZWI1ZmZlZTQyNTdkZTNiMGRiY2JlZjVmMjIxNzMxMyJ9	2020-10-17 01:56:20.995698+00
3jm5dx9suee1ez7g17a98es86we3mnly	YjM0YWNhMGRiMGFiNzI0NzQ4ZGJkNzI1MWNjMmY5MjZlOWE2YTk4Yzp7Il9hdXRoX3VzZXJfaWQiOiI1MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDViNjNjMDFhZDNjMjk0MDUwOTZhYjc4OGEwODk2ZmI3NjkyZDU4MCJ9	2020-10-12 06:37:54.399929+00
wh94ki345y0wczfp4jmm1lmqady0zind	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-11-01 07:11:36.554496+00
e8gvp9qugz414hyjfkk7abkyyayibadf	MGY1ODhmY2MyYzgzM2VmMDY1MGZkMDFlMjYxMDZmNjJjZTczOGUyZjp7Il9hdXRoX3VzZXJfaWQiOiI3NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNmM2M2UxY2M4MDgzZmYzZDc0MjI3ZWE4ODlhMmRkZTY1ZmQ3NWUzYiJ9	2020-10-30 07:22:04.865533+00
0g3af3y0dd2jdpka3gzzr82fis1197l7	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-11-02 06:55:15.86023+00
fyuewpi6w58jpfuhykutdflgucjll521	MGY1ODhmY2MyYzgzM2VmMDY1MGZkMDFlMjYxMDZmNjJjZTczOGUyZjp7Il9hdXRoX3VzZXJfaWQiOiI3NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNmM2M2UxY2M4MDgzZmYzZDc0MjI3ZWE4ODlhMmRkZTY1ZmQ3NWUzYiJ9	2020-10-17 04:27:27.69165+00
l4imj7ljy2wzoqk3579lgnuyetf4lp2h	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-31 04:29:25.148622+00
eyxk12mdlgkcqg05wy73voilvlvzqsn0	MzEzYjVlMjJhODZiMGE4NWRkYmUyMmIyZGU0ZWZiMDg5OThiZDg3MDp7Il9hdXRoX3VzZXJfaWQiOiI1NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMGE1NWRmMmZlNGU0OGM5ZDZjMzZmOGQ3MGI1N2VlMWNkY2IyYmJkNSJ9	2020-10-29 03:15:06.880467+00
wetkqjv38v1e4jsc3abmahi906awapiq	MzRjYzJjZjA1YTlkZDUwMzdiNjYwZmI1MGQ5NmQ5NWRmNTRjZTFjMTp7Il9hdXRoX3VzZXJfaWQiOiI2MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzdiNDc4NjI0ZWI1ZmZlZTQyNTdkZTNiMGRiY2JlZjVmMjIxNzMxMyJ9	2020-10-29 10:48:53.686124+00
nkwfegn6rfwwartqmd3u1nia1kbadeiw	ZjdkNjljNDc2NDViYzYyNDc4MjJmYmI2ZjlkYzZlNGI2ODUxODg2Zjp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJOVGpvcVNuNnU0UnVMRXJsY1BFeXZ0ck1tME40SUE3ViJ9	2020-10-21 14:40:23.375291+00
r4u5iwoadf3bfzyvifte40pj7rk3dta3	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-31 07:32:48.585692+00
q6l3ctienw118gj2ip5z31lch3la6ta1	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-06 09:25:09.452873+00
85qzwdcrb4avkvd2lxzik86fgnhcxcfj	NjZjMzc3NmE0ZjhmY2NlNDI0NDQ5ZjgwOGVhZmYyMjRmNTlmZWJjMjp7Il9hdXRoX3VzZXJfaWQiOiI4MyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNmI1YThkMzBiMjM5OTM0NDMyNmJmMTkzMTUyZjNlZjQyMDg5Y2ZhYiJ9	2020-10-26 02:31:35.995993+00
eiwk9pssgj46gz7mczruyqbyh1xcci1s	YzQxYzE4OTdlOWU2NTM0Yjg4OWU0M2Y3ZmIyODBmMDRlYjY5YjM4Mzp7Il9hdXRoX3VzZXJfaWQiOiI0MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWRlNTJiMmU0MjdmOTlhYWI0OGNmZDJiMDBmYjM3NmNjMTk5YzU4YiJ9	2020-10-08 05:50:10.030641+00
ccvu7m6tph3a0475i2bfal5d9j1rvrui	MGY1ODhmY2MyYzgzM2VmMDY1MGZkMDFlMjYxMDZmNjJjZTczOGUyZjp7Il9hdXRoX3VzZXJfaWQiOiI3NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNmM2M2UxY2M4MDgzZmYzZDc0MjI3ZWE4ODlhMmRkZTY1ZmQ3NWUzYiJ9	2020-10-15 11:03:32.364926+00
hsplhetskk5djxhi9rs4fg6hozg0onhq	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-08 06:49:05.499162+00
978frschc1i06ioulxhxc7qxsagyp16z	NmVjYjgwOTk1Y2MwMTc0ZjlkYmU5ZTI3MzA1ZjFkMTUyZDZjMDBjZjp7Il9hdXRoX3VzZXJfaWQiOiI2MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNzE2OTE0YTEyNTdhNDA5NzQxNTc5NGI4YWQ0YjlhMzM2MTBkY2Q5NiJ9	2020-10-06 07:46:24.346074+00
8w9juiljznh9xrrpcupf2awk9zb37a1p	ZWMzOGZlNzRlMGY5YzdiMzIwMDkzNWE5NjIzODJiOTNiNzgxZDFiZTp7Il9hdXRoX3VzZXJfaWQiOiI0MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZmM4MjZhZjgyNWE1ZDE2NmI0YTVlN2Q2ZTIxY2M1MTE1YjFkNTNkOCJ9	2020-10-20 03:07:55.64465+00
hzvsd56cbihdymt2lw6tq3mag3d5xld5	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-13 05:57:33.23688+00
szt2smjdmjz2b52a86ufchaqfnzhj9kv	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-31 03:03:51.724936+00
74a5zin2f1uma627erzp05gm0tkwt8ve	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-14 06:41:34.333248+00
w4kh56irswscbdkca5wjwknbw0q7gse3	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-10 11:31:44.976731+00
ibubzb9fkmobbzaieygxn9mj7m69uydd	ODAyZmI5NmRjOTA3YjZhZTU0Y2ViOGM1YjExMWIzZWQ1YzUzYjIwMTp7Il9hdXRoX3VzZXJfaWQiOiIxOSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMjk4ZWYyMGE1NmNkZWM2NzBkNTc4YjFhOGQ2NzZlYTliOGE5NGViMiJ9	2020-10-08 04:26:24.602232+00
7zl2j4ir6bdqxmem73rqwchnkaw2i06i	MzRjYzJjZjA1YTlkZDUwMzdiNjYwZmI1MGQ5NmQ5NWRmNTRjZTFjMTp7Il9hdXRoX3VzZXJfaWQiOiI2MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzdiNDc4NjI0ZWI1ZmZlZTQyNTdkZTNiMGRiY2JlZjVmMjIxNzMxMyJ9	2020-11-04 03:24:17.500252+00
ek6o3wo1adhj3jgsmw86dxz6dkvzd1py	ZWMzOGZlNzRlMGY5YzdiMzIwMDkzNWE5NjIzODJiOTNiNzgxZDFiZTp7Il9hdXRoX3VzZXJfaWQiOiI0MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZmM4MjZhZjgyNWE1ZDE2NmI0YTVlN2Q2ZTIxY2M1MTE1YjFkNTNkOCJ9	2020-10-31 06:52:05.964536+00
2mx3rj9dt1bvcu2a7r3r3gwvmz3gts24	YjM0YWNhMGRiMGFiNzI0NzQ4ZGJkNzI1MWNjMmY5MjZlOWE2YTk4Yzp7Il9hdXRoX3VzZXJfaWQiOiI1MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDViNjNjMDFhZDNjMjk0MDUwOTZhYjc4OGEwODk2ZmI3NjkyZDU4MCJ9	2020-10-20 08:03:58.802751+00
9lsid6k9ivgnsnf4xw8gzfgrfuut4rs8	ZWMzOGZlNzRlMGY5YzdiMzIwMDkzNWE5NjIzODJiOTNiNzgxZDFiZTp7Il9hdXRoX3VzZXJfaWQiOiI0MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZmM4MjZhZjgyNWE1ZDE2NmI0YTVlN2Q2ZTIxY2M1MTE1YjFkNTNkOCJ9	2020-10-22 10:10:33.861986+00
1pw4jbx3osp9hsfuxbqefolqd5a8453a	MGZmZWQ5NDczZjQ4Y2U4YWY4MWFjYjZhYTRjNWMyOGNjMGE2YTI4ZTp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJRZGRHdk5nNjY0d1R6U2s4S2FCaFhYdG5lZEtXSlEzTSJ9	2020-10-23 01:00:08.858821+00
lmn84smuyzg3vzo6larturego6dm3fjw	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-10 07:10:27.853743+00
5hhambwejfz6gfvpdmspirymo9z12y32	YmFmMGE1YTIwMGJiZWUyODY0MDkyYWEyM2ViNzk4NzliYzAwNzM1ZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3MTJkMDc3OTBkY2ZlMjk1ODg3Mjk1YWRlYTVlNmY5M2QxYWVjODM3In0=	2020-12-12 08:40:20.277969+00
zz2kag9di11i6j6x0b8404xrqz1omzaf	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-17 10:43:18.352737+00
quqyj2gkk8dnv33r9eo12fu62ur646y7	ODEzNTIwODU4Mzc3NWJiNjcyYTc5ZTQ1NjliZDEwMTc4MmRjOWE1OTp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJ1M3BiOUV1TmtuSm0xdmRyRm9PbkNqdWxYWHJLRm5iTyJ9	2020-12-12 14:09:13.7399+00
l6lqz5aoxr8brojgy4cyswjecacl7grz	MjMyMTE0ZWE4YjJlYWQwZjE3NzA4YmFiYmMwMDQ1NTU5ZWUwOWY2Nzp7Il9hdXRoX3VzZXJfaWQiOiI2NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYmMyOWFkYjBlN2RiMDE0NjFmY2QzNWM4YWFiNmFmOTg2NmYxNjUyOSJ9	2020-10-29 06:40:36.307188+00
zuygue8v4k4xilwrolkt9flfvewjfl4e	MDE4NmQ5ODcwNzQ1ZWRkZmJkOTZjZGJiOTRhNjY1MWNlYzk5OTE0Yjp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMmY0NGNkMzNiN2QzYmJhZTMzODhjNmY0NTQ4MDQ4NjRlYTZiMTEyOSJ9	2020-10-23 15:48:30.109393+00
zvmsssgfu4dw0qdrzzc0phzvn6hpxp1d	MjMyMTE0ZWE4YjJlYWQwZjE3NzA4YmFiYmMwMDQ1NTU5ZWUwOWY2Nzp7Il9hdXRoX3VzZXJfaWQiOiI2NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYmMyOWFkYjBlN2RiMDE0NjFmY2QzNWM4YWFiNmFmOTg2NmYxNjUyOSJ9	2020-10-14 06:17:24.837515+00
c5d49iai87fpk7s77qpyk8l3s23dg4ii	YTUyMGVlNTExYjk3OWVmNzgxOWJjMjViN2Q5OTJmNWJkZmI0MGU0ZTp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJGckMxczFvb0I0Y1ExelFWUkoyQjhPcjBsMHhvNzNNMSJ9	2020-10-18 00:14:50.055929+00
6xkkwn6n1mbwyd0ldjiea91dl4mfwpkl	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-17 07:51:04.470086+00
pplv291ey01qxwo6bj7fu9a1o871jhas	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-22 02:35:43.992703+00
pjjk6p6kuvdq4f4dg9imlo4uy3mcwc1u	MzRjYzJjZjA1YTlkZDUwMzdiNjYwZmI1MGQ5NmQ5NWRmNTRjZTFjMTp7Il9hdXRoX3VzZXJfaWQiOiI2MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzdiNDc4NjI0ZWI1ZmZlZTQyNTdkZTNiMGRiY2JlZjVmMjIxNzMxMyJ9	2020-10-26 01:35:50.577894+00
czcjxxvm1gby4zd96rbywktcqph9isev	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-10-26 01:39:26.617525+00
668tj5f4ebskaveh4upe1oa5danpu9e4	N2M3YTZmM2JmZGRmZjQ2YjZhMWFjODZjMmUzZWMwZTZhMDE1OWJhMjp7Il9hdXRoX3VzZXJfaWQiOiI2NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzMwMjI5MTNjODhhZWM1ODBhMGE2NjYzODJhMWUyNmEyYzA4MmIxNSJ9	2020-10-19 13:40:40.121038+00
p47gvrb08c7iah3lq60h2nhjvfqvcjdl	MTEwNWUwNzcxOTUxN2MyOWQ4OWQ4YmZiMGU1YjUzYzkzOGQ1MWVmMzp7Il9hdXRoX3VzZXJfaWQiOiI1MyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiN2JmNTExMjAxYzkxNjlhYmVhYTJjZTRkYTczZjI3OTg0NGFhMjAwMyJ9	2020-10-17 08:42:19.488777+00
bkvn85xyiu4ghdckm2r7bj3wxlh9xf79	OTlhMjYzMzcwZGY5NTI5MWY4NTJhM2QyYTQxODEyY2QzMzdjZTIxNjp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJVbHVZem51dVdXbVdrcGhoMFVhc2tsZ2xYd2FWT1ZWaCJ9	2020-11-01 15:22:43.200173+00
71jey2shs22kny8ra11tiyuuq8onh0cf	M2I1ZjBkNjQzOTQzNGQyNWExOTY4NWFjZDQwMTRjNWQ4M2QxM2RjZDp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJJTTFOMjRHZHFNMm5tQzBOTnY0YTBTOVJyZm1hY3FvOSIsIl9hdXRoX3VzZXJfaWQiOiI5MSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6InNvY2lhbF9jb3JlLmJhY2tlbmRzLmdvb2dsZS5Hb29nbGVPQXV0aDIiLCJfYXV0aF91c2VyX2hhc2giOiJhZGU3NmEwMzA2ZDA1OWQ4YzMyN2Y1Y2NiMmI5YjQxYmEzNGMwZThmIiwic29jaWFsX2F1dGhfbGFzdF9sb2dpbl9iYWNrZW5kIjoiZ29vZ2xlLW9hdXRoMiJ9	2020-11-13 00:40:18.105305+00
1wkus410qatfw4d79frnzsg2m1r28zzw	ZWMzOGZlNzRlMGY5YzdiMzIwMDkzNWE5NjIzODJiOTNiNzgxZDFiZTp7Il9hdXRoX3VzZXJfaWQiOiI0MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZmM4MjZhZjgyNWE1ZDE2NmI0YTVlN2Q2ZTIxY2M1MTE1YjFkNTNkOCJ9	2020-11-10 06:40:56.11717+00
jy3pbh694s9xzukxei6uggypuk9qw52y	MGY1ODhmY2MyYzgzM2VmMDY1MGZkMDFlMjYxMDZmNjJjZTczOGUyZjp7Il9hdXRoX3VzZXJfaWQiOiI3NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNmM2M2UxY2M4MDgzZmYzZDc0MjI3ZWE4ODlhMmRkZTY1ZmQ3NWUzYiJ9	2020-11-14 07:01:40.724256+00
ogqvlgomxmqzlxcyf2y6zaahh0stzmwv	NDVkNjA3YmFlOTFjYjc4NWNmODBhYTBiNmRhMjg0ZGRhZjI3Zjk1Zjp7Il9tZXNzYWdlcyI6IltbXCJfX2pzb25fbWVzc2FnZVwiLDAsMjAsXCJZb3UgaGF2ZSBzdWNjZXNzZnVsbHkgbG9nZ2VkIG91dC5cIl1dIn0=	2020-11-01 09:47:08.367661+00
kcmn9hbayhydt5dcks3fn9fce7rng8rj	MjlmOGQ1ODFiNTM5Yzg4ODFhOWU1Mjc1MjI0ODI5YmQzZjdiMWRmMjp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJIbGUwakZjTW5IWUVHcFA3MVdreExBVUJMeUdYa1dGNCIsIl9hdXRoX3VzZXJfaWQiOiI5MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6InNvY2lhbF9jb3JlLmJhY2tlbmRzLmdvb2dsZS5Hb29nbGVPQXV0aDIiLCJfYXV0aF91c2VyX2hhc2giOiJhZGU3NmEwMzA2ZDA1OWQ4YzMyN2Y1Y2NiMmI5YjQxYmEzNGMwZThmIiwic29jaWFsX2F1dGhfbGFzdF9sb2dpbl9iYWNrZW5kIjoiZ29vZ2xlLW9hdXRoMiJ9	2020-11-12 09:27:07.626698+00
xe0sx2tzzs27myg1obgxycp2u2qftbsu	MzRjYzJjZjA1YTlkZDUwMzdiNjYwZmI1MGQ5NmQ5NWRmNTRjZTFjMTp7Il9hdXRoX3VzZXJfaWQiOiI2MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzdiNDc4NjI0ZWI1ZmZlZTQyNTdkZTNiMGRiY2JlZjVmMjIxNzMxMyJ9	2020-11-03 12:37:34.523338+00
2474zi85vvgfvfikcri1yynhwempxall	MzRjYzJjZjA1YTlkZDUwMzdiNjYwZmI1MGQ5NmQ5NWRmNTRjZTFjMTp7Il9hdXRoX3VzZXJfaWQiOiI2MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzdiNDc4NjI0ZWI1ZmZlZTQyNTdkZTNiMGRiY2JlZjVmMjIxNzMxMyJ9	2020-11-25 05:55:17.297956+00
hm3yjurqqx2kn6kh5it1g3y3kmmu34iy	ZWMzOGZlNzRlMGY5YzdiMzIwMDkzNWE5NjIzODJiOTNiNzgxZDFiZTp7Il9hdXRoX3VzZXJfaWQiOiI0MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZmM4MjZhZjgyNWE1ZDE2NmI0YTVlN2Q2ZTIxY2M1MTE1YjFkNTNkOCJ9	2020-11-28 15:11:17.898155+00
mlicca5rdvpqy07i9eswdgod3zepbowa	NWMzOGI4Mjc4Nzg0YmUyYjA1MjhjYzkxZDZkMzc5NGE2ZDNhNTU1Nzp7Il9hdXRoX3VzZXJfaWQiOiIxMyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNjExZTA3MzhjZjU4YjBiMGI4YmY3YTJmNGI5MmIwMzg3YmVjNWFmNyJ9	2020-12-10 02:04:24.328081+00
d9j0q2n7i03k39unppth24d2gonpz70r	MGY1ODhmY2MyYzgzM2VmMDY1MGZkMDFlMjYxMDZmNjJjZTczOGUyZjp7Il9hdXRoX3VzZXJfaWQiOiI3NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNmM2M2UxY2M4MDgzZmYzZDc0MjI3ZWE4ODlhMmRkZTY1ZmQ3NWUzYiJ9	2020-12-10 05:22:17.897949+00
2e83d58u71hx18lkmp88pa60ekgdjsk8	OGQ0Y2ZhNmIzNmJhOTBlMTlmNzgxNmI2NjM4M2Q5OWExYmMxZTViNjp7Il9hdXRoX3VzZXJfaWQiOiI4OSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiY2JmMzVkYzIwMWU2YzI1YzBlZTQ4YzRmMTY4ZDI2MGRkODllZWM2ZSJ9	2020-12-11 15:20:09.36275+00
ug7yfwiw3gmdwgb5slb6zkea9yb1qwk7	YmFmMGE1YTIwMGJiZWUyODY0MDkyYWEyM2ViNzk4NzliYzAwNzM1ZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3MTJkMDc3OTBkY2ZlMjk1ODg3Mjk1YWRlYTVlNmY5M2QxYWVjODM3In0=	2020-12-12 08:42:48.981921+00
fn70yvvu27wx5zka8satqhid1s7v26li	MGY1ODhmY2MyYzgzM2VmMDY1MGZkMDFlMjYxMDZmNjJjZTczOGUyZjp7Il9hdXRoX3VzZXJfaWQiOiI3NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNmM2M2UxY2M4MDgzZmYzZDc0MjI3ZWE4ODlhMmRkZTY1ZmQ3NWUzYiJ9	2020-11-18 03:58:38.604527+00
heb1u741pnuof0geieq43e58z15dk0td	YWJjZjZiMDg1OWNmZDg1ZmY2MTA3OWRlYjlhOTY5ZjdiYzFmMDg0MDp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiIwWlhTQzJ6cjJYNllMTEdZSUh0NEpMVjF3YVQ0djd2diIsIl9sYW5ndWFnZSI6ImFyIn0=	2020-12-12 15:05:43.154595+00
xwajbxr66obs3mowtszv6y0ioeg21ouz	NWRlNGZhZjUxNDEyMmI5NWJkYzRlZGExMTZkNmVkOTdmMGQ2M2Q3MDp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJXTUt0VnpUMmFoOTVTNGM1TTUybllPTklkS0NmMmNzNiJ9	2020-11-23 23:12:45.512401+00
rynmb366rj1352sp7pv42f11by7enq8w	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-11-16 06:11:29.038339+00
g1yf8snxe5bt0ayrbtvwdbx1hzvo2xvg	MTRmM2RmMThlMGI3MmI1MmY4ZDZjOTA2MzJlYmY2OGZmMzNiYjFjNDp7Il9hdXRoX3VzZXJfaWQiOiI3MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNWNlYTlkODY5YWZjMjI0ZTg4MThlYzc1OWNjN2E0ODhiMGNhYTgwZiJ9	2020-11-09 01:37:56.781565+00
34jo7dbq2ef33ti1nglklxiffq0x32xv	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-12-09 03:38:23.454548+00
0gnse8nhok6zvl9w6z7p0hveo817zz8w	ZGFkYWM1NzJkODUzNjgxZDk5ZjEzMTRmZGQ4YWEyZTYzOGFmNGU0ZTp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMTVlN2NjOTM3NGYwYTkxZjhiNTA4ZmMyMjFiMTMyYTZkMWUwMWE2NyJ9	2020-12-04 16:52:39.09283+00
4j5s0lw5nslfh9qhy8rhbu0z1s5zcqoi	ZTc5NTYzOGFmYTgwNzAwODBiY2U4MjM4NTdiY2M1MWYzN2E4MDg0ZTp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJpSnZmdjI1cXVGUDhRYU9FZ1AyTHJ5RnU5MGYyMEZHQiIsIl9hdXRoX3VzZXJfaWQiOiIzNiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYjZjNjVhZDI2YTI0OTgyNTliNmQ2MGU4ZmJlNjY4ZDExZTg4NWY5ZiJ9	2020-12-09 07:42:08.474257+00
vakdu8gum9gvjzmqbl3rx5k798na4wk1	ZjYyMTE1ZTg2ZjU0MmIyNzE3ZTM1MmEyODRlNmI4NmFkOGExNmQ2Njp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJISjRkeDlkenJHeFc3OFl2NklacEtnS3cwNVdvMVFrMyJ9	2020-12-10 02:21:50.008811+00
5bz6wkgduqk6sp7refihon5y9lc6xb06	YTZhZjQ2NDZhMTgxODdkNjgzNjJhN2IyNGJhN2I4YTM5YmNkMmQ4Mjp7Il9hdXRoX3VzZXJfaWQiOiIzNiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYjZjNjVhZDI2YTI0OTgyNTliNmQ2MGU4ZmJlNjY4ZDExZTg4NWY5ZiJ9	2020-12-12 03:40:12.551492+00
p1f6p5jgc5i9i7g5qh4t0l48vdzx2kjg	NjMyMzdjZjBjOTYxMmM5NDdiZDVmNjBlMWU0Zjg5MzYwZTViODAzMTp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJ2cGNVS0hXeVB2N1JMSTVBaUZCRmU0WHdtSHVlMjFrYyJ9	2020-12-12 10:33:28.170121+00
w2dyo72dvqz52xecpnkkbnxxfytjd5p2	MTEyYTJiMDdlYzBjYWJhMDFhYjJjNDIzZDI3Mjg5ZjUwM2UzM2JiNTp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJkNk9qc1hTQzhFRGJpUkx1eUV0Q3REVTQ5Y3V4bmwyQSJ9	2020-11-27 00:48:36.025056+00
cj99wkczwcevcjmdrm66221wnc1g9dcs	ZWMzOGZlNzRlMGY5YzdiMzIwMDkzNWE5NjIzODJiOTNiNzgxZDFiZTp7Il9hdXRoX3VzZXJfaWQiOiI0MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZmM4MjZhZjgyNWE1ZDE2NmI0YTVlN2Q2ZTIxY2M1MTE1YjFkNTNkOCJ9	2020-11-05 04:07:56.659869+00
ysugpwof02rkjxwz44yfbo5slt64a7jq	ZWMzOGZlNzRlMGY5YzdiMzIwMDkzNWE5NjIzODJiOTNiNzgxZDFiZTp7Il9hdXRoX3VzZXJfaWQiOiI0MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZmM4MjZhZjgyNWE1ZDE2NmI0YTVlN2Q2ZTIxY2M1MTE1YjFkNTNkOCJ9	2020-11-20 06:26:53.243414+00
zgp1lqwsagt6b7b3a5gymue391gc26kg	MGVhZDcxMTRjNmY1ZTRlNzVhZjY3OWEwMjdkNDdhMzFmZjUzZGYyZjp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJwekdZa2FKaFFUcnNBY3RRZ0RTTEdZR3dhR3A4eVBoSSJ9	2020-12-12 14:08:42.886479+00
m6zafkkiwr688wbanahis404fqf5kgl7	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-11-25 07:22:33.96427+00
yfmkgmm2h82hh4mu9eu7y58buh6ojxeb	YWFiODUwM2I0OTBkM2Y4YzcxYTlmZDJkZjI4ZDRjZTI0MDg0ODE4Zjp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiIzMzlvYmNyYjRtRjJKb1F4OTQySTRETzNOb295cVNPMCJ9	2020-11-06 08:57:06.283168+00
mgcx79inq5qeo4uswnnoececny7k2wgm	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-11-02 11:17:26.146793+00
hkbljjfb75tj74f1tpktr80ir9gw7hln	ZWMzOGZlNzRlMGY5YzdiMzIwMDkzNWE5NjIzODJiOTNiNzgxZDFiZTp7Il9hdXRoX3VzZXJfaWQiOiI0MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZmM4MjZhZjgyNWE1ZDE2NmI0YTVlN2Q2ZTIxY2M1MTE1YjFkNTNkOCJ9	2020-12-09 02:52:24.285207+00
qeqnnnd118qdg2xura9d2ghlg5xd294m	MzRjYzJjZjA1YTlkZDUwMzdiNjYwZmI1MGQ5NmQ5NWRmNTRjZTFjMTp7Il9hdXRoX3VzZXJfaWQiOiI2MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzdiNDc4NjI0ZWI1ZmZlZTQyNTdkZTNiMGRiY2JlZjVmMjIxNzMxMyJ9	2020-11-14 07:24:14.476921+00
fz4l9xyt9lcye8ghymgsq8a2mwdnzmrr	OGRhN2YxOTEwNzA2OTgwNzNjMDhmZjNlNGEyYjFhYmNkNjk3ZWI0Mjp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJKWlM2WjVzdEQyRFA2UElPVHc4enRVOUQ0anhXZDMzQiIsIl9hdXRoX3VzZXJfaWQiOiI4OCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6InNvY2lhbF9jb3JlLmJhY2tlbmRzLmdvb2dsZS5Hb29nbGVPQXV0aDIiLCJfYXV0aF91c2VyX2hhc2giOiJhZGU3NmEwMzA2ZDA1OWQ4YzMyN2Y1Y2NiMmI5YjQxYmEzNGMwZThmIiwic29jaWFsX2F1dGhfbGFzdF9sb2dpbl9iYWNrZW5kIjoiZ29vZ2xlLW9hdXRoMiJ9	2020-12-04 08:58:04.663625+00
hzlqm85sskbhsps06gitu81uyabdonvs	YmFmMGE1YTIwMGJiZWUyODY0MDkyYWEyM2ViNzk4NzliYzAwNzM1ZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3MTJkMDc3OTBkY2ZlMjk1ODg3Mjk1YWRlYTVlNmY5M2QxYWVjODM3In0=	2020-11-04 05:42:40.583124+00
bsif2pfeo256eww6wgtf24st0m77hn6v	NjRlNGQzOTFmNjkwZWUzYzY5ZGM4ODk3ZTYyODYyNjg4ZTA0M2I2NDp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJRcVRhVFlKdENCWEdsUGtBYXNEWE1NcU41bDhnV3cyZSJ9	2020-12-10 02:26:02.298623+00
w9hrvlexkc73mt4nk5jtfhba9g27hno9	NWMzOGI4Mjc4Nzg0YmUyYjA1MjhjYzkxZDZkMzc5NGE2ZDNhNTU1Nzp7Il9hdXRoX3VzZXJfaWQiOiIxMyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNjExZTA3MzhjZjU4YjBiMGI4YmY3YTJmNGI5MmIwMzg3YmVjNWFmNyJ9	2020-12-04 16:52:55.275042+00
e11j6dx7n1gmcqtk6yhi8s3igi2elgh7	YjUyMDM5NGU1Mzg3OTllYzI5YTRlMTg5NjFiODQ1NTQ5NWIyOTkzODp7Il9wYXNzd29yZF9yZXNldF90b2tlbiI6IjVsdS0xY2NmZDM1OGI0MTNjNjBmNTc3MiJ9	2020-12-06 19:48:09.993876+00
s15xh9wfxx0vphtyl5gsozarghimw84f	NzgwODlhMmM4NjdhMmY2Nzg5YWI5NzAxYzFiNzQxYTBiZDIyNGY1Mjp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJPOUc2aHdZVk9VbWJ5cEFVZVVkZ3h5czk1bFdmeVlYMSJ9	2020-12-02 06:02:34.90847+00
r6hlsjyc6d5p28es1zhvqlvbh6srpqhn	NTY1ZDVlYjc0MjBjY2I5NmUzMjY5OGRjYjA5YTVhMjA5YzY2YjFlOTp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJBTElHSXpaRVdpU1B3OGFOY1o4c2Z5QjMxWGdqblhGVCJ9	2020-12-12 14:08:43.357265+00
d1dcegehl7dvo237wzwdoyf2622ocw9p	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-11-05 05:54:01.303453+00
wadn3smltuw2gmnsard935jr9brgstsi	MTRmM2RmMThlMGI3MmI1MmY4ZDZjOTA2MzJlYmY2OGZmMzNiYjFjNDp7Il9hdXRoX3VzZXJfaWQiOiI3MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNWNlYTlkODY5YWZjMjI0ZTg4MThlYzc1OWNjN2E0ODhiMGNhYTgwZiJ9	2020-11-27 03:08:33.294794+00
7yv7zeldolh105j9jdtzy0s1s6k5ckov	NWUwMmJiZGZkZjhmMWQyMjk1ZTU1NjE5OWFlMDk1NDdmNjdhNjg4YTp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJoRURWZVZMVVRCMmJOMUR4N3p3Tk8zbjgya05mTUNSSyJ9	2020-12-09 03:16:19.7074+00
jkiwbemwtw7l4om1gpkoo3kpw17vn2ig	ZWMzOGZlNzRlMGY5YzdiMzIwMDkzNWE5NjIzODJiOTNiNzgxZDFiZTp7Il9hdXRoX3VzZXJfaWQiOiI0MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZmM4MjZhZjgyNWE1ZDE2NmI0YTVlN2Q2ZTIxY2M1MTE1YjFkNTNkOCJ9	2020-11-05 04:08:55.927348+00
mmr05xw6kztxellk3tvysf5wfk4ywgya	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-11-07 12:28:23.819691+00
x8sry9qr9uxk6xj78va90umn2wgrwfju	MzRjYzJjZjA1YTlkZDUwMzdiNjYwZmI1MGQ5NmQ5NWRmNTRjZTFjMTp7Il9hdXRoX3VzZXJfaWQiOiI2MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzdiNDc4NjI0ZWI1ZmZlZTQyNTdkZTNiMGRiY2JlZjVmMjIxNzMxMyJ9	2020-11-26 13:06:55.02613+00
f7tkmsjinorm8b5qgo6lht0o8trmk7a8	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-11-25 04:49:34.170538+00
50yjhlb6qfs67sdwbwqcgfrkrkqok6cd	MWYxYzE1YTJkNTQ5MmRjODJmZDZkM2IzYTNlZjY5NTA0NjdmODIzNTp7Il9hdXRoX3VzZXJfaWQiOiI4NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZTMwZDM5ZWQxYzk3MjU0ZmI4ZWQ0YmM5NmNkMDBjNWE1MzJmZGEwMiJ9	2020-11-17 02:59:15.823438+00
up5vvi4q5v8qo8xwr49toygz3dwymicf	ZGFkYWM1NzJkODUzNjgxZDk5ZjEzMTRmZGQ4YWEyZTYzOGFmNGU0ZTp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMTVlN2NjOTM3NGYwYTkxZjhiNTA4ZmMyMjFiMTMyYTZkMWUwMWE2NyJ9	2020-12-10 01:51:15.350458+00
bax9kfi3qyhl85kn7oymcm96lhknfqkb	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-11-11 08:13:40.72239+00
js2164tx533ccjw540cdvlkkmxuy45yg	MGY1ODhmY2MyYzgzM2VmMDY1MGZkMDFlMjYxMDZmNjJjZTczOGUyZjp7Il9hdXRoX3VzZXJfaWQiOiI3NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNmM2M2UxY2M4MDgzZmYzZDc0MjI3ZWE4ODlhMmRkZTY1ZmQ3NWUzYiJ9	2020-12-10 05:11:28.844484+00
guiu6elewa830amob80i1rpbzqsxho1f	YWI1YmI0YTA4MDJkNjVkMGNiZjVhZWUwZjBjYjI0YzEyMWM4ZmE4Njp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJMYU9sMGY0MHJ2OVV1VXMzUTloakpXS3E2cUF5YVozMyJ9	2020-11-28 15:01:54.613383+00
rbonsib7kfulhb97n8c0d6gprul9beol	NWZjZmNmMWEzYWQxM2JjMjQ0NTVkY2VjY2FmMDE1YmNhNTFkZjk5Zjp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJ1Z1B1dVBVcTI3ejRPVVhmVVhYcXA3Q05aVGxnOFBNUyJ9	2020-11-24 13:17:23.370301+00
lzlc822vmdhcxxykmhlt95inxoqvlp27	MWYxYzE1YTJkNTQ5MmRjODJmZDZkM2IzYTNlZjY5NTA0NjdmODIzNTp7Il9hdXRoX3VzZXJfaWQiOiI4NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZTMwZDM5ZWQxYzk3MjU0ZmI4ZWQ0YmM5NmNkMDBjNWE1MzJmZGEwMiJ9	2020-12-12 07:27:19.815092+00
i7m3dtlf269w6kwu34y7ll0kvt8ykup5	M2I1NDkxZTFhZTI0NDQyMThhMmM5YWYzYTExMDBhYjgzNjE2YTQ1Yzp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiJBUXVNM3VpZ1lhdVRhQ0ZOeVJnR2Z0eEdLa2ZBeEV4OCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3MTJkMDc3OTBkY2ZlMjk1ODg3Mjk1YWRlYTVlNmY5M2QxYWVjODM3In0=	2020-12-12 09:20:31.070471+00
be1g5obqu8q2agzzlblcweb6g7r3kq0d	YWNiMzU2NjUyZTcwYzI5OTkzZWRmYjI4Y2E4ZTYwYmE2OWZkMmY3NTp7fQ==	2020-11-11 12:57:48.532174+00
2c5hznr9u29v6f265ly9h7j206rea1s2	MzQ2MWZkNDdlMjBlYjBiYmM3Yzc1MzZlN2JkNTczMzkyMzljY2Y3ZDp7Imdvb2dsZS1vYXV0aDJfc3RhdGUiOiI2Nmd2bktPVUFOMnVaWDlrdkJkSkZZOXhwSTI1MEJ6ZCJ9	2020-12-12 14:08:43.993987+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: drupphuser1
--

COPY public.django_site (id, domain, name) FROM stdin;
1	www.drupph.com	drupph
\.


--
-- Data for Name: giftcard_giftcard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.giftcard_giftcard (id, code, created, start_date, end_date, last_used_on, is_active, initial_balance, current_balance, user_id) FROM stdin;
\.


--
-- Data for Name: impersonate_impersonationlog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.impersonate_impersonationlog (id, session_key, session_started_at, session_ended_at, impersonating_id, impersonator_id) FROM stdin;
1	5a6f58b687d5bc0f01d76f47a23312b2dc922b44	2020-10-25 07:06:31.594151+00	\N	10	13
2	7c1eec44bb6cee02caeb9e2f8f8f33bcc4500efb	2020-10-25 13:28:47.705893+00	\N	45	13
3	494e4bf9c84d484e70261361d618334cd7634d02	2020-10-25 14:13:19.51793+00	\N	64	13
4	2cc07a08a2eff08806713451136903d09ed739fb	2020-10-25 14:33:22.248333+00	\N	49	13
5	187338f7455678595cd14aba40f1f1745fe17eb7	2020-10-25 14:35:16.635679+00	\N	45	13
6	ddb087dfaca33d648efd06f0ccb25f52240784ea	2020-10-25 15:22:40.871256+00	\N	87	13
7	0292a86a71929fc4e7b69a990e3a0f134ee7193a	2020-10-25 15:49:37.014428+00	\N	87	13
8	8c0741c15b1d354386b78f28f930d935621abd46	2020-10-27 03:18:19.339939+00	\N	49	13
9	a8f8250f7e297f316ae149320f90b367f3d93587	2020-10-27 03:20:31.210984+00	\N	49	13
10	abe8bf0793dddc264dc9b6799d7dbef15bed4ada	2020-10-27 03:22:19.189479+00	\N	52	13
11	ccc72dc3c9d3e41c5e3f008220a0ed35207f71ab	2020-10-27 05:11:42.289067+00	\N	53	13
12	6d5bff7eefb3d9e073d549cba01fd02289df76e3	2020-10-27 07:02:51.664584+00	\N	52	13
13	4a9c50b5b9a67fb83621733cc03c79998fb88b46	2020-10-27 07:14:51.473069+00	\N	49	13
14	77c6bf984c00ea7f49338c3a40145fc4edfbaf8d	2020-10-27 07:15:54.645675+00	\N	70	13
15	13be9e9c0b720830f4e0c075edf74bd846056eb6	2020-10-27 07:17:36.495128+00	\N	49	13
16	a40f8f2921d3c91fd4eb175017b09dfda345a5f3	2020-10-31 01:51:14.622475+00	\N	53	13
17	0d5b7a538906e0d92a77924e43fa2e60987271be	2020-10-31 08:42:25.662692+00	\N	53	13
18	f5d93aa5288af105b12b495551e72a858b5940ea	2020-10-31 10:15:52.361606+00	\N	70	1
19	094532ed3fe38c1ae5548c89a99ff8d9f0f32f43	2020-10-31 16:37:57.858109+00	2020-10-31 16:38:35.600075+00	70	1
\.


--
-- Data for Name: menu_menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_menu (id, name, json_content) FROM stdin;
1	navbar	[]
2	footer	[]
\.


--
-- Data for Name: menu_menuitem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_menuitem (id, name, sort_order, url, lft, rght, tree_id, level, category_id, collection_id, menu_id, page_id, parent_id) FROM stdin;
\.


--
-- Data for Name: menu_menuitemtranslation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_menuitemtranslation (id, language_code, name, menu_item_id) FROM stdin;
\.


--
-- Data for Name: order_fulfillment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_fulfillment (id, tracking_number, shipping_date, order_id, fulfillment_order, status) FROM stdin;
1	0123456789	2020-11-24 15:28:01.003956+00	4	1	fulfilled
\.


--
-- Data for Name: order_fulfillmentline; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_fulfillmentline (id, order_line_id, quantity, fulfillment_id) FROM stdin;
1	5	1	1
\.


--
-- Data for Name: order_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_order (id, created, tracking_client_id, user_email, token, billing_address_id, shipping_address_id, user_id, total_net, discount_amount, discount_name, voucher_id, language_code, shipping_price_gross, total_gross, shipping_price_net, status, shipping_method_name, shipping_method_id, display_gross_prices, translated_discount_name, customer_note, weight, checkout_token, pickup_datetime) FROM stdin;
1	2020-11-04 04:46:09.496023+00	bb71a501-88ed-52ba-bad8-5a5a86c091c0	digitaldelacruz@gmail.com	5d6fb8df-502e-4784-b0a9-427f66dca9d0	31	\N	88	1100.00	0.00		\N	en	0.00	1100.00	0.00	unfulfilled	\N	\N	t		1278 Syson St.	0	ecfe447b-8f51-4167-b9bd-7ef2684b9d6b	2020-11-04 16:12:09.472294+00
2	2020-11-12 04:56:35.648435+00	652f6d5d-d516-5be0-85d2-f72e975d8ad5	charleston.drupph@gmail.com	194fbe1c-f19e-4caa-baa6-636f5001b4fc	33	\N	98	100.00	0.00		\N	en	0.00	100.00	0.00	unfulfilled	\N	\N	t		testing	0	60c251bb-bb1e-4838-a69b-cabc05a2ecc6	2020-11-12 07:00:35.626361+00
3	2020-11-18 06:18:12.282521+00	c0d85de7-5f27-5811-98d7-b73b8000975a	charlestonz3r0@gmail.com	3ad005da-fd6e-4b21-92e2-a83d7ba9e5a9	35	\N	94	100.00	0.00		\N	en	0.00	100.00	0.00	unfulfilled	\N	\N	t			0	0d2262a1-d1db-4a93-aa52-a47514af651b	2020-11-19 09:50:12.255461+00
4	2020-11-18 06:47:35.351492+00	c0d85de7-5f27-5811-98d7-b73b8000975a	charlie.drupph@gmail.com	ce9cc785-45f1-4816-8522-068ec6b1aacf	37	\N	95	100.00	0.00		\N	en	0.00	100.00	0.00	fulfilled	\N	\N	t			0	5f867df8-52c0-4003-9c4a-a4a2970dd89f	2020-11-19 07:50:35.326017+00
\.


--
-- Data for Name: order_order_gift_cards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_order_gift_cards (id, order_id, giftcard_id) FROM stdin;
\.


--
-- Data for Name: order_orderevent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_orderevent (id, date, type, order_id, user_id, parameters, additional_note) FROM stdin;
1	2020-11-04 04:46:09.512224+00	placed	1	88	{}	
2	2020-11-04 04:46:12.272091+00	email_sent	1	88	{"email": "digitaldelacruz@gmail.com", "email_type": "order_confirmation"}	
3	2020-11-12 04:56:35.659053+00	placed	2	98	{}	
4	2020-11-12 04:56:38.368547+00	email_sent	2	98	{"email": "charleston.drupph@gmail.com", "email_type": "order_confirmation"}	
5	2020-11-18 06:18:12.292551+00	placed	3	94	{}	
6	2020-11-18 06:18:14.994305+00	email_sent	3	94	{"email": "charlestonz3r0@gmail.com", "email_type": "order_confirmation"}	
7	2020-11-18 06:47:35.359495+00	placed	4	95	{}	
8	2020-11-18 06:47:38.05058+00	email_sent	4	95	{"email": "charlie.drupph@gmail.com", "email_type": "order_confirmation"}	
9	2020-11-24 15:28:01.046878+00	fulfillment_fulfilled_items	4	89	{"fulfilled_items": [1]}	
10	2020-11-24 15:28:05.091856+00	email_sent	4	89	{"email": "charlie.drupph@gmail.com", "email_type": "fulfillment_confirmation"}	
\.


--
-- Data for Name: order_orderline; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_orderline (id, product_name, product_sku, quantity, unit_price_net, unit_price_gross, is_shipping_required, order_id, quantity_fulfilled, variant_id, tax_rate, translated_product_name) FROM stdin;
1	Alaxan FR (Alaxan FR)	ANA-MED-001	5	120.00	120.00	f	1	0	15	0.00	
2	Biogesic (Biogesic)	ANA-MED-001	2	250.00	250.00	f	1	0	16	0.00	
3	Colgate (Colgate)	MED-0001	1	100.00	100.00	f	2	0	233	0.00	
4	Colgate (Colgate)	MED-0001	1	100.00	100.00	f	3	0	233	0.00	
5	Colgate (Colgate)	MED-0001	1	100.00	100.00	f	4	1	233	0.00	
\.


--
-- Data for Name: page_page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.page_page (id, slug, title, content, created, is_published, publication_date, seo_description, seo_title, content_json) FROM stdin;
\.


--
-- Data for Name: page_pagetranslation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.page_pagetranslation (id, seo_title, seo_description, language_code, title, content, page_id, content_json) FROM stdin;
\.


--
-- Data for Name: payment_payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_payment (id, gateway, is_active, created, modified, charge_status, billing_first_name, billing_last_name, billing_company_name, billing_address_1, billing_address_2, billing_city, billing_city_area, billing_postal_code, billing_country_code, billing_country_area, billing_email, customer_ip_address, cc_brand, cc_exp_month, cc_exp_year, cc_first_digits, cc_last_digits, extra_data, token, currency, total, captured_amount, checkout_id, order_id) FROM stdin;
1	dummy	t	2020-11-12 04:56:51.71889+00	2020-11-12 04:56:51.718915+00	not-charged	testing	testing	testing		testing	TESTING		4200	PH	Batangas	charleston.drupph@gmail.com	119.95.163.135		\N	\N			{'customer_user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36 OPR/72.0.3815.186'}		PHP	100.00	0.00	\N	2
2	dummy	t	2020-11-18 06:18:23.401285+00	2020-11-18 06:18:23.401313+00	not-charged	test	test	test	test	test	BATANGAS CITY		4200	PH	Batangas	charlestonz3r0@gmail.com	119.95.163.135		\N	\N			{'customer_user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36 OPR/72.0.3815.320'}		PHP	100.00	0.00	\N	3
3	dummy	t	2020-11-18 06:47:41.320959+00	2020-11-18 06:47:41.320985+00	not-charged	test	test	test	test	test	BATANGAS CITY		4200	PH	Batangas	charlie.drupph@gmail.com	119.95.163.135		\N	\N			{'customer_user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36 OPR/72.0.3815.320'}		PHP	100.00	0.00	\N	4
\.


--
-- Data for Name: payment_transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_transaction (id, created, token, kind, is_success, error, currency, amount, gateway_response, payment_id, customer_id) FROM stdin;
1	2020-11-12 04:56:58.518372+00	not-charged	auth	t	\N	PHP	100.00	{}	1	\N
\.


--
-- Data for Name: portal_carousel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.portal_carousel (id, image, ppoi, title, description, "order") FROM stdin;
3	ads/carousel/function_uuid4_at_0x7f8e38683710_ZQfhHNo.jpg	0.5x0.5	Slide 3	<div style="margin: 0.5rem;">&nbsp;</div>	3
4	ads/carousel/function_uuid4_at_0x7f8e38683710_aSJojji.jpg	0.5x0.5	Slide 4	<div style="margin: 0.5rem;">&nbsp;</div>	4
1	ads/carousel/function_uuid4_at_0x7f2619562710.jpg	0.5x0.5	First Slide	<div style="margin: 0.5rem;">&nbsp;</div>	0
2	ads/carousel/function_uuid4_at_0x7f809b6f8710.jpg	0.5x0.5	Slide 2	<div style="margin: 0.5rem;">&nbsp;</div>	2
5	ads/carousel/function_uuid4_at_0x7f809b6f8710_bz4um7M.jpg	0.5x0.5	Slide 5	<div style="margin: 0.5rem;">&nbsp;</div>	5
\.


--
-- Data for Name: portal_carousellinks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.portal_carousellinks (id, url, caption, "order", carousel_id) FROM stdin;
1	/en/search/location/	Store Locator	1	1
\.


--
-- Data for Name: product_attribute; Type: TABLE DATA; Schema: public; Owner: drupphuser1
--

COPY public.product_attribute (id, slug, name, product_type_id, product_variant_type_id) FROM stdin;
12	liquid	Liquid	\N	\N
13	tablet	Tablet	\N	\N
14	toothpaste	Toothpaste	\N	\N
15	softgel_capsule	Softgel Capsule	\N	\N
16	suspension	Suspension	\N	\N
17	soap	Soap	\N	\N
18	face__body_soap	Face  Body Soap	\N	\N
19	eye_drops	Eye Drops	\N	\N
20	sustained_release_tablet	Sustained Release Tablet	\N	\N
21	disinfectant	Disinfectant	\N	\N
11	syrup	Syrup	\N	\N
10	capsules	Capsules	\N	\N
23	oral_solutuon	Oral Solutuon	\N	\N
24	per_box	per box	\N	\N
25	shampoo	Shampoo	\N	\N
26	astringent_powder	astringent powder	\N	\N
27	milk	Milk	\N	\N
28	generic	Generic	\N	\N
30	ophthalmic_solutions	Ophthalmic Solutions	\N	\N
31	generic_name	Generic Name	\N	\N
32	alaxan_generic_name	Generic Name	\N	\N
33	powder	Powder	\N	\N
34	plastic_strips	Plastic Strips	\N	\N
35	promo_pack	Promo Pack	\N	\N
\.


--
-- Data for Name: product_attributetranslation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_attributetranslation (id, language_code, name, attribute_id) FROM stdin;
\.


--
-- Data for Name: product_attributevalue; Type: TABLE DATA; Schema: public; Owner: drupphuser1
--

COPY public.product_attributevalue (id, name, attribute_id, slug, sort_order, value) FROM stdin;
11	15mg5ml	12	15mg5ml	0	
12	500 mg	13	500_mg	0	
13	350 oz	14	350_oz	0	
14	200mg	15	200mg	0	
15	120mg5ml	16	120mg5ml	0	
16	100mg	17	100mg	0	
17	100gm	18	100gm	0	
18	10ml	19	10ml	0	
19	50mg	20	50mg	0	
20	500ml	21	500ml	0	
27	250mL	11	250ml	0	
28	500mL	11	500ml	1	
29	120mL	11	120ml	2	
30	60mL	11	60ml	3	
34	250mg	10	250mg	0	
35	500mg	10	500mg	1	
36	0.5mg	10	0.5mg	2	
37	0.3mg	10	0.3mg	3	
38	600mg	23	600mg	0	
39	2200	24	2200	0	
40	120mL	25	120ml	0	
41	astringent powder	26	astringent_powder	0	
42	1.2 Kg	27	1.2_kg	0	
43	Yes	28	yes	0	
59	5ml	30	5ml	0	
60	10ml	30	10ml	1	
61	15ml	30	15ml	2	
62	Paracetamol and Ibuprofen	31	paracetamol_and_ibuprofen	0	
64	20	33	20	0	
65	Box of 100s	34	box_of_100s	0	
66	175gm Tubes x2	35	175gm_tubes_x2	0	
67	Php139.00	35	php139.00	1	
\.


--
-- Data for Name: product_attributevaluetranslation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_attributevaluetranslation (id, language_code, name, attribute_value_id) FROM stdin;
\.


--
-- Data for Name: product_category; Type: TABLE DATA; Schema: public; Owner: drupphuser1
--

COPY public.product_category (id, name, slug, description, lft, rght, tree_id, level, parent_id, background_image, seo_description, seo_title, background_image_alt, description_json) FROM stdin;
93	SCALP & HAIR CARE	scalp-hair-care		1	2	28	0	\N					{}
97	BEVERAGES	beverages		1	2	32	0	\N					{}
146	ANTI-ALLERGY	anti-allergy		1	2	36	0	\N					{}
152	ANTIDYSLIPIDIMIC	antidyslipidimic		1	2	42	0	\N					{}
153	ANTI-HEMORHOIDS	anti-hemorhoids		1	2	43	0	\N					{}
156	ANTI-INFECTIVES	anti-infectives		1	2	46	0	\N					{}
157	ANTIVIRAL	antiviral		1	2	47	0	\N					{}
159	DERMATOLOGY	dermatology		1	2	49	0	\N					{}
164	FIRST AID & SUPPLIES	first-aid-supplies		1	2	54	0	\N					{}
179	PAIN & FEVER	pain-fever		1	2	69	0	\N					{}
184	BATH	bath		1	2	74	0	\N					{}
196	MILK, DIET & FITNESS	milk-diet-fitness		1	2	86	0	\N					{}
95	ENERGY & SPORTS DRINK	energy-sports-drink		1	2	30	0	\N					{}
94	FEMININE PRODUCTS	feminine-products		1	2	29	0	\N					{}
175	NUTRITION	nutrition		1	2	65	0	\N					{}
201	Mask	mask		2	11	71	1	181		\N	\N		{}
202	Disposable	disposable		3	10	71	2	201		\N	\N		{}
58	ONCOLOGY	oncology		1	2	2	0	\N					{}
81	COUGH & COLDS	cough-colds		1	2	16	0	\N					{}
69	CARDIOVASCULAR	cardiovascular		1	2	4	0	\N					{}
78	ORAL & DENTAL CARE	oral-dental-care		1	2	13	0	\N					{}
147	ANESTHESIA & SURGERY	anesthesia-surgery		1	2	37	0	\N					{}
158	CENTRAL NERVOUS SYSTEM	central-nervous-system		1	2	48	0	\N					{}
166	GALENICALS	galenicals		1	2	56	0	\N					{}
177	OTHER HEALTHCARE ESSENTIALS	other-healthcare-essentials		1	2	67	0	\N					{}
188	HAND & FOOT CARE	hand-foot-care		1	2	78	0	\N					{}
197	OFFICE & SCHOOL SUPPLIES	office-school-supplies		1	2	87	0	\N					{}
203	3 Ply	3ply		4	5	71	3	202		\N	\N		{}
204	5 Ply	5ply		6	7	71	3	202		\N	\N		{}
148	ANTI-ANGINA	anti-angina		1	2	38	0	\N					{}
160	ENDOCRINE & METABOLLIC SYSTEM	endocrine-metabollic-system		1	2	50	0	\N					{}
163	FAMILY PLANNING	family-planning		1	2	53	0	\N					{}
170	HEALTH DEVICES & EQUIPMENTS	health-devices-equipments		1	2	60	0	\N					{}
178	OTHER THERAPEUTIC PRODUCTS	other-therapeutic-products		1	2	68	0	\N					{}
189	MEN'S PRODUCTS	mens-products		1	2	79	0	\N					{}
198	OTHER CONSUMER GOODS	other-consumer-goods		1	2	88	0	\N					{}
149	ANTI-ASTHMA	anti-asthma		1	2	39	0	\N					{}
154	ANTIHYPERTENSIVE	antihypertensive		1	2	44	0	\N					{}
165	FOOD & HERBAL SUPPLEMENTS	food-herbal-supplements		1	2	55	0	\N					{}
173	MUSCULO-SKELETAL	musculo-skeletal		1	2	63	0	\N					{}
180	RADIOGRAPHIC & OTHER DIAGNOSTIC AGENTS	radiographic-other-diagnostic-agents		1	2	70	0	\N					{}
185	BEAUTY CARE	beauty-care		1	2	75	0	\N					{}
186	COSMETICS	cosmetics		1	2	76	0	\N					{}
187	FRAGRANCE	fragrance		1	2	77	0	\N					{}
191	SANITARY PROTECTION	sanitary-protection		1	2	81	0	\N					{}
199	OTHER HOUSEHOLD ESSENTIALS	other-household-essentials		1	2	89	0	\N					{}
150	ANTIDIABETIC	antidiabetic		1	2	40	0	\N					{}
161	EYE & EAR CARE	eye-ear-care		1	2	51	0	\N					{}
171	IMMUNOLOGY	immunology		1	2	61	0	\N					{}
172	LIVER MEDICINES	liver-medicines		1	2	62	0	\N					{}
182	STERILE TOPICAL PREPARATIONS	sterile-topical-preparations		1	2	72	0	\N					{}
192	SKIN CARE	skin-care		1	2	82	0	\N					{}
168	GENITO-URINARY	genito-urinary		1	2	58	0	\N					{}
176	OPHTHALMOLOGY	ophthalmology		1	2	66	0	\N					{}
200	FOOD	food		1	2	90	0	\N					{}
181	RESPIRATORY	respiratory		1	12	71	0	\N					{}
206	10 ply	10-ply		8	9	71	3	202		\N	\N		{}
151	ANTIDOTES & OTHER DETOXIFYING AGENTS	antidotes-other-detoxifying-agents		1	2	41	0	\N					{}
155	ANTI-HYPERURECEMIA	anti-hyperurecemia		1	2	45	0	\N					{}
162	ENT	ent		1	2	52	0	\N					{}
169	GERIATRIC CARE	geriatric-care		1	2	59	0	\N					{}
183	VITAMINS & MINERALS	vitamins-minerals		1	2	73	0	\N					{}
190	OTHER PERSONAL CARE PRODUCTS	other-personal-care-products		1	2	80	0	\N					{}
193	BABY & KIDS PRODUCTS	baby-kids-products		1	2	83	0	\N					{}
194	COOKING	cooking		1	2	84	0	\N					{}
195	LAUNDRY	laundry		1	2	85	0	\N					{}
174	GASTRO-INTESTINAL	gastro-intestinal		1	2	64	0	\N					{}
\.


--
-- Data for Name: product_categorytranslation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_categorytranslation (id, seo_title, seo_description, language_code, name, description, category_id, description_json) FROM stdin;
\.


--
-- Data for Name: product_collection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_collection (id, name, slug, background_image, seo_description, seo_title, is_published, description, publication_date, background_image_alt, description_json) FROM stdin;
\.


--
-- Data for Name: product_collectionproduct; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_collectionproduct (id, collection_id, product_id, sort_order) FROM stdin;
\.


--
-- Data for Name: product_collectiontranslation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_collectiontranslation (id, seo_title, seo_description, language_code, name, collection_id, description, description_json) FROM stdin;
\.


--
-- Data for Name: product_digitalcontent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_digitalcontent (id, use_default_settings, automatic_fulfillment, content_type, content_file, max_downloads, url_valid_days, product_variant_id) FROM stdin;
\.


--
-- Data for Name: product_digitalcontenturl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_digitalcontenturl (id, token, created, download_num, content_id, line_id) FROM stdin;
\.


--
-- Data for Name: product_product; Type: TABLE DATA; Schema: public; Owner: drupphuser1
--

COPY public.product_product (id, name, description, price, publication_date, updated_at, product_type_id, attributes, is_published, category_id, seo_description, seo_title, charge_taxes, weight, description_json, meta, created_at) FROM stdin;
186	RITEMED Ambroxol Tablet (30mg)	RITEMED Ambroxol Tablet\r\nPotency: 30 mg\r\nForm: Tablet, White\r\nTherapeutic Use:\r\nDirections:\r\nPharmacist's Reminders:	5.50	\N	2020-10-25 15:54:00.455399+00	44		t	81	\N	\N	f	\N	{}	{}	2020-10-25 15:27:18.813106+00
306	Myra E 8's	d-Alpha Tocopherol (Vitamin E)\r\n400 I.U. Softgel Capsule	\N	\N	2020-11-03 07:06:43.432152+00	44		f	183	\N	\N	f	\N	{}	{}	2020-11-03 07:06:43.432183+00
65	Fern-c 30's	Sodium Ascorbic\r\n\r\nNon-acidic Vitamin C	216.00	\N	2020-10-25 13:32:51.459771+00	44		t	183	\N	\N	f	\N	{}	{}	2020-09-22 08:58:18.428685+00
64	Clusivol Plus	Multivitamins + Zinc + Copper	8.00	\N	2020-10-25 13:33:07.845682+00	44		t	183	\N	\N	f	\N	{}	{}	2020-09-22 08:54:26.222589+00
63	Conzace Capsule	Multivitamins + Minerals	16.00	\N	2020-10-25 13:33:26.941583+00	44		t	183	\N	\N	f	\N	{}	{}	2020-09-22 08:50:06.221712+00
25	Tampax	Tampax	1200.00	\N	2020-10-25 13:55:25.447805+00	45		t	191	\N	\N	f	\N	{}	{}	2020-09-09 16:39:26.390926+00
16	Biogesic	Biogesic	250.00	\N	2020-10-25 16:41:48.135344+00	44		t	179	\N	\N	f	\N	{}	{}	2020-09-09 16:17:58.243882+00
309	Ambroxol 6mg/mL	Ambroxol 6mg/mL Oral Drops\r\nMucolytic	30.00	\N	2020-11-03 08:00:13.664625+00	44		t	81	\N	\N	f	\N	{}	{}	2020-11-03 08:00:13.664652+00
26	Vicks-44	Vicks-44	790.00	\N	2020-11-07 10:16:10.659935+00	44		t	81	\N	\N	f	\N	{}	{}	2020-09-09 16:40:20.617644+00
278	Lady (ETHINYL ESTRADIOL + LEVONORGESTREL) Hormonal Contraceptive	Lady is a hormonal contraceptive containing Ethinyl Estradiol 30mcg and Levonogestrel 130mcg in Tablet form. Available in box of 28's.	0.00	\N	2020-11-04 08:14:21.092451+00	44		t	163	\N	\N	f	\N	{}	{}	2020-11-03 04:22:12.422446+00
21	Nestle Crunch	Nestle Crunch	120.00	\N	2020-10-25 14:04:38.943023+00	46		t	200	\N	\N	f	\N	{}	{}	2020-09-09 16:31:50.796741+00
17	Enervon-C	Enervon-C	250.00	\N	2020-10-25 14:27:59.143004+00	44		t	183	\N	\N	f	\N	{}	{}	2020-09-09 16:19:09.598531+00
23	Polysporin	Polysporin	1800.00	\N	2020-10-25 14:29:40.079351+00	44		t	182	\N	\N	f	\N	{}	{}	2020-09-09 16:37:05.482951+00
20	Neozep	Neozep	160.00	\N	2020-10-25 14:30:10.215305+00	44		t	81	\N	\N	f	\N	{}	{}	2020-09-09 16:24:08.446835+00
237	Sinecod Forte (BUTAMIRATE CITRATE) 50mg SR Tsblet	Sinecod Forte is sn anti-tussive containing Butamirate Citrate 50mg in Sustained - Release (SR)  Tablet form. Recommended for cough. 	0.00	\N	2020-11-01 07:51:28.326994+00	44		t	81	\N	\N	f	\N	{}	{}	2020-10-30 00:40:52.801686+00
232	Acular (KETOROLAC TROMETAMOL) 5mg/ml Eye Drops	Rx Required.\r\nAcular contains Ketorolac Trometamol 5mg/ml is a sterile ophthalmic solution in 5ml bottle. A non-steroidal anti-inflammatory drug (NSAID) preparation for eyes.	0.00	\N	2020-11-01 07:55:48.679078+00	44		t	176	\N	\N	f	\N	{}	{}	2020-10-29 10:29:22.370589+00
248	ENERVON CAPSULE	MULTIVITAMINS AND MINERALS	7.00	\N	2020-11-02 07:21:40.881819+00	44		t	183	\N	\N	f	\N	{}	{}	2020-11-02 07:21:40.881845+00
258	Guyabano Tea	AKITA Guyabano Tea (Soursop)\r\nNO APPROVED THERAPEUTIC CLAIMS	\N	\N	2020-11-03 03:05:12.865048+00	44		f	165	\N	\N	f	\N	{}	{}	2020-11-03 03:05:12.865077+00
202	Enervon Tablet	Multivitamins (Enervon) is a nutritional supplement. It works hand in hand with food to provide the synergistic benefits of B-vitamins (namely B1, B2, B6, B12) and Vitamin C to the body. Vitamins B1 and B2 help in the body's food-to-energy conversion process.\r\n	7.00	\N	2020-10-27 03:26:16.918294+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 03:26:16.918322+00
266	Ferrous Sulfate	Iron (as Ferrous Sulfate)\r\n250mg Capsule\r\nHematinic	\N	\N	2020-11-03 03:38:02.26447+00	44		f	178	\N	\N	f	\N	{}	{}	2020-11-03 03:38:02.264498+00
207	Celine + Chewable Tablet	Ascorbic acid 20mg, Sodium ascorbate 90mg, Zinc 5mg	7.00	\N	2020-10-31 02:05:03.327246+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 05:18:14.879449+00
212	Diatabs Capsule (2mg)	Loperamide 2mg Capsule	8.00	\N	2020-10-31 02:12:28.630431+00	44		t	174	\N	\N	f	\N	{}	{}	2020-10-27 05:28:17.412045+00
216	Enervon Tablet	Multivitamins (with vitamin-C)	7.00	\N	2020-10-31 02:14:32.909392+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 05:35:42.158681+00
217	Flanax Forte (550mg)	Naproxen sodium 550mg	24.45	\N	2020-10-31 02:15:14.780017+00	44		t	173	\N	\N	f	\N	{}	{}	2020-10-27 05:36:58.272351+00
222	Pharex E (400 IU)	D-Alpha Tocopheryl acetate (Vitamin-E) 400IU	10.00	\N	2020-10-31 02:16:55.887432+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 05:49:38.948504+00
272	Xanthone Plus Capsule	Xanthone Plus capsule contains mangosteen and malunggay.	0.00	\N	2020-11-03 04:14:05.330684+00	44		t	165	\N	\N	f	\N	{}	{}	2020-11-03 04:14:05.330711+00
284	Foralivit	Ferrous Sulfate + FOLIC Acid + Vitamin B Complex\r\n\r\nUsed in the prevention and treatment of iron deficiency anemia and Vitamin B complex deficiency, prenatal hematinic.\r\n\r\n	\N	\N	2020-11-03 04:31:21.881436+00	44		f	183	\N	\N	f	\N	{}	{}	2020-11-03 04:31:21.881463+00
287	Heng De Faceshield	Anti spray\r\nAnti fogging\r\nAnti smoke\r\nOil splash proof\r\nAnti exhaust\r\n\r\n	\N	\N	2020-11-03 04:39:47.39184+00	46		f	177	\N	\N	f	\N	{}	{}	2020-11-03 04:39:47.391868+00
293	Lady Pills	Ethinyl Estradiol + Levonorgestrel\r\n30 mcg / 150 mcg Tablet \r\nHormonal Contraceptive	\N	\N	2020-11-03 04:48:08.944642+00	44		f	163	\N	\N	f	\N	{}	{}	2020-11-03 04:48:08.944672+00
295	Malunggay Tea	Malungay Tea\r\nHorse Radish (Moringa oleifera Lam.) 1.5 g\r\n\r\nNO APPROVED THERAPEUTIC CLAIMS	\N	\N	2020-11-03 05:30:52.269052+00	44		f	165	\N	\N	f	\N	{}	{}	2020-11-03 05:30:52.26908+00
300	Ming's Garlic Oil	Ming's Garlic Oil 1000mg\r\n\r\nHelps lower bad cholesterol level\r\nHelps regulate the body’s blood pressure\r\nHelps support a healthy immune system\r\nGood source of vitamin C\r\nAnti- bacterial and Anti- viral benefits	\N	\N	2020-11-03 06:55:25.225133+00	44		f	165	\N	\N	f	\N	{}	{}	2020-11-03 06:55:25.225161+00
316	Carbocisteine 250mg / 5mL	Carbocisteine 250mg / 5mL \r\nSuspension\r\nMucolytic	0.00	\N	2020-11-03 08:07:56.977209+00	44		t	81	\N	\N	f	\N	{}	{}	2020-11-03 08:07:56.977231+00
318	Cetaphil Moisturizing Cream	Moisturize your dry skin like never before! This rich cream intensely hydrates for a full 24-hours replenishing moisture for softer, smoother, healthier looking skin. Infused with a superior system of emollients and humectants to restore the skin's natural moisture barrier. 	0.00	\N	2020-11-03 08:08:38.19108+00	45		t	159	\N	\N	f	\N	{}	{}	2020-11-03 08:08:38.191109+00
312	Biogesic 100mg/mL	Biogesic (Paracetamol) \r\n100mg/mL (Oral Drops)\r\n0-2 years old\r\nAnalgesic / Antipyretic 	71.00	\N	2020-11-04 03:58:00.498022+00	44		t	179	\N	\N	f	\N	{}	{}	2020-11-03 08:01:45.956646+00
24	Robust	Robust	359.00	\N	2020-11-10 11:45:23.758937+00	44		f	165	\N	\N	f	\N	{}	{}	2020-09-09 16:38:19.807421+00
329	Shaolin Oil Liniment 50ml	Shaolin Oil Liniment is a counterirritant.	0.00	\N	2020-11-04 09:17:44.849438+00	44		t	166	\N	\N	f	\N	{}	{}	2020-11-04 09:17:44.849466+00
354	Neuronerv	Vitamin B1 + B6 + B12\r\n100mg/5mg/50mg\r\n	\N	\N	2020-11-11 02:45:14.618199+00	44		f	183	\N	\N	f	\N	{}	{}	2020-11-11 02:45:14.618228+00
347	J. Chemie Isopropyl Alcohol 500mL	J. Chemie Isopropyl Alcohol \r\n500mL	90.00	\N	2020-11-08 20:45:20.762063+00	46		f	191	\N	\N	f	\N	{}	{}	2020-11-08 20:45:20.762082+00
348	J.Chemie Ethyl Alcohol Spray	J.Chemie Ethyl Alcohol Spray\r\n250 mL	85.00	\N	2020-11-08 20:56:10.938456+00	46		t	191	\N	\N	f	\N	{}	{}	2020-11-08 20:56:10.938482+00
350	Myra E	d-Alpha Tocopherol (Vitamin E)\r\n400 I.U. Softgel Capsule	12.00	\N	2020-11-08 21:12:04.540174+00	44		t	183	\N	\N	f	\N	{}	{}	2020-11-08 21:12:04.540196+00
351	Myra E 8's	d-Alpha Tocopherol (Vitamin E)\r\n400 I.U. Softgel Capsule	96.00	\N	2020-11-08 21:13:05.354185+00	44		t	183	\N	\N	f	\N	{}	{}	2020-11-08 21:13:05.354208+00
19	MX-3	MX-3	150.00	\N	2020-11-10 11:45:52.884742+00	44		t	165	\N	\N	f	\N	{}	{}	2020-09-09 16:22:53.435659+00
253	Johnson Baby Powder	Johnson Baby Powder	100.00	\N	2020-11-22 19:39:52.620822+00	45	"33"=>"64"	f	193	\N	\N	f	\N	{}	{}	2020-11-02 22:32:17.57373+00
187	RITEMED Ascorbic Acid (500mg) 100's	RITEMED Ascorbic Acid\r\nPotency: 500mg\r\nForm: Tablet, Yellow\r\nTherapeutic Use:\r\nDirections:\r\nPharmacist's Reminders:	350.00	\N	2020-10-25 15:54:12.852297+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-25 15:28:53.433092+00
273	Colgate Plax Peppermint Fresh	Colgate Plax Peppermint Fresh\r\n\r\nThere are times when it seems no matter how many times you brush or how many mints you pop, your mouth just doesn’t feel fresh. In these cases, a 30-second rinse with powerful mouthwash after brushing can make all the difference – for up to 12 hours.\r\n\r\n \r\n\r\nThat’s where Colgate® Plax® comes in. Available in a range of refreshing flavors, this clinically tested formula also provides protection against bacteria, plaque and cavities.	\N	\N	2020-11-03 04:15:13.849185+00	45		f	78	\N	\N	f	\N	{}	{}	2020-11-03 04:15:13.849213+00
70	Myra 400 I.U	d-Alpha Tocopherol (Vitamin E)	13.00	\N	2020-10-25 13:30:59.160356+00	44		t	183	\N	\N	f	\N	{}	{}	2020-09-22 09:13:49.319635+00
238	Ming's Garlic Oil Softgel 1000mg	"A healthy heart for a healthy lifestyle" - available in box of 36 capsules	0.00	\N	2020-10-30 04:36:57.661906+00	44		t	166	\N	\N	f	\N	{}	{}	2020-10-30 00:45:17.010912+00
213	Diclofenac Sodium Tablet (5mg)	Diclofenac Sodium 50mg Tablet (NSAID)	2.00	\N	2020-10-31 02:12:52.602607+00	44		t	173	\N	\N	f	\N	{}	{}	2020-10-27 05:30:00.477+00
218	Kiddielets	Paracetamol 125mg chewable for kids	3.00	\N	2020-10-31 02:15:37.850362+00	44		t	179	\N	\N	f	\N	{}	{}	2020-10-27 05:38:33.089748+00
244	KF94 Korean Mask by HengDe	Korean Mask Disposable Facemask\r\nKF94 by HengDe\r\nWhite	55.00	\N	2020-11-20 16:28:04.673202+00	44		t	204	\N	\N	f	\N	{}	{}	2020-10-31 16:15:10.955748+00
259	Turmeric Tea	AKITA Turmeric Tea (Curcumma longa Linn.) 1.5 G\r\n\r\nNO APPROVED THERAPEUTIC CLAIMS	\N	\N	2020-11-03 03:06:13.123677+00	44		f	165	\N	\N	f	\N	{}	{}	2020-11-03 03:06:13.123706+00
223	Stresstabs	Multivitamins (with vitamin-C and iron) .	11.50	\N	2020-10-31 01:57:31.374449+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 05:50:33.512499+00
203	Ascorbic Acid (500mg)	Ascorbic acid 500mg for 12 years old and above.	6.50	\N	2020-10-31 02:03:01.130303+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 05:13:06.531729+00
208	Centrum Advance 1's	Multivitamins	11.00	\N	2020-10-31 02:05:51.254574+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 05:19:18.481969+00
267	Calmoseptine Cream	Zinc Oxide + Calamine\r\n555.7 mg / 164.5mg / 3.5 g Ointment\r\nAnti-inflammatory / Anti-pruritic\r\n	\N	\N	2020-11-03 03:39:28.489188+00	44		f	159	\N	\N	f	\N	{}	{}	2020-11-03 03:39:28.48922+00
198	Flucysteine (ACETYLCYSTEINE) 600MG Powder for Oral Solution	Rx Required: Flucysteine contains Acetylcysteine 600mg powder for oral solutions. Mucolytic recommended for persistent coughing with pleghm.	0.00	\N	2020-11-01 07:58:46.957236+00	44		t	81	\N	\N	f	\N	{}	{}	2020-10-26 05:23:43.463844+00
289	J. Chemie Isopropyl Alcohol 500mL	J. Chemie Isopropyl Alcohol \r\n500mL	\N	\N	2020-11-03 04:42:06.303253+00	46		f	191	\N	\N	f	\N	{}	{}	2020-11-03 04:42:06.303283+00
296	Ambroxol 6mg/mL	Ambroxol 6mg/mL Oral Drops\r\nMucolytic	\N	\N	2020-11-03 05:31:38.848318+00	44		f	81	\N	\N	f	\N	{}	{}	2020-11-03 05:31:38.848346+00
254	Colgate Test 1	Description Test 1	100.00	\N	2020-11-22 20:10:16.023435+00	45	"14"=>"13"	t	78	\N	\N	f	\N	{}	{}	2020-11-02 22:47:10.780536+00
74	Zinc + Vitamin D plus Prebiotic and Probiotic	The combination of Vitamin D and Zinc effective immune system defense.\r\n\r\nZinc increases our t-cells that fight off ilnesses\r\nBoost our immunity to fight viral and bacterial infections\r\n\r\nVitamin D\r\nImportant to strengthening the immune system.\r\n\r\nProbiotic and Prebiotic\r\nDecrease the incidence of common colds\r\nDecrease the incidence of ventilator assisted Pneumonia\r\nGood for overall digestive health	1650.00	\N	2020-10-25 13:29:24.244461+00	44		t	183	\N	\N	f	\N	{}	{}	2020-09-23 09:23:22.357182+00
72	Amazing Pure Organic Barley Capsule	PARA SAAN ANG BARLEY?\r\n\r\n Ang Pure Organic Barley ay nakakatulong sa mga may:\r\n\r\n● Cancer ●Tumor ● Goiter ● Myoma ● Asthma ● Arthritis ● Diabetes ● Bronchial Problem ● Prostate Problem ● High Cholesterol ● Alzheimer's ● Thyroid Problem ● Liver Problem ● Kidney Problem ● Colon Problem ● Heart Problem ● Ovarian Problems ● Poor Memory ● Stroke ● Constipation ● Urinary Track Infection (UTI) ● Weak Body ● Anemia ● Back Pain ● Cyst ● Lupus ● Dengue ● Hepatitis ● Vertigo ● Pneumonia ● Allergy ●Gall Stone, ●Kidney Stone Problems ●Hypertension/High Blood Pressure  ● Psoriasis ● Other Degenerative Diseases ●Bukol sa kahit saang parte ng katawan ●Panginginig ng katawan\r\n\r\nIto ay safe, healthy and effective. 100% All-natural at walang halong chemical. Ito din ay GLUTEN and GMO FREE.	1750.00	\N	2020-10-25 13:30:41.465102+00	44	"10"=>"none"	t	165	\N	\N	f	\N	{}	{}	2020-09-23 05:43:10.772846+00
69	Immunomax 30mg CM-Glucan Capsule	Did you know that immunomodulation is pretty much the foundation of a healthy immunity?\r\n\r\n \r\n\r\nWhen it comes to your immune cells, balance is key. That means there are no weak cells and no overactive cells. If any of the two instances happen, you develop symptoms. Your immune system’s balancing act is called immunomodulation.\r\n\r\n \r\n\r\nThankfully, the scientists at Intermed worked hard to innovate a highly-soluble yeast extract called CM-glucan using a Swiss- patented technology. It’s an immunomodulator that updates, regulates and modulates cells in your immune system.\r\n\r\n \r\n\r\nSo if you’re concerned about your health, take an immunomodulator. Take ImmunoMax, the immunomodulator made of pure CM-glucan.	45.50	\N	2020-10-25 13:31:23.846187+00	44		t	183	\N	\N	f	\N	{}	{}	2020-09-22 09:11:55.01073+00
68	Immunomax 20mg CM-Glucan Syrup 60ml	Did you know that immunomodulation is pretty much the foundation of a healthy immunity?\r\n\r\n \r\n\r\nWhen it comes to your immune cells, balance is key. That means there are no weak cells and no overactive cells. If any of the two instances happen, you develop symptoms. Your immune system’s balancing act is called immunomodulation.\r\n\r\n \r\n\r\nThankfully, the scientists at Intermed worked hard to innovate a highly-soluble yeast extract called CM-glucan using a Swiss- patented technology. It’s an immunomodulator that updates, regulates and modulates cells in your immune system.\r\n\r\n \r\n\r\nSo if you’re concerned about your health, take an immunomodulator. Take ImmunoMax, the immunomodulator made of pure CM-glucan.	315.00	\N	2020-10-25 13:31:43.589217+00	44		t	183	\N	\N	f	\N	{}	{}	2020-09-22 09:10:34.555761+00
67	Pearly-C	Sodium Ascorbate + Zinc\r\n\r\nNon-acidic Vitamins	11.00	\N	2020-10-25 13:32:05.660491+00	44		t	183	\N	\N	f	\N	{}	{}	2020-09-22 09:02:43.883872+00
66	Immunomax 10mg CM-Glucan Capsule	Did you know that immunomodulation is pretty much the foundation of a healthy immunity?\r\n\r\n \r\n\r\nWhen it comes to your immune cells, balance is key. That means there are no weak cells and no overactive cells. If any of the two instances happen, you develop symptoms. Your immune system’s balancing act is called immunomodulation.\r\n\r\n \r\n\r\nThankfully, the scientists at Intermed worked hard to innovate a highly-soluble yeast extract called CM-glucan using a Swiss- patented technology. It’s an immunomodulator that updates, regulates and modulates cells in your immune system.\r\n\r\n \r\n\r\nSo if you’re concerned about your health, take an immunomodulator. Take ImmunoMax, the immunomodulator made of pure CM-glucan.	16.75	\N	2020-10-25 13:32:30.749952+00	44		t	183	\N	\N	f	\N	{}	{}	2020-09-22 09:01:10.300281+00
83	apcee 500mg tablet	ascorbic acid as food supplement.\r\ngood for boosting the immune system	3.00	\N	2020-10-25 14:18:00.027397+00	44		t	183	\N	\N	f	\N	{}	{}	2020-09-24 08:25:28.228999+00
261	Bigurlai Tea	Bigurlai Tea \r\nSenna Leaves (Cassia Angustifolia Vahl)\r\nLaxative 2 grams Tea Bag\r\n\r\n	\N	\N	2020-11-03 03:23:54.370268+00	44		f	165	\N	\N	f	\N	{}	{}	2020-11-03 03:23:54.370297+00
262	Biofit Tea	Biofit Tea \r\nSenna Leaves, Senna Pods\r\n1.275 g/ 0.425 g Laxative	\N	\N	2020-11-03 03:32:38.860484+00	44		f	165	\N	\N	f	\N	{}	{}	2020-11-03 03:32:38.860511+00
115	freestyle optium strip	glucose trip for freestyle optium glucometer\r\n50s\r\nbuy per box with discount	45.00	\N	2020-10-25 14:14:57.802733+00	44		t	150	\N	\N	f	\N	{}	{}	2020-09-30 06:11:08.854668+00
110	stabeta 10mg	generic name propranolol \r\nprescription meds\r\nvat exempt meds\r\nfor pick up \r\ngeneric 	1.50	\N	2020-10-25 14:15:32.512809+00	44		t	154	\N	\N	f	\N	{}	{}	2020-09-28 05:02:27.298665+00
118	hygenix 70% 500ml	ethyl alcohol	85.00	\N	2020-10-25 14:16:06.753081+00	44		t	166	\N	\N	f	\N	{}	{}	2020-09-30 06:41:02.507248+00
108	pulse oximeter	adult	1900.00	\N	2020-10-25 14:17:06.81522+00	44		t	170	\N	\N	f	\N	{}	{}	2020-09-28 04:28:48.560395+00
107	LAGUNDI WITH ZINC 600mg capsule	over the counter medication\r\nno prescription required \r\ncapsule herbal medicine for asthma and mild cough	7.00	\N	2020-10-25 14:17:32.196173+00	44		t	81	\N	\N	f	\N	{}	{}	2020-09-28 04:27:23.485943+00
199	Poten-Cee (ASCORBIC ACID) 500mg Chewable Tablet	Poten-Cee contains Ascorbic Acid 500mg. Orange flavored chewable tablet.	0.00	\N	2020-11-01 07:49:12.583634+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-26 06:08:25.208321+00
234	Johnson's Baby Soap 100gm	Johnson's baby soap with moisturizer.	0.00	\N	2020-11-01 07:53:09.416783+00	45		t	193	\N	\N	f	\N	{}	{}	2020-10-29 13:56:08.102737+00
229	Imodium (LOPERAMIDE) 2mg Capsule	Imodium contains Loperamide 2mg in capsule form. This medication is used to treat sudden diarrhea (including traveler's diarrhea). It works by slowing down the movement of the gut. This decreases the number of bowel movements and makes the stool less watery. Loperamide is also used to reduce the amount of discharge in patients who have undergone an ileostomy. It is also used to treat on-going diarrhea in people with inflammatory bowel disease.\r\n	0.00	\N	2020-11-01 07:56:25.004101+00	44		t	174	\N	\N	f	\N	{}	{}	2020-10-28 12:28:48.470916+00
245	Colgate Plax Peppermint Fresh 100ml	Colgate Plax Peppermint Fresh is alcohol free mouthwas for daily use in between brushing your teeth	0.00	\N	2020-11-01 14:26:56.793074+00	45		t	78	\N	\N	f	\N	{}	{}	2020-11-01 14:26:56.7931+00
268	Ceelin Plus Chewables	Ascorbic Acid + Sodium Ascorbate + Zinc\r\nVitamins & Minerals\r\n\r\nCeelin® Plus provides children double protection against sickness with the powerful combination of Vitamin C and Zinc. It is the only brand made with ZincPlus® Technology that ensures the stable combination of these 2 ingredients so that kids get the full dose they need.	\N	\N	2020-11-03 03:41:09.26233+00	44		f	183	\N	\N	f	\N	{}	{}	2020-11-03 03:41:09.262358+00
269	Cetaphil Moisturizing Cream	Moisturize your dry skin like never before! This rich cream intensely hydrates for a full 24-hours replenishing moisture for softer, smoother, healthier looking skin. Infused with a superior system of emollients and humectants to restore the skin's natural moisture barrier. 	\N	\N	2020-11-03 03:48:27.796817+00	45		f	159	\N	\N	f	\N	{}	{}	2020-11-03 03:48:27.796845+00
204	Carbocisteine Capsule (500mg)	Mucolytic	2.50	\N	2020-10-31 02:03:20.914795+00	44		t	81	\N	\N	f	\N	{}	{}	2020-10-27 05:15:01.161772+00
209	Cetirizine Tablet (10mg)	Cetirizine 10mg Tablet	5.00	\N	2020-10-31 02:06:34.502916+00	44		t	146	\N	\N	f	\N	{}	{}	2020-10-27 05:20:43.632402+00
214	Doktor Pinoy Capsule	99.9% Deep sea shark liver oil	13.40	\N	2020-10-31 02:13:27.679527+00	44		t	165	\N	\N	f	\N	{}	{}	2020-10-27 05:31:38.812967+00
219	Kremil-S	For hyperacidity/acid reflux	7.85	\N	2020-10-31 02:15:57.896862+00	44		t	174	\N	\N	f	\N	{}	{}	2020-10-27 05:39:50.899219+00
224	Xantone+ Capsule	Mnagosteen + Malunggay	13.00	\N	2020-10-31 02:17:27.290297+00	44		t	165	\N	\N	f	\N	{}	{}	2020-10-27 05:53:24.773654+00
250	Eye Mo (TETRAHDROZOLINE HCL) Red Eyes Formula	Eye Mo Red Eyes Formula is an ophthalmic vasoconstrictor that contains Tetrahydozoline HCl, a 0.05% solution (Eye Drops) recommended for red and irritated eyes. Eye Drops available in 7.5 ml sterile bottle.	0.00	\N	2020-11-02 08:13:02.845359+00	44		t	176	\N	\N	f	\N	{}	{}	2020-11-02 08:11:47.299399+00
274	Conzace	Multivitamins + Minerals\r\n\r\nConzace® has the highest levels of Zinc, Vitamins A, C, and E-proven to help immunity & the looks, like no other. This superior formulation combines all the molecules needed to give you healthy skin & hair. It also helps strengthen the immune system by 140% more vs. no supplementation.	\N	\N	2020-11-03 04:16:33.121539+00	44		f	183	\N	\N	f	\N	{}	{}	2020-11-03 04:16:33.121566+00
188	RITEMED B-Complex Tablet	<i>*indicated prices are vat-included</i>\r\n<br>\r\nImages shown here may not be accurate for generic medicines. Please send us a message at 09104049100 to determine the actual product on hand.\r\n<br>\r\n<br>\r\n\r\n<b>\r\nRITEMED B-Complex Tablet  <br>\r\nPotency: Vit B1 100 mg, vit B6 5 mg, vit B12 50 mcg  <br>\r\nForm: Round Tablet, Pink  <br>\r\n\r\nTherapeutic Use: Para sa mga ugat na nangangalay. Vitamin B Supplement<br>\r\nDirections: 1 tab once a day or as prescribed by the doctor <br>\r\nPharmacist's Reminders: <br>\r\n1. Itanong muna sa pharmacist kung tama ba ang gamot na bibilhin para sa sintomas na nararamdaman ninyo <br>\r\n2. Iwasan na ilagay ang gamot sa mainit na lugar.\r\n\r\n</b>\r\n\r\n\r\n\r\n\r\n\r\n	4.50	\N	2020-11-02 09:39:06.494754+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-25 15:29:59.591902+00
255	GENERIC Multivitamins/Minerals EURIVIT 120 mL Syrup	<i>*indicated prices are vat-included</i>\r\n<br>\r\nImages shown here may not be accurate for generic medicines. Please send us a message at 09104049100 to determine the actual product on hand.\r\n<br>\r\n<br>\r\n\r\n<b>\r\nGENERIC Multivitamins/Minerals EURIVIT <br>\r\nPotency: Vit A 4000 IU Vit D2 200 IU Vit B1/B2/B6/B12 2.5mg/1mg/1mg/3 mcg Vit C 50mg Calcium 10mg Nicotinamide 12.5mg <br>\r\nForm: Syrup, 120 mL <br>\r\n\r\nTherapeutic Use: Supplement<br>\r\nDirections: Usual Pediatric Dose: 5 mL once a day (see package insert for more information <br>\r\nPharmacist's Reminders: <br>\r\n1. Itanong muna sa pharmacist kung tama ba ang gamot na bibilhin para sa sintomas na nararamdaman ninyo <br>\r\n2. Iwasan na ilagay ang gamot sa mainit na lugar.\r\n\r\n</b>	75.00	\N	2020-11-03 02:59:15.534486+00	44		t	183	\N	\N	f	\N	{}	{}	2020-11-03 02:59:15.534513+00
277	Dove Coconut Milk Bar Soap	Dove Coconut Milk Bar Soap\r\n\r\nIngredients\r\nSodium Lauroyl Isethionate, Stearic Acid, Sodium Palmitate, Aqua, Lauric Acid, Sodium Isethionate, Sodium Stearate, Cocamidopropyl Betaine, Sodium Palm Kernelate, Parfum, Cocos Nucifera Fruit Extract, Glycerin, Sodium Chloride, Zinc Oxide, Propylene Glycol, Tetrasodium EDTA, Tetrasodium Etidronate, Alumina, Pentylene Glycol, Sine Adipe Lac, Decylene Glycol, 1,2-Hexanediol, Alpha-Isomethyl Ionone, Benzyl Alcohol, Benzyl Salicylate, Butylphenyl Methylpropional, Coumarin, Hexyl Cinnamal, Limonene, Linalool, CI 14700, CI 17200, CI 77891\r\nIngredients correct at time of publishing. Always check product packaging.	\N	\N	2020-11-03 04:20:57.53586+00	45		f	184	\N	\N	f	\N	{}	{}	2020-11-03 04:20:57.53589+00
288	J.Chemie Ethyl Alcohol Spray	J.Chemie Ethyl Alcohol Spray\r\n120 mL	\N	\N	2020-11-03 04:41:14.824455+00	46		f	191	\N	\N	f	\N	{}	{}	2020-11-03 04:41:14.824483+00
290	Johnson's Baby Oil 50mL	Johnson's Baby Oil 50mL	\N	\N	2020-11-03 04:44:45.094063+00	45		f	193	\N	\N	f	\N	{}	{}	2020-11-03 04:44:45.09409+00
297	Mediplast Band Aid	Mediplast Band Aid 100 Strips\r\n	\N	\N	2020-11-03 05:33:05.886696+00	45		f	182	\N	\N	f	\N	{}	{}	2020-11-03 05:33:05.886723+00
303	Dextromethorphan Hydrobromide 10 mg / 5 mL	Dextromethorphan Hydrobromide 10 mg / 5 mL\r\nAntitussive	\N	\N	2020-11-03 06:59:10.930559+00	44		f	81	\N	\N	f	\N	{}	{}	2020-11-03 06:59:10.930587+00
235	Colgate	Ipsum sit amet dolor qui consectetur	100.00	\N	2020-11-22 19:39:21.015088+00	45	"23"=>"38"	f	78	\N	\N	f	\N	{}	{}	2020-10-29 23:08:59.360224+00
256	Paracetamol 500mg	Paracetamol 500mg Tablet \r\nAntipyretic/Analgesic	\N	\N	2020-11-03 03:02:12.59467+00	44		f	179	\N	\N	f	\N	{}	{}	2020-11-03 03:02:12.594698+00
260	Mefenamic Acid 250mg	Mefenamic Acid 250mg Capsule\r\nNon-Steroidal Anti-Inflammatory Drug (NSAID)\r\n	\N	\N	2020-11-03 03:07:13.188518+00	44		f	179	\N	\N	f	\N	{}	{}	2020-11-03 03:07:13.188544+00
200	Johnson's Baby Oil 50ml	Johnson's Lite baby oil light and fast absorbing, Locks in more moisture conpared to ordinary lotion. pH Balanced, tested with pediatricians. Wirh fast absorbing formula. Made with pure mineral oil.\r\n	0.00	\N	2020-11-01 07:57:38.69967+00	45		t	193	\N	\N	f	\N	{}	{}	2020-10-26 07:57:34.356351+00
263	Biogesic 100mg/mL	Biogesic (Paracetamol) \r\n100mg/mL (Oral Drops)\r\n0-2 years old\r\nAnalgesic / Antipyretic 	\N	\N	2020-11-03 03:34:06.668149+00	44		f	179	\N	\N	f	\N	{}	{}	2020-11-03 03:34:06.668176+00
246	Centrum Capsule	Multivitamins and Minerals	12.00	\N	2020-11-02 07:12:06.442572+00	44		t	183	\N	\N	f	\N	{}	{}	2020-11-02 07:12:06.442599+00
265	Biogesic 250mg/5mL	Biogesic (Paracetamol)\r\n250mg/5mL (Suspension)\r\nAnalgesic/Antipyretic\r\n	\N	\N	2020-11-03 03:36:19.795327+00	44		f	179	\N	\N	f	\N	{}	{}	2020-11-03 03:36:19.795354+00
270	Colgate Spicy Fresh	Colgate Spicy Fresh 2 Tubes\r\n175g x 2pcs\r\n\r\nMake Xtra Fresh Connections with Colgate Fresh Confidence!\r\n\r\nRefreshing gel toothpaste powered with a breakthrough cooling technology for intense cooling and a super fresh experience!\r\nContains unique cooling crystals that dissolve while brushing for that extra fresh feeling\r\nFeels super fresh to give you that Xtra Confidence when interacting with others	\N	\N	2020-11-03 03:58:05.964135+00	45		f	78	\N	\N	f	\N	{}	{}	2020-11-03 03:58:05.964164+00
189	RITEMED Carbocistine Capsule (500mg)	<i>*indicated prices are vat-included</i>\r\n<br>\r\nImages shown here may not be accurate for Generic medicines. Please send us a message at 09104049100 to determine the actual product on hand.\r\n<br>\r\n<br>\r\n\r\n<b>\r\nRITEMED Carbocisteine Capsule <br>\r\nPotency: 500mg <br>\r\nForm: Solid Capsule, Orange <br>\r\n\r\nTherapeutic Use: Para sa ubong may plema. Pampalabnaw ng malapot na plema. <br>\r\nDirections: Orally, 1 capsule three times a day for 5 days<br>\r\nPharmacist's Reminders: <br>\r\n1. Itanong muna sa pharmacist kung tama ba ang gamot na bibilhin para sa sintomas na nararamdaman ninyo <br>\r\n2. Ito ay isang over the counter medicine. Kung hindi kayo gumaling after 5-7 days, mainam na magpakonsulta agad sa doktor. <br>\r\n3. Iwasan na ilagay ang gamot sa mainit na lugar.\r\n\r\n</b>	5.00	\N	2020-11-02 07:57:33.752585+00	44		t	81	\N	\N	f	\N	{}	{}	2020-10-25 15:31:52.677662+00
275	Carbocisteine 250mg / 5mL	Carbocisteine 250mg / 5mL \r\nSuspension\r\nMucolytic	\N	\N	2020-11-03 04:17:41.521314+00	44		f	81	\N	\N	f	\N	{}	{}	2020-11-03 04:17:41.521342+00
225	Xanthone Plus Gold	Malunggay, Garlic, Spirulina	15.00	\N	2020-10-31 01:52:41.20363+00	44		t	165	\N	\N	f	\N	{}	{}	2020-10-27 05:54:36.238602+00
205	Cecon (500mg)	Chewable Ascorbic Acid 500mg for Adult	10.00	\N	2020-10-31 02:03:36.022891+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 05:16:38.811975+00
210	Clusivol+ Tablet	Multivitamins (with vitamin-C) film-coated tablet	7.00	\N	2020-10-31 02:07:25.635403+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 05:23:24.720708+00
215	DTX-500	Malunggay, Sugarcane	14.00	\N	2020-10-31 02:14:05.973384+00	44		t	165	\N	\N	f	\N	{}	{}	2020-10-27 05:33:18.296034+00
220	MIghty Cee (500mg)	Ascorbic acid 500mg	10.00	\N	2020-10-31 02:16:17.556031+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 05:46:57.5715+00
191	RITEMED Paracetamol (500mg) Tablet	<i>*indicated prices are vat-included</i>\r\n<br>\r\nImages shown here may not be accurate for generic medicines. Please send us a message at 09104049100 to determine the actual product on hand.\r\n<br>\r\n<br>\r\n\r\n<b>\r\nRITEMED Paracetamol Tablet <br>\r\nPotency: 500mg <br>\r\nForm: Round Tablet, White <br>\r\n\r\nTherapeutic Use: Pang-pababa ng lagnat. Mahinang uri na lunas para sa sakit sa ulo at ngipin (mild pain reliever) <br>\r\nDirections: 1 tab three or 4 times a day for 5 days<br>\r\nPharmacist's Reminders: <br>\r\n1. Itanong muna sa pharmacist kung tama ba ang gamot na bibilhin para sa sintomas na nararamdaman ninyo <br>\r\n2. Ito ay isang over the counter medicine. Kung hindi kayo gumaling after 5-7 days, mainam na magpakonsulta agad sa doktor. <br>\r\n3. Iwasan na ilagay ang gamot sa mainit na lugar.\r\n\r\n</b>	2.00	\N	2020-11-02 09:40:39.739516+00	44		t	179	\N	\N	f	\N	{}	{}	2020-10-25 15:35:27.005722+00
280	Dove Pink Bar Soap	Dove Pink Bar Soap\r\n\r\nClassic moisturizing formula with a delicate pink hue\r\n\r\nIngredients\r\nSodium Lauroyl Isethionate, Stearic Acid, Sodium Palmitate, Aqua, Lauric Acid, Sodium Isethionate, Sodium Stearate, Cocamidopropyl Betaine, Sodium Palm Kernelate, Glycerin, Parfum, Sodium Chloride, Propylene Glycol, Zinc Oxide, Tetrasodium EDTA, Tetrasodium Etidronate, Alumina, Alpha-Isomethyl Ionone, Benzyl Alcohol, Butylphenyl Methylpropional, Citronellol, Coumarin, Hexyl Cinnamal, Limonene, Linalool, CI 14700, CI 17200, CI 77891	\N	\N	2020-11-03 04:22:19.354659+00	45		f	184	\N	\N	f	\N	{}	{}	2020-11-03 04:22:19.354688+00
285	Gyne Pro 60mL	GynePro® contains Chlorhexidine digluconate, a safe and effective, clinically-tested anti-infective which protects against bacteria that can cause common genital infections.\r\n\r\n-Best used during red days. Use twice a day (morning & evening).\r\n-Use 3 times a week for protection during regular days.\r\n-Use as cleansing wash before sexual intercourse.	\N	\N	2020-11-03 04:34:39.682443+00	45		f	94	\N	\N	f	\N	{}	{}	2020-11-03 04:33:05.10444+00
291	Johnson's Baby Powder	Johnson's baby powder gently absorbs moisture to soothe delicate skin, and leave it feeling soft and smooth. Specially formulated for babies, this baby powder is dermatologist-tested and clinically proven mild and gentle. This hypoallergenic baby powder is free of parabens, phthalates, dyes, and harsh fragrances.	\N	\N	2020-11-03 04:45:54.58659+00	45		f	193	\N	\N	f	\N	{}	{}	2020-11-03 04:45:54.586618+00
298	Mena	Natural White Pearl Cream	\N	\N	2020-11-03 06:53:04.602886+00	45		f	185	\N	\N	f	\N	{}	{}	2020-11-03 06:53:04.602913+00
304	MX3 Coffee	MX3 Coffee Mix is a flavorful concoction of Premium Coffee packed with 3 anti-oxidants: Alpha, Beta, and Gamma from G. Mangostana.\r\n\r\n✓ Low Acid Coffee\r\n✓ High Source of Vitamin C\r\n✓ High Source of Calcium\r\n\r\nDirection for Use: One sachet in a cup of hot water.\r\n\r\nBox of 10 sachets.	\N	\N	2020-11-03 07:04:38.949758+00	44		f	165	\N	\N	f	\N	{}	{}	2020-11-03 07:04:38.949787+00
307	Paracetamol 125mg/5mL Suspension	Paracetamol 125mg/5mL Suspension\r\nAntipyretic / Analgesic	\N	\N	2020-11-03 07:08:00.855272+00	44		f	179	\N	\N	f	\N	{}	{}	2020-11-03 07:08:00.855301+00
310	Bigurlai Tea	Bigurlai Tea \r\nSenna Leaves (Cassia Angustifolia Vahl)\r\nLaxative 2 grams Tea Bag\r\n\r\n	8.00	\N	2020-11-03 08:00:50.85473+00	44		t	165	\N	\N	f	\N	{}	{}	2020-11-03 08:00:50.854754+00
315	Calmoseptine Cream	Zinc Oxide + Calamine\r\n555.7 mg / 164.5mg / 3.5 g Ointment\r\nAnti-inflammatory / Anti-pruritic\r\n	45.00	\N	2020-11-03 08:03:58.269314+00	44		t	159	\N	\N	f	\N	{}	{}	2020-11-03 08:03:58.269338+00
292	Johnson's Baby Soap	Gently cleanses without drying baby's delicate skin. Enriched with moisturizers for skin that feels baby soft. Product Demos. Product Recommendations. Exclusive Membership. Improved Formulation. Customer Service. Product Matching. Ingredient Breakdown.	\N	\N	2020-11-03 04:46:52.558527+00	45		f	193	\N	\N	f	\N	{}	{}	2020-11-03 04:46:52.558554+00
201	sample 1	sample des	123.00	\N	2020-10-27 00:51:17.781805+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 00:51:17.781833+00
73	Amazing Garcinia Cambogia	WHY DRINK GARCINIA CAMBOGIA?\r\n\r\n• Nakakabawas ng appetite kaya busog ka agad. Hindi ka made-deprive sa masasarap na pagkain kasi NO NEED FOR EXTREME DIET.\r\n\r\n• Kino convert ang calories into energy kaya hindi ito na i-store as fat, kaya NO NEED FOR INTENSE EXERCISE.\r\n\r\n• No LBM effect. Pwede mong gamitin kahit may lakad or may work ka.\r\n\r\n• No unnecessary side effects.\r\n\r\n• No rebound. Pwede nyo syang gamitin up to 6 weeks nang tuluy-tuloy. Pero you can stop anytime once maabot mo na yung desired size mo. Suffering from obesity, Cholesterol problem, an increase in your blood sugar level, and depression due to weight challenges? Tired of rigorous exercises, torturous diet, and the unpleasant taste and high cost of dietary supplements? Or simply just wanted to loose excess fat and reach that desired weight?	900.00	\N	2020-10-25 13:30:06.929089+00	44		t	165	\N	\N	f	\N	{}	{}	2020-09-23 09:09:48.661807+00
247	STRESSTABS	MULTIVITAMINS & MINERALS	13.00	\N	2020-11-02 07:16:25.511628+00	44		t	183	\N	\N	f	\N	{}	{}	2020-11-02 07:16:25.511653+00
294	Lysol Hand & Body Wipes	Lysol Hand & Body Wipes \r\n10 pulls\r\n\r\nLysol is the No.1 disinfectant brand in the US with over 50% of households using Lysol products. Families have trusted the brand to help keep their homes healthy for over 100 years. Hospitals across the US also trust the brand to satisfy their cleaning and disinfecting needs. Lysol has been helping create healthy households with effective household cleaning products for over a century. Our range spans everything from disinfectants to fabric cleaners. Lysol a leading and respected germ-protection brand advocates a healthy touch to every home. Through their range of cleaning tools Lysol is able to address what every home needs – a healthy and safe environment for the family.\r\n \r\nLadies and gents will appreciate the new Lysol Germ Protection Hand Wipes. \r\nProtecting yourself from germs is now handy as it kills 99.9% (proven and tested) of sickness causing germs and bacteria yet gentle on our skin. \r\nDermatologists tested the product and affirms it can moisturize our face or cleanse our sensitive body parts as it alcohol-free.\r\nCleans and Sanitizes.\r\nLysol Helps you stay protected anywhere, anytime.\r\nIts soft, textured fabric gently cleanses your skin without irritation.\r\nLeaves your skin feeling with a light fragrance after use.	\N	\N	2020-11-03 05:29:42.76764+00	45		f	191	\N	\N	f	\N	{}	{}	2020-11-03 05:29:42.767669+00
211	Decolgen	For fever with runny nose and headache	6.20	\N	2020-10-27 06:09:36.718194+00	44		t	81	\N	\N	f	\N	{}	{}	2020-10-27 05:26:49.30534+00
190	RITEMED Bisacodyl (5mg) Tablet	<i>*indicated prices are vat-included</i>\r\n<br>\r\nImages shown here may not be accurate for generic medicines. Please send us a message at 09104049100 to determine the actual product on hand.\r\n<br>\r\n<br>\r\n\r\n<b>\r\nRITEMED Bisacodyl Tablet <br>\r\nPotency: 5mg <br>\r\nForm: Tablet <br>\r\n\r\nTherapeutic Use: Laksatiba/laxative. Para mabilis maglabas ng dumi.<br>\r\nDirections: Orally, 1 tablet before bed time<br>\r\nPharmacist's Reminders: <br>\r\n1. Itanong muna sa pharmacist kung tama ba ang gamot na bibilhin para sa sintomas na nararamdaman ninyo <br>\r\n2. Ito ay isang over the counter medicine. Kung hindi kayo gumaling after 5 days, mainam na magpakonsulta agad sa doktor. <br>\r\n3. Iwasan na ilagay ang gamot sa mainit na lugar. <br>\r\n4. Huwag gamitin palagi dahil baka magkaroon ng drug dependence <br>\r\n\r\n</b>	15.00	\N	2020-11-02 09:35:13.43836+00	44		t	174	\N	\N	f	\N	{}	{}	2020-10-25 15:34:17.115993+00
226	SAMPLE 2	SAMPLE 2 DES	123.00	\N	2020-10-27 06:40:55.944387+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 06:40:55.944416+00
236	Palmolive Shampoo	Lorem ipsum sit amet consectetur qui elementum	200.00	\N	2020-11-02 21:27:50.506486+00	45	"25"=>"40"	t	93	\N	\N	f	\N	{}	{}	2020-10-29 23:12:26.655061+00
257	Mefenamic Acid 50mg/5mL Suspension	Mefenamic Acid 50mg/5mL Suspension\r\nNon-steroidal Anti-inflammatory Drugs (NSAIDs)	\N	\N	2020-11-03 03:03:42.228592+00	44		f	179	\N	\N	f	\N	{}	{}	2020-11-03 03:03:42.228619+00
264	Biogesic 120mg/5mL	Biogesic (Paracetamol) \r\n120mg/5mL (Suspension)\r\n2-6 years old\r\nAnalgesic / Antipyretic 	\N	\N	2020-11-03 03:35:07.397501+00	44		f	179	\N	\N	f	\N	{}	{}	2020-11-03 03:35:07.397529+00
276	Diatabs	Loperamide 2mg\r\nAntimotility\r\n\r\nFor relief of diarrhea and its symptoms	\N	\N	2020-11-03 04:18:55.707559+00	44		f	174	\N	\N	f	\N	{}	{}	2020-11-03 04:18:55.707588+00
281	Drivemax Capsule	- Drivemax Adult Herbal Capsule is an ADULT DIETARY supplement for MEN and WOMEN\r\n\r\n- Its main ingredients are TONGKAT ALI that is good for blood circulation and increases testosterone level that could help fertility and sterility	\N	\N	2020-11-03 04:23:26.085019+00	44		f	165	\N	\N	f	\N	{}	{}	2020-11-03 04:23:26.085047+00
299	Mena	Mena Pink Cream	\N	\N	2020-11-03 06:53:31.500733+00	45		f	185	\N	\N	f	\N	{}	{}	2020-11-03 06:53:31.500761+00
206	Cecon Jr.	Chewable ascorbic acid for your kids	10.00	\N	2020-10-31 02:04:15.959451+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 05:17:23.659894+00
221	Pharex B-Complex	Vtamin B Complex	5.00	\N	2020-10-31 02:16:37.770742+00	44		t	183	\N	\N	f	\N	{}	{}	2020-10-27 05:47:51.206289+00
282	Eskinol Papaya Smooth White	- Removes deep seated dirt, excess oil and make up with Micro-Cleanse Anti-bacterial Formula\r\n- With pure Papaya Extract and Vitamin B3 to whiten skin in as early as 1 week , based on clinical test\r\n- Helps renew dull skin, leaving it smoother\r\n\r\nIngredients\r\nWater, Alcohol Denat., Sorbitol, Carica papaya Fruit Extract, Propylene Glycol, PEG-40 Hydrogenated Castol Oil, Niacinamide, Perfume, Tocopheryl Acetate, Menthol, Citric Acid, Benzophenone-3, Phenoxyethanol, CI 15985, CI 17200, CI 19140\r\n\r\n	\N	\N	2020-11-03 04:25:09.562021+00	45		f	185	\N	\N	f	\N	{}	{}	2020-11-03 04:24:57.60437+00
283	Acetylcysteine 600mg	Acetylcysteine 600mg Powder for Oral Solution\r\nMucolytic	\N	\N	2020-11-03 04:27:44.250917+00	44		f	81	\N	\N	f	\N	{}	{}	2020-11-03 04:27:44.250945+00
286	GynePro mL	GynePro® contains Chlorhexidine digluconate, a safe and effective, clinically-tested anti-infective which protects against bacteria that can cause common genital infections.\r\n\r\n-Best used during red days. Use twice a day (morning & evening).\r\n-Use 3 times a week for protection during regular days.\r\n-Use as cleansing wash before sexual intercourse.	\N	\N	2020-11-03 04:36:11.696716+00	45		f	94	\N	\N	f	\N	{}	{}	2020-11-03 04:36:11.696745+00
305	Myra E	d-Alpha Tocopherol (Vitamin E)\r\n400 I.U. Softgel Capsule	\N	\N	2020-11-03 07:06:58.488536+00	44		f	183	\N	\N	f	\N	{}	{}	2020-11-03 07:05:34.960944+00
308	Acetylcysteine 600mg	Acetylcysteine 600mg Powder for Oral Solution\r\nMucolytic	30.00	\N	2020-11-03 07:59:46.40204+00	44		t	81	\N	\N	f	\N	{}	{}	2020-11-03 07:59:46.402065+00
311	Biofit Tea	Biofit Tea \r\nSenna Leaves, Senna Pods\r\n1.275 g/ 0.425 g Laxative	6.50	\N	2020-11-03 08:01:21.395833+00	44		t	165	\N	\N	f	\N	{}	{}	2020-11-03 08:01:21.395855+00
313	Biogesic 120mg/5mL	Biogesic (Paracetamol) \r\n120mg/5mL (Suspension)\r\n2-6 years old\r\nAnalgesic / Antipyretic 	84.00	\N	2020-11-04 03:58:37.08226+00	44		t	179	\N	\N	f	\N	{}	{}	2020-11-03 08:02:19.656174+00
366	Stresstabs	Multivitamins + Iron \r\n	\N	\N	2020-11-11 03:08:59.856194+00	44		f	183	\N	\N	f	\N	{}	{}	2020-11-11 03:08:59.856225+00
15	Alaxan FR	Alaxan FR	120.00	\N	2020-11-10 11:41:42.877633+00	44		t	179	\N	\N	f	\N	{}	{}	2020-09-09 16:15:20.158472+00
369	Digital Thermometer	Digital Thermometer	\N	\N	2020-11-11 03:24:13.483882+00	44		f	170	\N	\N	f	\N	{}	{}	2020-11-11 03:24:13.48391+00
301	Ming's Pei Pa Koa 150mL Syrup	Natural Herb, Loquat with Honey Extracts for sore throat and disruptive coughs. Relief never tasted this good.\r\n\r\nMing’s Pei Koa Syrup is made from a number of herbal ingredients including a kind of loquat syrup used in traditional oriental medicine. It has proven to soothe dry, itchy throat and clear nasal passages that is trusted thousand years ago. It is safe and free from any side effects.\r\n\r\nMing’s Pa Koa an Syrup exceptional syrup that HELPS TO CALM minor cough associated with common colds, it calms itchy, strained and stressed throat from over used chords (e.g. singers, teachers), smoking, sore throat, loss or hoarseness of voice and the like.\r\n\r\nMAIN BENEFITS: A soothing solution for cough, sore throat, strain and hoarseness of voice. Eases throat discomfort and manage disruptive cough quickly. It is a natural health remedies. With its main benefits, Ming’s Pe Pa Koa Syrup a potent herbal formulation that HELPS relieves cough and sore throat as well as restores vocal quality. It has been an ever-ready and ever-reliable relief of allergies, colds or a stressed out of throat whenever we take the toll of our voice.	\N	\N	2020-11-03 06:57:28.552744+00	44		f	165	\N	\N	f	\N	{}	{}	2020-11-03 06:57:19.578107+00
302	Ming's Pei Pa Koa 70mL Syrup	Natural Herb, Loquat with Honey Extracts for sore throat and disruptive coughs. Relief never tasted this good.\r\n\r\nMing’s Pei Koa Syrup is made from a number of herbal ingredients including a kind of loquat syrup used in traditional oriental medicine. It has proven to soothe dry, itchy throat and clear nasal passages that is trusted thousand years ago. It is safe and free from any side effects.\r\n\r\nMing’s Pa Koa an Syrup exceptional syrup that HELPS TO CALM minor cough associated with common colds, it calms itchy, strained and stressed throat from over used chords (e.g. singers, teachers), smoking, sore throat, loss or hoarseness of voice and the like.\r\n\r\nMAIN BENEFITS: A soothing solution for cough, sore throat, strain and hoarseness of voice. Eases throat discomfort and manage disruptive cough quickly. It is a natural health remedies. With its main benefits, Ming’s Pe Pa Koa Syrup a potent herbal formulation that HELPS relieves cough and sore throat as well as restores vocal quality. It has been an ever-ready and ever-reliable relief of allergies, colds or a stressed out of throat whenever we take the toll of our voice.	\N	\N	2020-11-03 06:58:04.584641+00	44		f	165	\N	\N	f	\N	{}	{}	2020-11-03 06:58:04.584669+00
319	Colgate Plax Peppermint Fresh	Colgate Plax Peppermint Fresh\r\n\r\nThere are times when it seems no matter how many times you brush or how many mints you pop, your mouth just doesn’t feel fresh. In these cases, a 30-second rinse with powerful mouthwash after brushing can make all the difference – for up to 12 hours.\r\n\r\n \r\n\r\nThat’s where Colgate® Plax® comes in. Available in a range of refreshing flavors, this clinically tested formula also provides protection against bacteria, plaque and cavities.	0.00	\N	2020-11-03 08:09:03.951978+00	45		t	78	\N	\N	f	\N	{}	{}	2020-11-03 08:09:03.952005+00
320	Colgate Spicy Fresh	Colgate Spicy Fresh 2 Tubes\r\n175g x 2pcs\r\n\r\nMake Xtra Fresh Connections with Colgate Fresh Confidence!\r\n\r\nRefreshing gel toothpaste powered with a breakthrough cooling technology for intense cooling and a super fresh experience!\r\nContains unique cooling crystals that dissolve while brushing for that extra fresh feeling\r\nFeels super fresh to give you that Xtra Confidence when interacting with others	0.00	\N	2020-11-03 08:09:25.363504+00	45		t	78	\N	\N	f	\N	{}	{}	2020-11-03 08:09:25.363527+00
322	Dextromethorphan Hydrobromide 10 mg / 5 mL	Dextromethorphan Hydrobromide 10 mg / 5 mL\r\nAntitussive	40.00	\N	2020-11-04 03:55:21.17401+00	44		t	81	\N	\N	f	\N	{}	{}	2020-11-03 08:10:20.182763+00
327	Eskinol Papaya Smooth White 75ml	- Removes deep seated dirt, excess oil and make up with Micro-Cleanse Anti-bacterial Formula\r\n- With pure Papaya Extract and Vitamin B3 to whiten skin in as early as 1 week , based on clinical test\r\n- Helps renew dull skin, leaving it smoother\r\n\r\nIngredients\r\nWater, Alcohol Denat., Sorbitol, Carica papaya Fruit Extract, Propylene Glycol, PEG-40 Hydrogenated Castol Oil, Niacinamide, Perfume, Tocopheryl Acetate, Menthol, Citric Acid, Benzophenone-3, Phenoxyethanol, CI 15985, CI 17200, CI 19140\r\n\r\n	47.00	\N	2020-11-04 03:53:05.906298+00	45		t	185	\N	\N	f	\N	{}	{}	2020-11-03 08:12:27.495959+00
326	Drivemax Capsule	- Drivemax Adult Herbal Capsule is an ADULT DIETARY supplement for MEN and WOMEN\r\n\r\n- Its main ingredients are TONGKAT ALI that is good for blood circulation and increases testosterone level that could help fertility and sterility	105.00	\N	2020-11-04 03:53:22.93285+00	44		t	165	\N	\N	f	\N	{}	{}	2020-11-03 08:12:05.463487+00
325	Dove Pink Bar Soap	Dove Pink Bar Soap\r\n\r\nClassic moisturizing formula with a delicate pink hue\r\n\r\nIngredients\r\nSodium Lauroyl Isethionate, Stearic Acid, Sodium Palmitate, Aqua, Lauric Acid, Sodium Isethionate, Sodium Stearate, Cocamidopropyl Betaine, Sodium Palm Kernelate, Glycerin, Parfum, Sodium Chloride, Propylene Glycol, Zinc Oxide, Tetrasodium EDTA, Tetrasodium Etidronate, Alumina, Alpha-Isomethyl Ionone, Benzyl Alcohol, Butylphenyl Methylpropional, Citronellol, Coumarin, Hexyl Cinnamal, Limonene, Linalool, CI 14700, CI 17200, CI 77891	52.00	\N	2020-11-04 03:53:56.144788+00	45		t	184	\N	\N	f	\N	{}	{}	2020-11-03 08:11:32.423456+00
324	Dove Coconut Milk Bar Soap	Dove Coconut Milk Bar Soap\r\n\r\nIngredients\r\nSodium Lauroyl Isethionate, Stearic Acid, Sodium Palmitate, Aqua, Lauric Acid, Sodium Isethionate, Sodium Stearate, Cocamidopropyl Betaine, Sodium Palm Kernelate, Parfum, Cocos Nucifera Fruit Extract, Glycerin, Sodium Chloride, Zinc Oxide, Propylene Glycol, Tetrasodium EDTA, Tetrasodium Etidronate, Alumina, Pentylene Glycol, Sine Adipe Lac, Decylene Glycol, 1,2-Hexanediol, Alpha-Isomethyl Ionone, Benzyl Alcohol, Benzyl Salicylate, Butylphenyl Methylpropional, Coumarin, Hexyl Cinnamal, Limonene, Linalool, CI 14700, CI 17200, CI 77891\r\nIngredients correct at time of publishing. Always check product packaging.	52.00	\N	2020-11-04 03:54:14.053554+00	45		t	184	\N	\N	f	\N	{}	{}	2020-11-03 08:11:13.718623+00
321	Conzace	Multivitamins + Minerals\r\n\r\nConzace® has the highest levels of Zinc, Vitamins A, C, and E-proven to help immunity & the looks, like no other. This superior formulation combines all the molecules needed to give you healthy skin & hair. It also helps strengthen the immune system by 140% more vs. no supplementation.	13.00	\N	2020-11-04 03:55:43.410518+00	44		t	183	\N	\N	f	\N	{}	{}	2020-11-03 08:09:45.092805+00
271	Mediplast standard Plastic Strips	Mediplast contains Acrinol. Available in box of 100 strips.	0.00	\N	2020-11-03 14:12:07.989941+00	44	"34"=>"65"	t	164	\N	\N	f	\N	{}	{}	2020-11-03 04:10:53.322627+00
345	Turmeric Tea	AKITA Turmeric Tea (Curcumma longa Linn.) 1.5 G\r\n\r\nNO APPROVED THERAPEUTIC CLAIMS	7.00	\N	2020-11-08 20:42:32.982927+00	44		t	165	\N	\N	f	\N	{}	{}	2020-11-08 20:42:32.982951+00
346	Lady Pills	Ethinyl Estradiol + Levonorgestrel\r\n30 mcg / 150 mcg Tablet \r\nHormonal Contraceptive	45.00	\N	2020-11-08 20:44:07.669724+00	44		t	163	\N	\N	f	\N	{}	{}	2020-11-08 20:44:07.66975+00
249	Colgate Fresh Confidence	Colgate activity toothpaste with cooling crystals for intense cooling and super freshness. 175gm tube available in pack of 2's for only php139.00	139.00	\N	2020-11-03 14:41:16.547626+00	45		t	78	\N	\N	f	\N	{}	{}	2020-11-02 07:58:28.781542+00
323	Diatabs	Loperamide 2mg\r\nAntimotility\r\n\r\nFor relief of diarrhea and its symptoms	7.75	\N	2020-11-04 03:54:48.537971+00	44		t	174	\N	\N	f	\N	{}	{}	2020-11-03 08:10:49.491507+00
317	Ceelin Plus Chewables	Ascorbic Acid + Sodium Ascorbate + Zinc\r\nVitamins & Minerals\r\n\r\nCeelin® Plus provides children double protection against sickness with the powerful combination of Vitamin C and Zinc. It is the only brand made with ZincPlus® Technology that ensures the stable combination of these 2 ingredients so that kids get the full dose they need.	6.50	\N	2020-11-04 03:56:42.797099+00	44		t	183	\N	\N	f	\N	{}	{}	2020-11-03 08:08:18.291332+00
314	Biogesic 250mg/5mL	Biogesic (Paracetamol)\r\n250mg/5mL (Suspension)\r\nAnalgesic/Antipyretic\r\n	132.00	\N	2020-11-04 03:57:40.094134+00	44		t	179	\N	\N	f	\N	{}	{}	2020-11-03 08:02:52.377407+00
330	RiteMed (ASCORBIC ACID) 100mg/5ml Syrup 120ml	RiteMed Ascorbic Acid syrup is Vitamin C for children.	0.00	\N	2020-11-04 09:22:58.025225+00	44		t	183	\N	\N	f	\N	{}	{}	2020-11-04 09:22:58.025252+00
332	Advil (IBUPROPEN) 200mg Softgel Capsule	Advil contains Ibupropen 200mg softgel capsule is an analgesic and antipyretic NSAID (non-steroidal anti-inflamatory drug).	0.00	\N	2020-11-05 14:02:00.41176+00	44		t	179	\N	\N	f	\N	{}	{}	2020-11-05 14:00:11.833278+00
333	Likas Papaya Soap	Likas Papaya soap is an herbal bath soap for face and body.	0.00	\N	2020-11-05 14:06:44.629839+00	45		t	184	\N	\N	f	\N	{}	{}	2020-11-05 14:06:44.629867+00
336	Robitusin (GUAIFENESIN) 200mg Softgel Capsule	Robotusin contains Guaifenesin 200mg softgel capsule. Robitusin is an Expectorant that helps clear chest congestion. Helps lossen sticky mucus.	0.00	\N	2020-11-06 03:02:38.209073+00	44		t	81	\N	\N	f	\N	{}	{}	2020-11-06 03:01:51.512067+00
337	Alvedon (PARACETAMOL) 500mg Tablet	Alvedon contains Paracetamol 500mg Tablet. Alvedon is an analgesic and anti-pyretic medicine.	0.00	\N	2020-11-06 03:07:18.842622+00	44		t	179	\N	\N	f	\N	{}	{}	2020-11-06 03:06:10.405282+00
338	Myra e (ALPHA TOCOPHEROL) Vitsmin E 400iu Capsule	Myra e contains Alpha Tocopherol 400iu Vitamin E capsule.	0.00	\N	2020-11-06 03:10:52.041994+00	44		t	183	\N	\N	f	\N	{}	{}	2020-11-06 03:10:52.042028+00
339	Alaxan FR (IBUPROFEN + PARACETAMOL) Capsule	Alaxan FR contains Ibuprofen 200mg and Patacetamol 325mg. A combination of a non-steroidal anti-inflammatory drug and an analgesic & antipyretic preparation.	0.00	\N	2020-11-06 03:16:12.477469+00	44		t	179	\N	\N	f	\N	{}	{}	2020-11-06 03:16:12.477497+00
341	Dove Coconut Milk Bar Soap	Dove Coconut Milk Bar Soap\r\n\r\nIngredients\r\nSodium Lauroyl Isethionate, Stearic Acid, Sodium Palmitate, Aqua, Lauric Acid, Sodium Isethionate, Sodium Stearate, Cocamidopropyl Betaine, Sodium Palm Kernelate, Parfum, Cocos Nucifera Fruit Extract, Glycerin, Sodium Chloride, Zinc Oxide, Propylene Glycol, Tetrasodium EDTA, Tetrasodium Etidronate, Alumina, Pentylene Glycol, Sine Adipe Lac, Decylene Glycol, 1,2-Hexanediol, Alpha-Isomethyl Ionone, Benzyl Alcohol, Benzyl Salicylate, Butylphenyl Methylpropional, Coumarin, Hexyl Cinnamal, Limonene, Linalool, CI 14700, CI 17200, CI 77891\r\nIngredients correct at time of publishing. Always check product packaging.	0.00	\N	2020-11-07 14:10:52.875418+00	45		f	184	\N	\N	f	\N	{}	{}	2020-11-07 12:58:58.925742+00
349	Calmoseptine Cream	Zinc Oxide + Calamine\r\n555.7 mg / 164.5mg / 3.5 g Ointment\r\nAnti-inflammatory / Anti-pruritic\r\n	45.00	\N	2020-11-08 21:00:17.910437+00	44		f	159	\N	\N	f	\N	{}	{}	2020-11-08 21:00:17.910459+00
352	Diatabs	Loperamide 2mg\r\nAntimotility\r\n\r\nFor relief of diarrhea and its symptoms	7.25	\N	2020-11-08 21:14:14.88781+00	44		t	174	\N	\N	f	\N	{}	{}	2020-11-08 21:14:14.88783+00
344	Lady Pills	Ethinyl Estradiol + Levonorgestrel\r\n30 mcg / 150 mcg Tablet \r\nHormonal Contraceptive	150.00	\N	2020-11-10 08:19:44.425759+00	44		t	163	\N	\N	f	\N	{}	{}	2020-11-08 02:41:28.685941+00
355	Nexcare Baby Cooling Fever Patch	3M Nexcare Baby Cooling Fever Patch\r\n2 Patches\r\n	\N	\N	2020-11-11 02:47:24.385741+00	45		f	193	\N	\N	f	\N	{}	{}	2020-11-11 02:47:24.385767+00
357	Paracetamol 250mg / 5mL	Paracetamol 250mg / 5mL\r\nSuspension\r\nAnalgesic / Antipyretic	\N	\N	2020-11-11 02:51:12.452903+00	44		f	179	\N	\N	f	\N	{}	{}	2020-11-11 02:51:12.452931+00
342	Eskinol Papaya Smooth White	- Removes deep seated dirt, excess oil and make up with Micro-Cleanse Anti-bacterial Formula\r\n- With pure Papaya Extract and Vitamin B3 to whiten skin in as early as 1 week , based on clinical test\r\n- Helps renew dull skin, leaving it smoother\r\n\r\nIngredients\r\nWater, Alcohol Denat., Sorbitol, Carica papaya Fruit Extract, Propylene Glycol, PEG-40 Hydrogenated Castol Oil, Niacinamide, Perfume, Tocopheryl Acetate, Menthol, Citric Acid, Benzophenone-3, Phenoxyethanol, CI 15985, CI 17200, CI 19140\r\n\r\n	0.00	\N	2020-11-16 09:41:44.218955+00	45		f	185	\N	\N	f	\N	{}	{}	2020-11-07 13:01:10.49741+00
356	Carbocisteine 50mg/mL	Carbocisteine 50mg/mL \r\n15mL\r\nMucolytic\r\n	\N	\N	2020-11-11 02:49:56.231411+00	44		f	81	\N	\N	f	\N	{}	{}	2020-11-11 02:49:56.231438+00
358	Optein	Lutein Capsules\r\nNo Therapeutic Claims	\N	\N	2020-11-11 02:52:05.870001+00	44		f	176	\N	\N	f	\N	{}	{}	2020-11-11 02:52:05.870029+00
359	Optive Fusion	A unique combination formula for instant relief, superior comfort and sustained protection from dry eye symptoms	\N	\N	2020-11-11 02:54:00.516218+00	44		f	176	\N	\N	f	\N	{}	{}	2020-11-11 02:54:00.516247+00
360	Pai Pa Koa Candy	Helps to relief of sore throat, cough, hoarseness, and loss of voice.\r\nHelps prevent dryness of throat from smoking, alcohol drinking and late night fatigue.	\N	\N	2020-11-11 02:55:38.646425+00	44		f	165	\N	\N	f	\N	{}	{}	2020-11-11 02:55:38.646451+00
361	pH Care Blue	Feel the extra cooling gush of ActiveCool™ to keep you clean, cool and fresh against kulong na init.	\N	\N	2020-11-11 02:57:19.192908+00	45		f	94	\N	\N	f	\N	{}	{}	2020-11-11 02:57:19.192935+00
362	Placenta White	Ideal for aging skin and areas susceptible to wrinkles or loss of subtleness. Helps renew damaged skin tissues and fades away skin blemishes.	\N	\N	2020-11-11 02:58:28.830204+00	45		f	184	\N	\N	f	\N	{}	{}	2020-11-11 02:58:28.830232+00
363	Ritemed Ascorbic Acid 100mg/5mL Syrup	Ritemed Ascorbic Acid 100mg/5mL Syrup\r\nVITAMINS	\N	\N	2020-11-11 02:59:35.527561+00	44		f	183	\N	\N	f	\N	{}	{}	2020-11-11 02:59:35.527588+00
364	Shaolin Oil 50mL	Liniment Counterirritant\r\n50mL\r\n	\N	\N	2020-11-11 03:02:00.547088+00	44		f	166	\N	\N	f	\N	{}	{}	2020-11-11 03:02:00.547116+00
365	Silka Papaya Soap	Experience a natural and effective way to cleanse and whiten your skin. Enriched with PAPAYA ENZYME that helps eliminate dead skin cells for clearer, younger-looking skin. Blended with Vitamin E that acts as antioxidant for strengthenng skin's barrier function, increase skin's resiliency against free radicals and conditioning agent for improved softness. Enjoy its fruity fragrance for all day freshness. Use regularly to achieve lighter, smoother complexion.	\N	\N	2020-11-11 03:04:39.211982+00	45		f	184	\N	\N	f	\N	{}	{}	2020-11-11 03:04:39.212007+00
367	Symdex-D	Phenylpropanolamine Hydrochloride + Chlorphenamine Maleate + Paracetamol\r\n25 mg / 2 mg / 325 mg \r\nDecongestnat / Antihistamine / Analgesic / Antipyretic\r\n	\N	\N	2020-11-11 03:16:54.250372+00	44		f	81	\N	\N	f	\N	{}	{}	2020-11-11 03:16:54.250398+00
368	Paracetamol 100 mg / mL	Paracetamol 100 mg / mL\r\n15mL\r\nAnalgesic / Antipyretic\r\n	\N	\N	2020-11-11 03:22:18.52336+00	44		f	179	\N	\N	f	\N	{}	{}	2020-11-11 03:22:18.523385+00
370	Trust Pill	Ethinyl Estradiol + Levenorgestrel \r\n30mcg/125mcg\r\nFerrous Fumarate\r\n75mg\r\nTablet \r\nOral Contraceptive\r\n	\N	\N	2020-11-11 03:26:59.141221+00	44		f	163	\N	\N	f	\N	{}	{}	2020-11-11 03:26:59.14125+00
371	Urisam	Blumea balsamifera L. Sambong Leaf\r\n500mg \r\nAnti-urolithiasis / Diuretic\r\n	\N	\N	2020-11-11 03:29:02.649037+00	44		f	165	\N	\N	f	\N	{}	{}	2020-11-11 03:29:02.649065+00
372	Loperamide 2mg	Loperamide 2mg\r\nCapsule\r\nAntimotility	\N	\N	2020-11-11 03:30:10.457982+00	44		f	174	\N	\N	f	\N	{}	{}	2020-11-11 03:30:10.458008+00
373	Ascorbic Acid 500mg Tablet	Ascorbic Acid 500mg Tablet\r\nVitamin	\N	\N	2020-11-11 03:31:16.252366+00	44		f	183	\N	\N	f	\N	{}	{}	2020-11-11 03:31:16.252395+00
374	Petroleum Jelly 100g	Petroleum Jelly 100g\r\nProtectant\r\n	\N	\N	2020-11-11 03:32:04.43097+00	44		f	166	\N	\N	f	\N	{}	{}	2020-11-11 03:32:04.430999+00
375	Xanthone Plus	Mangosteen and Malunggay Capsule\r\nFood Supplement\r\nNo Approved Therapeutic Claims	\N	\N	2020-11-11 03:33:30.125678+00	44		f	165	\N	\N	f	\N	{}	{}	2020-11-11 03:33:30.125706+00
376	Conzace	Multivitamins + Minerals\r\n\r\nConzace® has the highest levels of Zinc, Vitamins A, C, and E-proven to help immunity & the looks, like no other. This superior formulation combines all the molecules needed to give you healthy skin & hair. It also helps strengthen the immune system by 140% more vs. no supplementation.	100.00	\N	2020-11-14 11:26:25.633868+00	44		t	183	\N	\N	f	\N	{}	{}	2020-11-12 21:03:13.117652+00
239	KF94 Korean Mask by HengDe	Korean Mask Disposable Facemask\r\nKF94 by HengDe\r\nWhite	55.00	\N	2020-11-21 01:21:50.718674+00	44		f	204	\N	\N	f	\N	{}	{}	2020-10-30 16:21:37.171765+00
380	CIGLA-KAS	Sodium Ascorbate 600mg\r\n\r\n	5.00	\N	2020-11-26 05:22:17.180284+00	44		t	183	\N	\N	f	\N	{}	{}	2020-11-26 05:22:17.180312+00
\.


--
-- Data for Name: product_productimage; Type: TABLE DATA; Schema: public; Owner: drupphuser1
--

COPY public.product_productimage (id, image, ppoi, alt, sort_order, product_id) FROM stdin;
512	products/12/199/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		2	199
317	products/87/189/function_uuid4_at_0x7fc8f5d02710.JPG	0.5x0.5		0	189
513	products/12/199/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		3	199
514	products/12/199/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		4	199
515	products/12/199/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		5	199
761	products/75/345/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	345
517	products/12/199/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		7	199
537	products/12/234/function_uuid4_at_0x7fe53a595710.jpeg	0.5x0.5		0	234
422	products/12/198/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		7	198
423	products/12/198/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		8	198
424	products/12/198/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		9	198
425	products/12/198/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		10	198
426	products/12/198/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		11	198
427	products/12/198/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		12	198
542	products/12/234/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		5	234
620	products/87/189/function_uuid4_at_0x7f6feffb2710.jpg	0.5x0.5		1	189
621	products/87/189/function_uuid4_at_0x7f6feffb2710_tGGm0sM.jpg	0.5x0.5		2	189
625	products/75/247/function_uuid4_at_0x7f6feffb2710.webp	0.5x0.5		0	247
629	products/89/236/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		1	236
765	products/75/349/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	349
766	products/75/349/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		1	349
639	products/89/254/function_uuid4_at_0x7f6feffb2710.jpg	0.5x0.5		0	254
640	products/89/254/function_uuid4_at_0x7f6feffb2710_hd3BgHD.jpg	0.5x0.5		1	254
493	products/12/200/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		7	200
494	products/12/200/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		8	200
495	products/12/200/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		9	200
496	products/12/200/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		10	200
27	products/10/16/function_uuid4_at_0x7f117be0b710.jpg	0.5x0.5		0	16
28	products/10/17/function_uuid4_at_0x7f117be0b710.jpg	0.5x0.5		0	17
497	products/12/200/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		11	200
30	products/10/19/function_uuid4_at_0x7f117be0b710.jpg	0.5x0.5		0	19
31	products/10/20/function_uuid4_at_0x7f117be0b710.jpg	0.5x0.5		0	20
32	products/10/21/function_uuid4_at_0x7f117be0b710.jpg	0.5x0.5		0	21
498	products/12/200/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		12	200
34	products/10/23/function_uuid4_at_0x7f117be0b710.jpg	0.5x0.5		0	23
35	products/10/24/function_uuid4_at_0x7f117be0b710.jpg	0.5x0.5		0	24
36	products/10/25/function_uuid4_at_0x7f117be0b710.jpg	0.5x0.5		0	25
37	products/10/26/function_uuid4_at_0x7f117be0b710.jpg	0.5x0.5		0	26
539	products/12/234/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		2	234
541	products/12/234/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		4	234
543	products/12/234/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		6	234
556	products/12/238/function_uuid4_at_0x7f404ce45710.jpeg	0.5x0.5		0	238
558	products/12/238/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		2	238
560	products/12/238/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		4	238
561	products/12/238/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		5	238
562	products/12/238/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		6	238
645	products/62/258/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	258
651	products/62/264/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	264
657	products/62/270/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	270
661	products/62/274/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	274
664	products/62/277/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	277
672	products/62/285/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	285
675	products/62/288/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	288
575	products/53/206/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	206
578	products/53/209/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	209
581	products/53/213/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	213
584	products/53/216/function_uuid4_at_0x7f823ea15710.png	0.5x0.5		0	216
586	products/53/218/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	218
571	products/53/223/function_uuid4_at_0x7f823ea15710.webp	0.5x0.5		0	223
677	products/62/290/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	290
73	products/45/64/function_uuid4_at_0x7f5791b73710.jpg	0.5x0.5		0	64
74	products/45/63/function_uuid4_at_0x7f5791b73710.png	0.5x0.5		0	63
75	products/45/65/function_uuid4_at_0x7f5791b73710.jpg	0.5x0.5		0	65
76	products/45/66/function_uuid4_at_0x7f5791b73710.jpg	0.5x0.5		0	66
77	products/45/67/function_uuid4_at_0x7f5791b73710.jpg	0.5x0.5		0	67
78	products/45/68/function_uuid4_at_0x7f5791b73710.jpg	0.5x0.5		0	68
79	products/45/69/function_uuid4_at_0x7f5791b73710.jpg	0.5x0.5		0	69
80	products/45/70/function_uuid4_at_0x7f5791b73710.jpg	0.5x0.5		0	70
81	products/45/72/function_uuid4_at_0x7f840d28b710.jpg	0.5x0.5		0	72
82	products/45/73/function_uuid4_at_0x7f840d28b710.jpg	0.5x0.5		0	73
83	products/45/74/function_uuid4_at_0x7f840d28b710.png	0.5x0.5		0	74
26	products/10/15/function_uuid4_at_0x7f117be0b710.jpg	0.5x0.5		0	15
92	products/64/83/function_uuid4_at_0x7f840d28b710.jpg	0.5x0.5		0	83
314	products/87/186/function_uuid4_at_0x7fc8f5d02710.JPG	0.5x0.5		0	186
319	products/87/191/function_uuid4_at_0x7fc8f5d02710.JPG	0.5x0.5		0	191
401	products/12/198/function_uuid4_at_0x7fa13582e710.png	0.5x0.5		0	198
762	products/75/346/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	346
767	products/75/350/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	350
403	products/12/198/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		2	198
405	products/12/198/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		4	198
406	products/12/198/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		5	198
116	products/64/107/function_uuid4_at_0x7f9683100710.jpg	0.5x0.5		0	107
117	products/64/108/function_uuid4_at_0x7f9683100710.jpg	0.5x0.5		0	108
407	products/12/198/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		6	198
119	products/64/110/function_uuid4_at_0x7f9683100710.jpg	0.5x0.5		0	110
430	products/12/199/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		1	199
544	products/89/235/function_uuid4_at_0x7f404ce45710.jpg	0.5x0.5		0	235
122	products/64/115/function_uuid4_at_0x7f9683100710.jpg	0.5x0.5		0	115
545	products/89/235/function_uuid4_at_0x7f404ce45710_rENWGxs.jpg	0.5x0.5		1	235
546	products/89/235/function_uuid4_at_0x7f404ce45710_ndKvrun.jpg	0.5x0.5		2	235
431	products/12/199/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		1	199
547	products/89/235/function_uuid4_at_0x7f404ce45710_wO8uQmT.jpg	0.5x0.5		3	235
774	products/62/356/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	356
778	products/62/360/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	360
626	products/75/248/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	248
782	products/62/364/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	364
783	products/62/365/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	365
786	products/62/368/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	368
789	products/62/371/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	371
472	products/12/229/function_uuid4_at_0x7fb081402710.png	0.5x0.5		0	229
563	products/12/238/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		7	238
432	products/12/199/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		1	199
564	products/12/238/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		8	238
433	products/12/199/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		1	199
790	products/62/372/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	372
499	products/12/232/function_uuid4_at_0x7fe53a595710.jpeg	0.5x0.5		0	232
501	products/12/232/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		2	232
503	products/12/232/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		4	232
504	products/12/232/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		5	232
505	products/12/232/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		6	232
474	products/12/229/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		1	229
565	products/12/238/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		9	238
566	products/12/238/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		10	238
476	products/12/229/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		1	229
567	products/12/238/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		11	238
568	products/12/238/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		12	238
477	products/12/229/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		1	229
478	products/12/229/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		1	229
687	products/62/300/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	300
572	products/53/203/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	203
576	products/53/207/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	207
580	products/53/212/function_uuid4_at_0x7f823ea15710.png	0.5x0.5		0	212
582	products/53/214/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	214
588	products/53/220/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	220
589	products/53/221/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	221
641	products/87/255/function_uuid4_at_0x7f6feffb2710.jpg	0.5x0.5		0	255
642	products/87/255/function_uuid4_at_0x7f6feffb2710_qgAR1l9.jpg	0.5x0.5		1	255
646	products/62/259/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	259
653	products/62/266/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	266
658	products/12/271/function_uuid4_at_0x7f6feffb2710.jpeg	0.5x0.5		0	271
662	products/62/275/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	275
667	products/62/280/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	280
673	products/62/286/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	286
678	products/62/291/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	291
681	products/62/294/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	294
684	products/62/297/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	297
690	products/62/303/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	303
691	products/62/304/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	304
694	products/62/307/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	307
698	products/75/310/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	310
702	products/75/314/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	314
703	products/75/315/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	315
704	products/75/315/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		1	315
707	products/75/318/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	318
428	products/12/199/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		1	199
709	products/75/320/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	320
429	products/12/199/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		1	199
315	products/87/187/function_uuid4_at_0x7fc8f5d02710.JPG	0.5x0.5		0	187
408	products/12/199/function_uuid4_at_0x7fa13582e710.jpeg	0.5x0.5		0	199
409	products/12/199/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		1	199
763	products/75/347/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	347
548	products/89/236/function_uuid4_at_0x7f404ce45710.jpg	0.5x0.5		0	236
569	products/1/239/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	239
768	products/75/351/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	351
772	products/62/354/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	354
623	products/12/245/function_uuid4_at_0x7f6feffb2710.jpeg	0.5x0.5		0	245
434	products/40/201/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		0	201
435	products/40/201/function_uuid4_at_0x7f822845f710.png	0.5x0.5		1	201
436	products/40/201/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		2	201
776	products/62/358/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	358
779	products/62/361/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	361
643	products/62/256/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	256
647	products/62/260/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	260
648	products/62/261/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	261
649	products/62/262/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	262
654	products/62/267/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	267
784	products/62/366/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	366
787	products/62/369/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	369
791	products/62/373/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	373
793	products/62/375/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	375
802	products/89/254/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		5	254
659	products/12/272/function_uuid4_at_0x7f6feffb2710.jpeg	0.5x0.5		0	272
663	products/62/276/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	276
573	products/53/204/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	204
577	products/53/208/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	208
583	products/53/215/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	215
587	products/53/219/function_uuid4_at_0x7f823ea15710.png	0.5x0.5		0	219
410	products/12/199/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		1	199
591	products/53/224/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	224
668	products/62/281/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	281
669	products/62/282/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	282
670	products/62/283/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	283
674	products/62/287/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	287
608	products/36/244/function_uuid4_at_0x7f6feffb2710.jpg	0.5x0.5		0	244
614	products/36/244/function_uuid4_at_0x7f6feffb2710_TqrMN5e.jpg	0.5x0.5		2	244
615	products/36/244/function_uuid4_at_0x7f6feffb2710_nQ4Qc7W.jpg	0.5x0.5		3	244
412	products/12/199/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		1	199
679	products/62/292/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	292
682	products/62/295/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	295
413	products/12/199/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		1	199
685	products/62/298/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	298
688	products/62/301/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	301
692	products/62/305/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	305
695	products/75/308/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	308
696	products/75/308/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		1	308
699	products/75/311/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	311
701	products/75/313/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	313
705	products/75/316/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	316
710	products/75/321/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	321
712	products/75/323/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	323
714	products/75/325/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	325
717	products/75/327/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	327
721	products/12/330/function_uuid4_at_0x7f6feffb2710.jpeg	0.5x0.5		0	330
812	products/89/235/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		9	235
799	products/89/376/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		4	376
738	products/10/24/function_uuid4_at_0x7fecdd9f6710_Taoom86.jpg	0.5x0.5		1	24
798	products/89/376/function_uuid4_at_0x7f585e929710.png	0.5x0.5		0	376
752	products/89/254/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		2	254
742	products/12/333/function_uuid4_at_0x7fe44f584710.jpeg	0.5x0.5		0	333
813	products/75/380/function_uuid4_at_0x7f0f6f62b710.png	0.5x0.5		0	380
748	products/12/337/function_uuid4_at_0x7fdffe429710.jpeg	0.5x0.5		0	337
750	products/12/339/function_uuid4_at_0x7fdffe429710.jpeg	0.5x0.5		0	339
753	products/89/254/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		3	254
754	products/89/254/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		4	254
756	products/12/341/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	341
316	products/87/188/function_uuid4_at_0x7fc8f5d02710.JPG	0.5x0.5		0	188
318	products/87/190/function_uuid4_at_0x7fc8f5d02710.JPG	0.5x0.5		0	190
415	products/12/200/function_uuid4_at_0x7fa13582e710.png	0.5x0.5		0	200
764	products/75/348/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	348
417	products/12/200/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		2	200
769	products/75/352/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	352
419	products/12/200/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		4	200
420	products/12/200/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		5	200
624	products/75/246/function_uuid4_at_0x7f6feffb2710.jpg	0.5x0.5		0	246
421	products/12/200/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		6	200
628	products/12/250/function_uuid4_at_0x7f6feffb2710.jpeg	0.5x0.5		0	250
638	products/89/253/function_uuid4_at_0x7f6feffb2710.jpg	0.5x0.5		0	253
644	products/62/257/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	257
650	products/62/263/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	263
652	products/62/265/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	265
655	products/62/268/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	268
461	products/40/226/function_uuid4_at_0x7fa13582e710.png	0.5x0.5		0	226
462	products/40/226/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		1	226
773	products/62/355/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	355
775	products/62/357/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	357
463	products/40/226/function_uuid4_at_0x7f822845f710.png	0.5x0.5		1	226
777	products/62/359/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	359
464	products/40/226/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		1	226
780	products/62/362/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	362
549	products/12/237/function_uuid4_at_0x7f404ce45710.jpeg	0.5x0.5		0	237
781	products/62/363/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	363
785	products/62/367/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	367
788	products/62/370/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	370
656	products/62/269/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	269
660	products/62/273/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	273
665	products/12/278/function_uuid4_at_0x7f6feffb2710.jpeg	0.5x0.5		0	278
792	products/62/374/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		0	374
671	products/62/284/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	284
551	products/12/237/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		2	237
794	products/89/235/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		4	235
553	products/12/237/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		4	237
554	products/12/237/function_uuid4_at_0x7f2fc45ae710.png	0.5x0.5		5	237
555	products/12/237/function_uuid4_at_0x7f0b95cdb710.png	0.5x0.5		6	237
676	products/62/289/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	289
570	products/53/225/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	225
680	products/62/293/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	293
683	products/62/296/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	296
686	products/62/299/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	299
689	products/62/302/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	302
693	products/62/306/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	306
574	products/53/205/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	205
579	products/53/210/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	210
585	products/53/217/function_uuid4_at_0x7f823ea15710.jpg	0.5x0.5		0	217
590	products/53/222/function_uuid4_at_0x7f823ea15710.webp	0.5x0.5		0	222
697	products/75/309/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	309
700	products/75/312/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	312
706	products/75/317/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	317
609	products/36/244/function_uuid4_at_0x7f6feffb2710_JHdstgh.jpg	0.5x0.5		1	244
616	products/36/244/function_uuid4_at_0x7f6feffb2710_Se6Whfj.jpg	0.5x0.5		4	244
795	products/89/235/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		5	235
708	products/75/319/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	319
711	products/75/322/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	322
713	products/75/324/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	324
715	products/75/326/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	326
716	products/75/326/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		1	326
718	products/12/249/function_uuid4_at_0x7f6feffb2710.jpeg	0.5x0.5		0	249
720	products/12/329/function_uuid4_at_0x7f6feffb2710.jpeg	0.5x0.5		0	329
803	products/89/254/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		6	254
809	products/89/235/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		6	235
810	products/89/235/function_uuid4_at_0x7fc584cd6710.png	0.5x0.5		7	235
811	products/89/235/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		8	235
760	products/89/344/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	344
797	products/89/376/function_uuid4_at_0x7f585e929710.jpg	0.5x0.5		1	376
741	products/12/332/function_uuid4_at_0x7fe44f584710.jpeg	0.5x0.5		0	332
747	products/12/336/function_uuid4_at_0x7fdffe429710.jpeg	0.5x0.5		0	336
749	products/12/338/function_uuid4_at_0x7fdffe429710.jpeg	0.5x0.5		0	338
757	products/12/342/function_uuid4_at_0x7f6feffb2710.png	0.5x0.5		0	342
\.


--
-- Data for Name: product_producttranslation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_producttranslation (id, seo_title, seo_description, language_code, name, description, product_id, description_json) FROM stdin;
\.


--
-- Data for Name: product_producttype; Type: TABLE DATA; Schema: public; Owner: drupphuser1
--

COPY public.product_producttype (id, name, has_variants, is_shipping_required, weight, is_digital, meta, user_id, is_published, publication_date) FROM stdin;
44	MEDICAL	t	f	0	f	{}	13	t	\N
45	PERSONAL CARE	t	f	0	f	{}	13	t	\N
46	CONSUMER PRODUCTS	t	f	0	f	{}	13	t	\N
\.


--
-- Data for Name: product_productvariant; Type: TABLE DATA; Schema: public; Owner: drupphuser1
--

COPY public.product_productvariant (id, sku, name, price_override, product_id, attributes, cost_price, quantity, quantity_allocated, track_inventory, weight) FROM stdin;
184	C&C-MED-0001	RITEMED Ambroxol Tablet (30mg)	5.50	186		5.50	10	0	t	\N
286	P&F-MED 002	Alvedon (PARACETAMOL) 500mg Tablet	0.00	337		0.00	24	0	t	\N
186	V&M-MED-002	RITEMED B-Complex Tablet	4.50	188		4.50	10	0	t	\N
288	P&F-MED 004	Alaxan FR (IBUPROFEN + PARACETAMOL) Capsule	0.00	339		0.00	36	0	t	\N
251	MED-0005	Colgate Test 1	100.00	254		100.00	7	0	t	\N
290	BAT-PC 002	Dove Coconut Milk Bar Soap	0.00	341		0.00	12	0	t	\N
272	gastro001	Diatabs	7.75	323		7.75	100	0	t	\N
199	sam123	sample 1	123.00	201		123.00	123	0	t	\N
223	F&HS-MED-005	Xanthone Plus Gold	15.00	225		15.00	100	0	t	\N
221	V&M-MED-011	Stresstabs	11.50	223		11.50	100	0	t	\N
197	V&M-MED 001	Poten-Cee (ASCORBIC ACID) 500mg Chewable Tablet	0.00	199		0.00	24	0	t	\N
235	C&C-MED 002	Sinecod Forte (BUTAMIRATE CITRATE) 50mg SR Tsblet	0.00	237		0.00	24	0	t	\N
209	C&C-MED-0002	Decolgen	6.20	211		6.20	100	0	t	\N
227	GIT-MED 001	Imodium (LOPERAMIDE) 2mg Capsule	0.00	229		0.00	24	0	t	\N
257	cough 003	Acetylcysteine 600mg	30.00	308		30.00	100	0	t	\N
259	herbal 001	Bigurlai Tea	8.00	310		8.00	50	0	t	\N
243	vit 001	Centrum Capsule	12.00	246		12.00	100	0	t	\N
201	V&M-MED-001	Ascorbic Acid (500mg)	6.50	203		6.50	100	0	t	\N
203	V&M-MED-002	Cecon (500mg)	10.00	205		10.00	100	0	t	\N
21	CHO-FOO-001	Nestle Crunch	120.00	21		120.00	100	0	t	\N
17	MUL-MED-001	Enervon-C	250.00	17		250.00	150	0	t	\N
205	V&M-MED-004	Celine + Chewable Tablet	7.00	207		7.00	100	0	t	\N
207	ANT-MED-0001	Cetirizine Tablet (10mg)	5.00	209		5.00	100	0	t	\N
245	VIT 003	ENERVON CAPSULE	7.00	248		7.00	500	0	t	\N
211	MUS-MED-001	Diclofenac Sodium Tablet (5mg)	2.00	213		2.00	100	0	t	\N
213	F&HS-MED-002	DTX-500	14.00	215		14.00	100	0	t	\N
215	MUS-MED-002	Flanax Forte (550mg)	24.45	217		24.45	100	0	t	\N
217	GAS-MED-001	Kremil-S	7.85	219		7.85	100	0	t	\N
219	V&M-MED-009	Pharex B-Complex	5.00	221		5.00	100	0	t	\N
69	00007	Immunomax 30mg CM-Glucan Capsule	45.50	69		45.50	50	0	t	\N
265	cough 005	Carbocisteine 250mg / 5mL	0.00	316		0.00	10	0	t	\N
247	OPH-MED 002	Eye Mo (TETRAHDROZOLINE HCL) Red Eyes Formula	0.00	250		0.00	24	0	t	\N
269	oraldent 002	Colgate Spicy Fresh	0.00	320		0.00	10	0	t	\N
188	GAS-MED-001	RITEMED Bisacodyl (5mg) Tablet	15.00	190		15.00	10	0	t	\N
19	MUL-MED-001	MX-3	150.00	19		150.00	200	0	t	\N
253	FA&S-MED 001	Mediplast standard Plastic Strips	0.00	271		0.00	24	0	t	\N
276	beau001	Eskinol Papaya Smooth White 75ml	47.00	327		47.00	10	0	t	\N
274	soap 002	Dove Pink Bar Soap	52.00	325		52.00	10	0	t	\N
261	fever001	Biogesic 100mg/mL	71.00	312		71.00	10	0	t	\N
16	ANA-MED-001	Biogesic	250.00	16		250.00	150	2	t	\N
262	fever 002	Biogesic 120mg/5mL	84.00	313		84.00	10	0	t	\N
255	FP-MED 001	Lady (ETHINYL ESTRADIOL + LEVONORGESTREL) Hormonal Contraceptive	0.00	278		0.00	10	0	t	\N
278	GAL-MED 002	Shaolin Oil Liniment 50ml	0.00	329		0.00	24	0	t	\N
282	BAT-PC 002	Likas Papaya Soap	0.00	333		0.00	12	0	t	\N
24	MUL-MED-001	Robust	359.00	24		359.00	200	0	t	\N
233	MED-0021	Colgate	100.00	235		100.00	9	2	t	\N
26	COU-MED-001	Vicks-44	790.00	26		790.00	23	0	t	\N
296	Covid essential 001	J. Chemie Isopropyl Alcohol 500mL	90.00	347		90.00	100	0	t	\N
294	herbal 004	Turmeric Tea	7.00	345		7.00	100	0	t	\N
74	00008	Zinc + Vitamin D plus Prebiotic and Probiotic	1650.00	74		1650.00	6	0	t	\N
298	dermmed 003	Calmoseptine Cream	45.00	349		45.00	40	0	t	\N
300	vit 007	Myra E 8's	96.00	351		96.00	5	0	t	\N
73	00006	Amazing Garcinia Cambogia	900.00	73		900.00	9	0	t	\N
15	ANA-MED-001	Alaxan FR	120.00	15		120.00	200	5	t	\N
241	Mas-med-0001	KF94 Korean Mask by HengDe	55.00	244		55.00	1	0	t	\N
83	asc-tab 01	apcee 500mg tablet	3.00	83		3.00	500	0	t	\N
72	00008	Amazing Pure Organic Barley Capsule	1750.00	72		1750.00	2	0	t	\N
70	00007	Myra 400 I.U	13.00	70		13.00	100	0	t	\N
68	00006	Immunomax 20mg CM-Glucan Syrup 60ml	315.00	68		315.00	5	0	t	\N
67	00005	Pearly-C	11.00	67		11.00	200	0	t	\N
66	00004	Immunomax 10mg CM-Glucan Capsule	16.75	66		16.75	50	0	t	\N
65	00003	Fern-c 30's	216.00	65		216.00	20	0	t	\N
64	00002	Clusivol Plus	8.00	64		8.00	200	0	t	\N
63	00001	Conzace Capsule	16.00	63		16.00	200	0	t	\N
25	TAM-COS-001	Tampax	1200.00	25		1200.00	16	0	t	\N
23	BUR-MED-001	Polysporin	1800.00	23		1800.00	23	0	t	\N
20	COL-MED-001	Neozep	160.00	20		160.00	80	0	t	\N
232	B&KP-MED 001	Johnson's Baby Soap 100gm	0.00	234		0.00	12	0	t	\N
185	V&M-MED-001	RITEMED Ascorbic Acid (500mg) 100's	350.00	187		350.00	10	0	t	\N
275	herbal 003	Drivemax Capsule	105.00	326		105.00	10	0	t	\N
273	soap 001	Dove Coconut Milk Bar Soap	52.00	324		52.00	10	0	t	\N
110	metopr-ooo1	stabeta 10mg	1.50	110		1.50	300	0	t	\N
230	OPH-MED 001	Acular (KETOROLAC TROMETAMOL) 5mg/ml Eye Drops	0.00	232		0.00	24	0	t	\N
198	B&KP-PC 002	Johnson's Baby Oil 50ml	0.00	200		0.00	24	0	t	\N
196	C&C-MED 001	Flucysteine (ACETYLCYSTEINE) 600MG Powder for Oral Solution	0.00	198		0.00	12	0	t	\N
271	cough 006	Dextromethorphan Hydrobromide 10 mg / 5 mL	40.00	322		40.00	10	0	t	\N
242	O&DC-PC 001	Colgate Plax Peppermint Fresh 100ml	0.00	245		0.00	24	0	t	\N
270	vit 005	Conzace	13.00	321		13.00	100	0	t	\N
200	V&M-MED-001	Enervon Tablet	7.00	202		7.00	100	0	t	\N
244	VIT 002	STRESSTABS	13.00	247		13.00	100	0	t	\N
266	vit 004	Ceelin Plus Chewables	6.50	317		6.50	10	0	t	\N
187	C&C-MED-0002	RITEMED Carbocistine Capsule (500mg)	5.00	189		5.00	50	0	t	\N
263	fever 003	Biogesic 250mg/5mL	132.00	314		132.00	10	0	t	\N
189	V&M-MED-003	RITEMED Paracetamol (500mg) Tablet	2.00	191		2.00	10	0	t	\N
234	SHA-0001	Palmolive Shampoo	200.00	236		200.00	20	0	t	\N
224	SAMPLE123	SAMPLE 2	123.00	226		123.00	123	0	t	\N
250	MED-0004	Johnson Baby Powder	100.00	253		100.00	5	0	t	\N
305	VITAMINS&MINS	CIGLA-KAS	5.00	380		5.00	400	0	t	\N
252	GEN-MULTIMIN-001	GENERIC Multivitamins/Minerals EURIVIT 120 mL Syrup	75.00	255		75.00	10	0	t	\N
254	F&HS-MED 001	Xanthone Plus Capsule	0.00	272		0.00	24	0	t	\N
236	GAL-MED 001	Ming's Garlic Oil Softgel 1000mg	0.00	238		0.00	30	0	t	\N
202	C&C-MED-001	Carbocisteine Capsule (500mg)	2.50	204		2.50	100	0	t	\N
204	V&M-MED-003	Cecon Jr.	10.00	206		10.00	100	0	t	\N
206	V&M-MED-005	Centrum Advance 1's	11.00	208		11.00	100	0	t	\N
208	V&M-MED-006	Clusivol+ Tablet	7.00	210		7.00	100	0	t	\N
210	GAS-MED-001	Diatabs Capsule (2mg)	8.00	212		8.00	100	0	t	\N
212	F&HS-MED-001	Doktor Pinoy Capsule	13.40	214		13.40	100	0	t	\N
214	V&M-MED-007	Enervon Tablet	7.00	216		7.00	100	0	t	\N
216	P&F-MED-001	Kiddielets	3.00	218		3.00	100	0	t	\N
218	V&M-MED-008	MIghty Cee (500mg)	10.00	220		10.00	100	0	t	\N
220	V&M-MED-010	Pharex E (400 IU)	10.00	222		10.00	100	0	t	\N
222	F&HS-MED-004	Xantone+ Capsule	13.00	224		13.00	100	0	t	\N
258	cough 004	Ambroxol 6mg/mL	30.00	309		30.00	10	0	t	\N
260	herbal 002	Biofit Tea	6.50	311		6.50	100	0	t	\N
279	V&M-MED 002	RiteMed (ASCORBIC ACID) 100mg/5ml Syrup 120ml	0.00	330		0.00	24	0	t	\N
264	dermmed001	Calmoseptine Cream	45.00	315		45.00	40	0	t	\N
267	dermmed 002	Cetaphil Moisturizing Cream	0.00	318		0.00	10	0	t	\N
268	oraldent001	Colgate Plax Peppermint Fresh	0.00	319		0.00	10	0	t	\N
295	FP med 001	Lady Pills	45.00	346		45.00	40	0	t	\N
281	P&F-MED 001	Advil (IBUPROPEN) 200mg Softgel Capsule	0.00	332		0.00	20	0	t	\N
246	O&DC-PC 002	Colgate Fresh Confidence	139.00	249		139.00	24	0	t	\N
285	C&C-MED 003	Robitusin (GUAIFENESIN) 200mg Softgel Capsule	0.00	336		0.00	36	0	t	\N
287	V&M-MED 003	Myra e (ALPHA TOCOPHEROL) Vitsmin E 400iu Capsule	0.00	338		0.00	36	0	t	\N
297	Covid essential 002	J.Chemie Ethyl Alcohol Spray	85.00	348		85.00	100	0	t	\N
299	vit 006	Myra E	12.00	350		12.00	100	0	t	\N
301	gas med 001	Diatabs	7.25	352		7.25	100	0	t	\N
293	MED-0002	Lady Pills	150.00	344		150.00	8	0	t	\N
303	MED-0001	Conzace	100.00	376		100.00	4	0	t	\N
291	BEC-PC 001	Eskinol Papaya Smooth White	0.00	342		0.00	24	0	t	\N
115	med-gluco strip-0001	freestyle optium strip	45.00	115		45.00	100	0	t	\N
118	med-gal-0001	hygenix 70% 500ml	85.00	118		85.00	48	0	t	\N
108	pulse oxi 001	pulse oximeter	1900.00	108		1900.00	2	0	t	\N
107	lag 001	LAGUNDI WITH ZINC 600mg capsule	7.00	107		7.00	500	0	t	\N
\.


--
-- Data for Name: product_productvarianttranslation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_productvarianttranslation (id, language_code, name, product_variant_id) FROM stdin;
\.


--
-- Data for Name: product_variantimage; Type: TABLE DATA; Schema: public; Owner: drupphuser1
--

COPY public.product_variantimage (id, image_id, variant_id) FROM stdin;
\.


--
-- Data for Name: shipping_shippingcities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_shippingcities (id, city, shipping_province_id) FROM stdin;
\.


--
-- Data for Name: shipping_shippingmethod; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_shippingmethod (id, name, maximum_order_price, maximum_order_weight, minimum_order_price, minimum_order_weight, price, type, shipping_zone_id, meta) FROM stdin;
\.


--
-- Data for Name: shipping_shippingmethodtranslation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_shippingmethodtranslation (id, language_code, name, shipping_method_id) FROM stdin;
\.


--
-- Data for Name: shipping_shippingprovince; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_shippingprovince (id, province, shipping_zone_id) FROM stdin;
\.


--
-- Data for Name: shipping_shippingzone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_shippingzone (id, name, countries, "default") FROM stdin;
\.


--
-- Data for Name: shipping_usershippingzone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_usershippingzone (id, shipping_zone_id, user_id) FROM stdin;
\.


--
-- Data for Name: site_authorizationkey; Type: TABLE DATA; Schema: public; Owner: drupphuser1
--

COPY public.site_authorizationkey (id, name, key, password, site_settings_id) FROM stdin;
2	google-oauth2	1013502534227-88lbgtcarenbp8h9hcbo4jfvn7bktstm.apps.googleusercontent.com	jPwnlvHPY7hO1lWGQxRJN3pg	1
\.


--
-- Data for Name: site_sitesettings; Type: TABLE DATA; Schema: public; Owner: drupphuser1
--

COPY public.site_sitesettings (id, header_text, description, site_id, bottom_menu_id, top_menu_id, display_gross_prices, include_taxes_in_prices, charge_taxes_on_shipping, track_inventory_by_default, homepage_collection_id, default_weight_unit, automatic_fulfillment_digital_products, default_digital_max_downloads, default_digital_url_valid_days, company_address_id) FROM stdin;
1			1	2	1	t	t	t	t	\N	kg	f	\N	\N	\N
\.


--
-- Data for Name: site_sitesettingstranslation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.site_sitesettingstranslation (id, language_code, header_text, description, site_settings_id) FROM stdin;
\.


--
-- Data for Name: social_auth_association; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.social_auth_association (id, server_url, handle, secret, issued, lifetime, assoc_type) FROM stdin;
\.


--
-- Data for Name: social_auth_code; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.social_auth_code (id, email, code, verified, "timestamp") FROM stdin;
\.


--
-- Data for Name: social_auth_nonce; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.social_auth_nonce (id, server_url, "timestamp", salt) FROM stdin;
\.


--
-- Data for Name: social_auth_partial; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.social_auth_partial (id, token, next_step, backend, data, "timestamp") FROM stdin;
\.


--
-- Data for Name: social_auth_usersocialauth; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.social_auth_usersocialauth (id, provider, uid, extra_data, user_id) FROM stdin;
13	google-oauth2	charleston.drupph@gmail.com	{"auth_time": 1605352777, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.A0AfH6SMCHLmdpVoRtul8TrgtYw-3rZIBpU4GqRQdZKCtGDcufrQgFoYSKhdwUVYvbcZGJ90KU0ZnUkrggnAWpYfBCcXp4jtSWZL_Z8yDngEB113yQIDkq_XC0JX9oTZRLELr1W7e8CP0uUj9ekcp9HN-_WPV_Dt8fF6wJciRgR7qg"}	98
9	google-oauth2	ruedech.rt@gmail.com	{"auth_time": 1603963643, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.A0AfH6SMAWe1g5upU816T_ucuybtHLcAlkK3ligcmmSJedimHC7AikNeJTdaPDXZZlaN1t-lUQmBX4miFEvDu3CAga_BjUWTwqR7FQY0Hvyip3NO7XevM4OAUnrXYjjWkv4CFKF0zdUtmvQwmJiaJWKqO9G7ucAlm1VVR0lTeZcjw"}	90
11	google-oauth2	charlie.drupph@gmail.com	{"auth_time": 1606490386, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.a0AfH6SMCmDKigJsdXXXOSihJ34wGdg_W00ArAD-DpHdFUG8Ct68jXlFuPpXTwC8Sl_5Dftq00sPFeBwPziyN5xfOXkDyTFd87fNtedeFTJnHVhFSL9-BErGPt2bPbyWlY9au1gdQRx0dclx8iTn7y4Y7PwJj43qbsy1dDQelcVxKcLw"}	95
21	google-oauth2	mestanislao@inmyhouse.net	{"auth_time": 1605347490, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.A0AfH6SMCMq94A8CIEAztLGFnldDtb5vkXKgoeD9ZBUD3yutAMWfBbY8wXre3aWuTOza4IE3NIWHDGA1S9hX7p7zglTdJnUAwMlGxWkatyys_VXNKrlOFaddhO4eikmfO4PBAs95DWd18gUmosT45gZvdNQZ-YS2YZAjts7LacdEFq"}	103
5	google-oauth2	islandicho@orlamera.com	{"auth_time": 1600182577, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.a0AfH6SMDFjhUOkUsmV7l8zcaTeixAGI5XzddRkH0z2YhYXY-K6STFpEabp66awkQwp02Nea15yDFAMLac8hrczQ_KK6Xrq_vzcSQr3n3wCXO1Fru5U8Vj4nnaRe954RqDthzqvF_HKd21aLShyp305gOx4wxz3vxCsHY"}	9
24	google-oauth2	2200436@slu.edu.ph	{"auth_time": 1605366183, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.A0AfH6SMBvSqO_fUuBJuovltUrBmihm2XhxOvaL46AE1jGTEHt3KdXxQJh48SUNSxFvrtNK4L6KGrTCfbK7F2gRNcODPnoaChAGOykrTzaPLgutVmfKwSJXsgIeh4EA-LFYGKre2QVWfRM-CViNTznWjkUhUu4OTKJ88WTvg5bpwk"}	109
12	google-oauth2	island0288@gmail.com	{"auth_time": 1604645788, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.A0AfH6SMAZl6e6m4nVhijis9E0RCfD-Eru-FZNKgDzu77jEIBBw-QXrIb9sXKKQ2Oud3WTSD035225-DE4gjQT6ofJs3VS7faxf2FybOAdR6-nZ-MXFf7JwCHnxLmfAn6YQWaGo7D3ws3WXuvWlV2W8VsASTRE7cJianQxn9wdkkA"}	97
18	google-oauth2	meeyome@gmail.com	{"auth_time": 1605871262, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.a0AfH6SMA9fkyZ-83RU-_ZbhsUK0CzwIE_FLKWo6lcbMCKIvdRdO4Bw-CaeDqOQmaVywURSfSUTZuM7nwIJyHVVp3wQXIgPbLqPURGkazj46T5zUMTHfDjDkGrRCqdtl_GqXxvk4POm75HeZKtQIwvZJpmYvx8Fyb8_Q2M4Cc02rou"}	104
6	google-oauth2	drupphofficial@gmail.com	{"auth_time": 1603253900, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.a0AfH6SMDsDEHlw0UJ7r2BM0ZTDk1UkiJ-m_jdR6TXEo5Jncw_oM3iAWKxQDeHlP5X3ajeP9xy2HSrRHmSKMlNgWaoa82_9I6YzAMPQqjh0itbaUzTz-Rtwj9Tpdx38804LBi9F_8fPxeqe7cGR2rI4HFfMACBYdWI5PS5"}	40
4	google-oauth2	optievo.info@gmail.com	{"auth_time": 1604645989, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.A0AfH6SMCId0nIB-pd9h40yjlCgHC8ctjFvvoyYkOgc3bLFFSkhDPLHjQWZWtvT9m2D1yJtg_JvjBWd88oFS9WhpHpzrSHjjnPByrlfnS9E-poQrfkZm_xSx0YfW3zEWfwu0Tvm9uYUr-q1tohC9d5dwjtGArvAov-1VC64pFkPlOt7Q"}	9
3	google-oauth2	paulon.zervoulakus@gmail.com	{"auth_time": 1605921661, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.a0AfH6SMCRQYxzmKqA8l8YTt6wXsoVR30toa-H6jfSXiSHH0DtLUT3_WlXx_3D3zdtHv3HmPWkoOg2Z4nufsGXUZDRabp0EagCA_94Wrekf5HduQbLbKCyjdo0BUaOI83yKkXJLnVvqOsvvEaHTxsEZWKYDWOzPdVDWqiGDVw9MNOexw"}	36
22	google-oauth2	doomznyt@gmail.com	{"auth_time": 1605358909, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.A0AfH6SMDpyhBfHxNt8z6tNaTT44Fw-yDVDDGnYi8NhbKFzNA0sxnSkELysUdcof-EjS0GqibD9j3pDdWjHZwOxWfWPa2enTlndiRki55_dp8kipYwsfTtbQWLgzqJFuidyN28PfeM8DCJ4DJyKQf262tKayW3ZUs_g_maTdDraZv4"}	108
23	google-oauth2	michaelmalicsi090398@gmail.com	{"auth_time": 1605366352, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.A0AfH6SMCeCBH2hCdEiPmLbjNIQi-EzyTyvf_vN3KSEgbvlEo8M1PjNmVa3wBNF_r8EhpDBFLUuERJ8WCHi-s9phEqgzLw0W0UMI2byDqrxb3r4caOEW8PV1i2RxZKFoxcTriA14VqruxiKWDvifp94IFpeTH2ObmE42o0NuItu3iGZg"}	106
2	google-oauth2	pzervoulakus@inmyhouse.net	{"auth_time": 1606275499, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.a0AfH6SMAqzx7QNYKMTjMPL-Q6SHZU8hYo8ls5nbKIH5kcWs1b-RPItiEQxLxHNj9gMe9kHf9d4QE95cB48nWMcTSgs3ogZY_E0delN4MSDcYbnaLeAtLrNZojCTQoyNPQG5siE091raYZY2w-3wImXir24DENO0e7oq8yBX2CvRbcAg"}	1
26	google-oauth2	charlestonz3r0@gmail.com	{"auth_time": 1605682514, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.a0AfH6SMB1aIA5YUQjAXdkNTgWVnIMP8oD5kMRfzOj4mc9Vlp0SKqPuykgSNlY6wit5Q1o31jkzBPIxNxOwmO59Ai7eJEK4cs6WIpL4HMqq9zYFLhv20Wnem0yh490Qj_wKKX1HE2hH9qERK2XvfW_Y5GrQ9dOsP_-u7l75nkHNZQ"}	94
8	google-oauth2	digitaldelacruz@gmail.com	{"auth_time": 1605862684, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.a0AfH6SMBUSUVJLvrGoq5LY9mAjSTzXVTexdy3ZqKnQ1lgHpb9TvJnfmuFMq5JD12hi27CgvSQuHJgUzd4dprCKVoq3bf0hVjX0cCJxhkHasIAxeOLX7uStUoXhdw_41TAhvAa309Y00QgZhZRsL5-QCgAEZO7fFjva5hBaBcmBMj-"}	88
19	google-oauth2	meestanislao@rigeltech.ph	{"auth_time": 1605871253, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.a0AfH6SMCdQSQznvHl4WPkzj1HLuk7HSprcPaZBnnaDYp2kKhJIwyKFQkOyVAufHxxg-mqk_GO2-3bjzfzFMIeKRaN4av9GK7MFzPbArdRL42x001JHu8vS9Q2omPUyXvCgDNFJix0qkUjwIGiRADhvoakhBXgjMu6dHacIPgMGSU2"}	105
10	google-oauth2	charlestonvillegas@gmail.com	{"auth_time": 1605682179, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.a0AfH6SMC7In72i7WtHEgsdma4ScO9DEwOZPdbmJNF6Gz5bdL1kxkTkGrOARYhIDte5i4c3sqnn1G84D0fFm0GrtktT0rRg8GGtTL-o3EdA1HmvEegnSPlDNxEEEulasDtd3m0P3XWEEQdKjJNliomWT-5zYoPdAn_t-PtbNpoPnYX"}	91
25	google-oauth2	lee.drupph@gmail.com	{"auth_time": 1605681207, "expires": 3599, "token_type": "Bearer", "access_token": "ya29.a0AfH6SMC6sm46qTuxs-k25E9iRpcAHvPxS13_5neQKyrNVXxQESfAyUfK-pvrC2Vt3-OLPQEfs4BVpDOQGqIAh4eEUomyJ7TVgbK72ZjjKzl5OMi5_1Pmzc5crZZseq_BW9Ni0DTVYsqkw42eutmZPOTISkOIB47zzMKjyy8sAl4"}	89
\.


--
-- Data for Name: storefront_businessdocument; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.storefront_businessdocument (id, image, ppoi, title, store_id) FROM stdin;
1	storefront/document/4/5270169767_5a7e410bea_z.jpg	0.5x0.5	\N	4
2	storefront/document/36/COR.jpg	0.5x0.5	CPR	36
4	storefront/document/36/Mayors_permit_2020.jpg	0.5x0.5	Mayor's Permit	36
7	storefront/document/37/lto_bgx.jpg	0.5x0.5	\N	37
6	storefront/document/40/Mayors_permit_2020.jpg	0.5x0.5	Mayor's Permit	40
5	storefront/document/40/COR.jpg	0.5x0.5	COR	40
8	storefront/document/40/LTO.jpg	0.5x0.5	LTO	40
9	storefront/document/40/DTI.jpg	0.5x0.5	DTI	40
12	storefront/document/60/brgy_permit-page-001.jpg	0.5x0.5	BARANGAY PERMIT	60
14	storefront/document/60/Mayors_Permit.jpg	0.5x0.5	Mayor's Permit	60
15	storefront/document/60/DTI.jpg	0.5x0.5	DTI	60
13	storefront/document/60/LTO.jpg	0.5x0.5	LTO/FDA	60
16		0.5x0.5	DTI	49
17		0.5x0.5	FDA/LTO	49
18		0.5x0.5	FDA/LTO	49
19		0.5x0.5	FDA/LTO	49
20	storefront/document/49/sample1.png	0.5x0.5	FDA/LTO	49
21	storefront/document/29/sample.png	0.5x0.5	\N	29
22	storefront/document/55/business_permit004.jpg	0.5x0.5	Business Permit	55
23	storefront/document/55/CERT_OF_REGISTRATION_2303.jpg	0.5x0.5	Certificate of Registration	55
24	storefront/document/55/CERTIFICATE_OF_AUTHORITY012.jpg	0.5x0.5	Certificate of Authority	55
25	storefront/document/55/LISCENCE_TO_OPERATE007.jpg	0.5x0.5	License to Operate	55
\.


--
-- Data for Name: storefront_colorthemes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.storefront_colorthemes (id, name, css, order_arrangement) FROM stdin;
1	Default	storefront_default.css	1
2	Classic	storefront_classic.css	2
3	Dark	storefront_dark.css	3
4	Green	storefront_green.css	4
5	Orange	storefront_orange.css	5
6	Modern Blue	storefront_modernblue.css	6
7	Lilac	storefront_lilac.css	7
8	Magenta	storefront_magenta.css	8
\.


--
-- Data for Name: storefront_store; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.storefront_store (id, storename, banner_image, profile_image, ppoi, alt, is_publish, owner_id, storeaddress_id, dsap, operating_hours, color_themes_id, latitude, longtitude, storename_sticky) FROM stdin;
65	MD DrugStore			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
43	We Care Drug			0.5x0.5	\N	t	56	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
68	MADMJR Pharmacy			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
4	BOTIKA BETSKY INC.	storefront/banner/10/pharmacy-pharmacology-drugstore-medical-vector-15059384_aDwhgTN.jpg	storefront/profile/10/bestdadrgb-fez.jpg	0.5x0.5	\N	t	10	1	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "3:00 PM", "opening": "10:00 AM"}}]	4	14.576022	120.990828	f
6	ICL Healthcare			0.5x0.5	\N	t	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
8	HS Pharmacy		storefront/profile/19/1.png	0.5x0.5	\N	t	\N	2	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	5	14.705626	121.082973	t
49	Best Care Pharmacy	storefront/banner/62/1_zMfYkeG.png	storefront/profile/62/logos.png	0.51x0.5	\N	f	62	20	\N	[{"Monday": {"closing": "10:00 PM", "opening": "6:00 AM"}}, {"Tuesday": {"closing": "10:00 PM", "opening": "6:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "7:00 PM", "opening": "5:00 AM"}}, {"Sunday": {"closing": "12:00 PM", "opening": "9:00 AM"}}]	2	14.679174	121.078870	f
9	Conise Store			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
10	Conise Store1			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
11	Conise Store2			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
12	Conise Store3			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
7	DIGITAL DRUGSTORE			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
14	GoiiStore			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
15	ChikangStore			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
16	ChiChangStore			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
13	Conise Store 4			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
17	Conise Store 5			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
18	conise store 6			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
20	ChachiChang Store			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
19	conise store 7			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
22	conise store 8			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
23	conise store 9			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
24	conise store 10			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
25	conise store 11			0.5x0.5	\N	t	36	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
66	MAM Pharmacy			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
27	JDC Pharmacy			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
21	chibingchibing			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
26	Cee Pharmacy			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
30	BotikaBert			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
39	Dailymed Pharmacy	storefront/banner/52/dailymed.jpg		0.5x0.5	\N	t	52	14	\N	[{"Monday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "7:00 AM"}}]	2	9.982318	122.738636	f
33	Goyerstore			0.5x0.5	\N	t	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
31	BOTIKABERTO	storefront/banner/42/2013-12-02_21.16.33.jpg	storefront/profile/42/Halakhak.jpg	0.5x0.5	\N	t	\N	6	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "12:00 PM", "opening": "10:00 AM"}}]	3	14.557998	121.019628	f
28	MAM DrugStore			0.5x0.5	\N	t	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
35	MytestStores			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
32	BOTICA ni BERTO	storefront/banner/43/how_to_work.jpg	storefront/profile/43/basket-toon-close.JPG	0.5x0.5	\N	t	\N	7	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "3:00 PM", "opening": "10:00 AM"}}]	4	14.552513	121.027032	f
42	Panacan Pharmacy			0.5x0.5	\N	t	55	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
3	OC Healthcare	storefront/banner/9/SF_oc_healthcare_1b_1.jpg	storefront/profile/9/photo-stock_dawn.jpg	0.51x0.5	\N	t	9	3	\N	[{"Monday": {"closing": "6:00 PM", "opening": "11:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	5	14.488043	121.023409	f
41	mims pharmacy			0.5x0.5	\N	t	54	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
2	1925 Pharmacy	storefront/banner/7/banner_GNfgEBb.png	storefront/profile/7/MMM_yMX7j3l.jpg	0.5x0.5	\N	t	7	8	\N	[{"Monday": {"closing": "8:30 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "8:30 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "8:30 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "8:30 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "8:30 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	6	14.585897	121.060052	f
38	Botika Sa Kanto	storefront/banner/51/cafe_02_VykPMIM.jpg	storefront/profile/51/Botika_sa_Kanto_avatar_H1ofyk0.jpg	0.51x0.5	\N	t	\N	10	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "7:00 PM", "opening": "7:00 AM"}}]	4	14.434756	120.994053	f
45	GRX Pharmacy			0.5x0.5	\N	t	58	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
46	FARMACIA JURUENA			0.5x0.5	\N	t	59	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
47	QNM Drugmart			0.5x0.5	\N	t	60	16	\N	[{"Monday": {"closing": "8:00 PM", "opening": "7:00 AM"}}, {"Tuesday": {"closing": "8:00 PM", "opening": "7:00 AM"}}, {"Wednesday": {"closing": "8:00 PM", "opening": "7:00 AM"}}, {"Thursday": {"closing": "8:00 PM", "opening": "7:00 AM"}}, {"Friday": {"closing": "8:00 PM", "opening": "7:00 AM"}}, {"Saturday": {"closing": "8:00 PM", "opening": "7:00 AM"}}, {"Sunday": {"closing": "8:00 PM", "opening": "7:00 AM"}}]	4	14.975941	120.643407	t
48	FARMACIA M			0.5x0.5	\N	t	61	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "6:00 AM"}}]	\N	\N	\N	f
37	BGx Pharmacy	storefront/banner/50/CP.jpg	storefront/profile/50/PP.jpg	0.5x0.5	\N	t	50	11	\N	[{"Monday": {"closing": "7:30 PM", "opening": "7:30 AM"}}, {"Tuesday": {"closing": "7:30 PM", "opening": "7:30 AM"}}, {"Wednesday": {"closing": "7:30 PM", "opening": "7:30 AM"}}, {"Thursday": {"closing": "7:30 PM", "opening": "7:30 AM"}}, {"Friday": {"closing": "7:30 PM", "opening": "7:30 AM"}}, {"Saturday": {"closing": "7:30 PM", "opening": "7:30 AM"}}, {"Sunday": {"closing": "7:30 PM", "opening": "7:30 AM"}}]	2	10.101558	122.869900	t
1	123 Botika Mart Pharmacy	storefront/banner/3/Store_Front_A_SHNIqW2.png	storefront/profile/3/123_BMP.png	0.5x0.5	\N	t	\N	5	\N	[{"Tuesday": {"closing": "3:00 PM", "opening": "10:00 AM"}}, {"Wednesday": {"closing": "3:00 PM", "opening": "10:00 AM"}}, {"Thursday": {"closing": "3:00 PM", "opening": "10:00 AM"}}, {"Friday": {"closing": "3:00 PM", "opening": "10:00 AM"}}, {"Saturday": {"closing": "3:00 PM", "opening": "10:00 AM"}}]	3	14.558054	121.019564	f
50	FARMACIA 4 ALL	storefront/banner/64/flower2.png	storefront/profile/64/banner_logo_4_all.png	0.51x0.5	\N	t	64	17	\N	[{"Monday": {"closing": "6:00 PM", "opening": "7:30 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "7:30 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "7:30 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "7:30 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "7:30 AM"}}, {"Saturday": {"closing": "5:30 PM", "opening": "7:30 AM"}}, {"Sunday": {"closing": "5:30 PM", "opening": "7:30 AM"}}]	4	\N	\N	t
34	Emmaflor Drugstore	storefront/banner/45/emmaflor_logo_vZFr2Io.jpg	storefront/profile/45/logo_1_l3vWMSw.jpg	0.5x0.5	\N	t	45	13	\N	[{"Monday": {"closing": "5:00 PM", "opening": "8:00 AM"}}, {"Tuesday": {"closing": "5:00 PM", "opening": "8:00 AM"}}, {"Wednesday": {"closing": "5:00 PM", "opening": "8:00 AM"}}, {"Thursday": {"closing": "5:00 PM", "opening": "8:00 AM"}}, {"Friday": {"closing": "5:00 PM", "opening": "8:00 AM"}}, {"Saturday": {"closing": "5:00 PM", "opening": "8:00 AM"}}]	5	14.558739	121.046066	f
63	MD Pharmacy			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
67	MAMJR Pharmacy			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
70	drupph testing	storefront/banner/89/bauan_pharm.jpg	storefront/profile/89/bauan_pharm_ava.jpg	0.5x0.5	\N	t	89	30	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	1	13.791102	121.010134	f
29	Newday Pharmacy	storefront/banner/40/banner_2_sY4GtCA.png	storefront/profile/40/1_FXXzh9G.png	0.51x0.5	\N	t	40	9	\N	[{"Monday": {"closing": "5:00 PM", "opening": "7:00 AM"}}, {"Tuesday": {"closing": "5:00 PM", "opening": "7:00 AM"}}, {"Wednesday": {"closing": "5:00 PM", "opening": "7:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "7:00 PM"}}, {"Friday": {"closing": "5:00 PM", "opening": "7:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	7	16.420152	120.597783	f
69	Jacamed Pharmacy Inc	storefront/banner/87/coverpage_copy_uSRMmfK.jpg	storefront/profile/87/profileimage_copy_Be86gfi.jpg	0.51x0.5	\N	t	87	23	\N	[{"Monday": {"closing": "6:00 PM", "opening": "6:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "6:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "6:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "6:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "6:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "6:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "6:00 AM"}}]	4	14.541402	121.059116	f
51	ParSia Pharmacy			0.5x0.5	\N	t	66	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
59	MAD Drugstore			0.5x0.5	\N	t	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
58	San Antonio Pharmacy			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
54	MD Drugstore			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
57	Yvette Farmacia			0.5x0.5	\N	t	72	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
53	test			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
64	MAD Pharmacy			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
56	Amesco Drug Corporation			0.5x0.5	\N	t	71	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
5	CEES Pharmacy	storefront/banner/12/CEES_pharmacy_4.png	storefront/profile/12/IMG_1041.JPG	0.5x0.5	\N	t	12	4	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	4	13.833740	120.631928	f
40	Triple K Pharmacy		storefront/profile/53/102681456_2904184956296979_5669076018305680057_o.jpg	0.5x0.5	\N	t	53	15	\N	[{"Monday": {"closing": "7:00 PM", "opening": "7:00 AM"}}, {"Tuesday": {"closing": "7:00 PM", "opening": "7:00 AM"}}, {"Wednesday": {"closing": "7:00 PM", "opening": "7:00 AM"}}, {"Thursday": {"closing": "7:00 PM", "opening": "7:00 AM"}}, {"Friday": {"closing": "7:00 PM", "opening": "7:00 AM"}}, {"Saturday": {"closing": "7:00 PM", "opening": "7:00 AM"}}, {"Sunday": {"closing": "7:00 PM", "opening": "7:00 AM"}}]	4	10.195377	122.865989	t
44	BUPHARCO Pharmacy			0.5x0.5	\N	t	57	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
55	BUPHARCO Pharmacy Bulua Branch		storefront/profile/70/logo_IzYqVvP.jpg	0.5x0.5	\N	t	70	24	\N	[{"Monday": {"closing": "8:00 PM", "opening": "6:00 AM"}}, {"Tuesday": {"closing": "8:00 PM", "opening": "6:00 AM"}}, {"Wednesday": {"closing": "8:00 PM", "opening": "6:00 AM"}}, {"Thursday": {"closing": "8:00 PM", "opening": "6:00 AM"}}, {"Friday": {"closing": "8:00 PM", "opening": "6:00 AM"}}, {"Saturday": {"closing": "8:00 PM", "opening": "6:00 AM"}}, {"Sunday": {"closing": "8:00 PM", "opening": "6:00 AM"}}]	4	8.504420	124.615034	f
62	HDC Drugstore			0.5x0.5	\N	f	\N	\N	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	\N	\N	\N	f
52	Bauan Pharmacy	storefront/banner/67/bauan_pharm.jpg	storefront/profile/67/bauan_pharm_ava.jpg	0.5x0.5	\N	f	\N	19	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	1	13.795075	121.000241	f
61	LEOVENELLE DRUGSTORE	storefront/banner/76/banner_orig_3C.jpg	storefront/profile/76/bowl_of_hygeia_white_blue_button.png	0.5x0.5	\N	t	76	22	\N	[{"Monday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "7:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "7:00 AM"}}]	2	7.083934	124.898901	t
36	Triple K Pharmacy II		storefront/profile/49/102681456_2904184956296979_5669076018305680057_o.jpg	0.5x0.5	\N	t	49	12	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	2	10.199959	122.866485	t
60	PharmaKo Wellness Online Shop	storefront/banner/75/banner.png	storefront/profile/75/PharmaKo_Wellness_Logo.png	0.5x0.5	\N	t	75	18	\N	[{"Monday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Tuesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Wednesday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Thursday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Friday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Saturday": {"closing": "6:00 PM", "opening": "9:00 AM"}}, {"Sunday": {"closing": "6:00 PM", "opening": "9:00 AM"}}]	5	14.876907	120.233091	f
\.


--
-- Data for Name: storefront_temporaryimage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.storefront_temporaryimage (id, procedure, image, store_id, filename) FROM stdin;
81	0	products/89/temporary/function_uuid4_at_0x7f6feffb2710.png	70	tmp
82	0	products/89/temporary/function_uuid4_at_0x7f6feffb2710.png	70	tmp
83	0	products/89/temporary/function_uuid4_at_0x7f6feffb2710.png	70	tmp
84	0	products/89/temporary/function_uuid4_at_0x7fc584cd6710.png	70	tmp
85	0	products/89/temporary/function_uuid4_at_0x7f6feffb2710.png	70	tmp
86	0	products/89/temporary/function_uuid4_at_0x7f6feffb2710.png	70	tmp
87	0	products/89/temporary/function_uuid4_at_0x7f6feffb2710.png	70	tmp
88	0	products/89/temporary/function_uuid4_at_0x7f6feffb2710.png	70	tmp
\.


--
-- Name: account_customerevent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_customerevent_id_seq', 258, true);


--
-- Name: account_customernote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_customernote_id_seq', 1, false);


--
-- Name: account_userproducts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_userproducts_id_seq', 380, true);


--
-- Name: account_userrequestform_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_userrequestform_id_seq', 89, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 306, true);


--
-- Name: cart_cartline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cart_cartline_id_seq', 23, true);


--
-- Name: checkout_checkout_gift_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.checkout_checkout_gift_cards_id_seq', 1, false);


--
-- Name: discount_sale_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_sale_categories_id_seq', 1, false);


--
-- Name: discount_sale_collections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_sale_collections_id_seq', 1, false);


--
-- Name: discount_sale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_sale_id_seq', 1, false);


--
-- Name: discount_sale_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_sale_products_id_seq', 1, false);


--
-- Name: discount_saletranslation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_saletranslation_id_seq', 1, false);


--
-- Name: discount_voucher_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_voucher_categories_id_seq', 1, false);


--
-- Name: discount_voucher_collections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_voucher_collections_id_seq', 1, false);


--
-- Name: discount_voucher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_voucher_id_seq', 1, false);


--
-- Name: discount_voucher_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_voucher_products_id_seq', 1, false);


--
-- Name: discount_vouchertranslation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_vouchertranslation_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 73, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drupphuser1
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 464, true);


--
-- Name: django_prices_openexchangerates_conversionrate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_prices_openexchangerates_conversionrate_id_seq', 1, false);


--
-- Name: django_prices_vatlayer_ratetypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_prices_vatlayer_ratetypes_id_seq', 1, false);


--
-- Name: django_prices_vatlayer_vat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_prices_vatlayer_vat_id_seq', 1, false);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drupphuser1
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, true);


--
-- Name: giftcard_giftcard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.giftcard_giftcard_id_seq', 1, false);


--
-- Name: impersonate_impersonationlog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.impersonate_impersonationlog_id_seq', 19, true);


--
-- Name: menu_menu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_menu_id_seq', 2, true);


--
-- Name: menu_menuitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_menuitem_id_seq', 1, false);


--
-- Name: menu_menuitemtranslation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_menuitemtranslation_id_seq', 1, false);


--
-- Name: order_fulfillment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_fulfillment_id_seq', 1, true);


--
-- Name: order_fulfillmentline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_fulfillmentline_id_seq', 1, true);


--
-- Name: order_order_gift_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_order_gift_cards_id_seq', 1, false);


--
-- Name: order_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_order_id_seq', 4, true);


--
-- Name: order_ordereditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_ordereditem_id_seq', 5, true);


--
-- Name: order_orderevent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_orderevent_id_seq', 10, true);


--
-- Name: page_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.page_page_id_seq', 1, false);


--
-- Name: page_pagetranslation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.page_pagetranslation_id_seq', 1, false);


--
-- Name: payment_paymentmethod_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_paymentmethod_id_seq', 3, true);


--
-- Name: payment_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_transaction_id_seq', 1, true);


--
-- Name: portal_carousel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.portal_carousel_id_seq', 5, true);


--
-- Name: portal_carousellinks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.portal_carousellinks_id_seq', 1, true);


--
-- Name: product_attributechoicevalue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drupphuser1
--

SELECT pg_catalog.setval('public.product_attributechoicevalue_id_seq', 67, true);


--
-- Name: product_attributechoicevaluetranslation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_attributechoicevaluetranslation_id_seq', 1, false);


--
-- Name: product_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drupphuser1
--

SELECT pg_catalog.setval('public.product_category_id_seq', 206, true);


--
-- Name: product_categorytranslation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_categorytranslation_id_seq', 1, false);


--
-- Name: product_collection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_collection_id_seq', 1, false);


--
-- Name: product_collection_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_collection_products_id_seq', 1, false);


--
-- Name: product_collectiontranslation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_collectiontranslation_id_seq', 1, false);


--
-- Name: product_digitalcontent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_digitalcontent_id_seq', 1, false);


--
-- Name: product_digitalcontenturl_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_digitalcontenturl_id_seq', 1, false);


--
-- Name: product_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drupphuser1
--

SELECT pg_catalog.setval('public.product_product_id_seq', 380, true);


--
-- Name: product_productattribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drupphuser1
--

SELECT pg_catalog.setval('public.product_productattribute_id_seq', 35, true);


--
-- Name: product_productattributetranslation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_productattributetranslation_id_seq', 1, false);


--
-- Name: product_productclass_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drupphuser1
--

SELECT pg_catalog.setval('public.product_productclass_id_seq', 49, true);


--
-- Name: product_productimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drupphuser1
--

SELECT pg_catalog.setval('public.product_productimage_id_seq', 813, true);


--
-- Name: product_producttranslation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_producttranslation_id_seq', 1, false);


--
-- Name: product_productvariant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drupphuser1
--

SELECT pg_catalog.setval('public.product_productvariant_id_seq', 305, true);


--
-- Name: product_productvarianttranslation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_productvarianttranslation_id_seq', 1, false);


--
-- Name: product_variantimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drupphuser1
--

SELECT pg_catalog.setval('public.product_variantimage_id_seq', 1, false);


--
-- Name: shipping_shippingcities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shipping_shippingcities_id_seq', 1, false);


--
-- Name: shipping_shippingmethod_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shipping_shippingmethod_id_seq', 1, false);


--
-- Name: shipping_shippingmethodtranslation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shipping_shippingmethodtranslation_id_seq', 1, false);


--
-- Name: shipping_shippingprovince_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shipping_shippingprovince_id_seq', 1, false);


--
-- Name: shipping_shippingzone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shipping_shippingzone_id_seq', 1, false);


--
-- Name: shipping_usershippingzone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shipping_usershippingzone_id_seq', 1, false);


--
-- Name: site_authorizationkey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drupphuser1
--

SELECT pg_catalog.setval('public.site_authorizationkey_id_seq', 2, true);


--
-- Name: site_sitesettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drupphuser1
--

SELECT pg_catalog.setval('public.site_sitesettings_id_seq', 1, true);


--
-- Name: site_sitesettingstranslation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.site_sitesettingstranslation_id_seq', 1, false);


--
-- Name: social_auth_association_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.social_auth_association_id_seq', 1, false);


--
-- Name: social_auth_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.social_auth_code_id_seq', 1, false);


--
-- Name: social_auth_nonce_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.social_auth_nonce_id_seq', 1, false);


--
-- Name: social_auth_partial_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.social_auth_partial_id_seq', 1, false);


--
-- Name: social_auth_usersocialauth_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.social_auth_usersocialauth_id_seq', 26, true);


--
-- Name: storefront_businessdocument_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.storefront_businessdocument_id_seq', 25, true);


--
-- Name: storefront_colorthemes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.storefront_colorthemes_id_seq', 8, true);


--
-- Name: storefront_store_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.storefront_store_id_seq', 70, true);


--
-- Name: storefront_temporaryimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.storefront_temporaryimage_id_seq', 88, true);


--
-- Name: userprofile_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.userprofile_address_id_seq', 38, true);


--
-- Name: userprofile_user_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.userprofile_user_addresses_id_seq', 8, true);


--
-- Name: userprofile_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.userprofile_user_groups_id_seq', 1, false);


--
-- Name: userprofile_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.userprofile_user_id_seq', 109, true);


--
-- Name: userprofile_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.userprofile_user_user_permissions_id_seq', 64, true);


--
-- Name: account_customerevent account_customerevent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_customerevent
    ADD CONSTRAINT account_customerevent_pkey PRIMARY KEY (id);


--
-- Name: account_customernote account_customernote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_customernote
    ADD CONSTRAINT account_customernote_pkey PRIMARY KEY (id);


--
-- Name: account_user account_user_token_40f69349_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user
    ADD CONSTRAINT account_user_token_40f69349_uniq UNIQUE (token);


--
-- Name: account_userproducts account_userproducts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_userproducts
    ADD CONSTRAINT account_userproducts_pkey PRIMARY KEY (id);


--
-- Name: account_userrequestform account_userrequestform_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_userrequestform
    ADD CONSTRAINT account_userrequestform_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: checkout_checkout cart_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkout
    ADD CONSTRAINT cart_cart_pkey PRIMARY KEY (token);


--
-- Name: checkout_checkoutline cart_cartline_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkoutline
    ADD CONSTRAINT cart_cartline_pkey PRIMARY KEY (id);


--
-- Name: checkout_checkoutline checkout_cartline_cart_id_variant_id_data_new_de3d8fca_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkoutline
    ADD CONSTRAINT checkout_cartline_cart_id_variant_id_data_new_de3d8fca_uniq UNIQUE (checkout_id, variant_id, data);


--
-- Name: checkout_checkout_gift_cards checkout_checkout_gift_c_checkout_id_giftcard_id_401ba79e_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkout_gift_cards
    ADD CONSTRAINT checkout_checkout_gift_c_checkout_id_giftcard_id_401ba79e_uniq UNIQUE (checkout_id, giftcard_id);


--
-- Name: checkout_checkout_gift_cards checkout_checkout_gift_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkout_gift_cards
    ADD CONSTRAINT checkout_checkout_gift_cards_pkey PRIMARY KEY (id);


--
-- Name: discount_sale_categories discount_sale_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_categories
    ADD CONSTRAINT discount_sale_categories_pkey PRIMARY KEY (id);


--
-- Name: discount_sale_categories discount_sale_categories_sale_id_category_id_be438401_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_categories
    ADD CONSTRAINT discount_sale_categories_sale_id_category_id_be438401_uniq UNIQUE (sale_id, category_id);


--
-- Name: discount_sale_collections discount_sale_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_collections
    ADD CONSTRAINT discount_sale_collections_pkey PRIMARY KEY (id);


--
-- Name: discount_sale_collections discount_sale_collections_sale_id_collection_id_01b57fc3_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_collections
    ADD CONSTRAINT discount_sale_collections_sale_id_collection_id_01b57fc3_uniq UNIQUE (sale_id, collection_id);


--
-- Name: discount_sale discount_sale_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale
    ADD CONSTRAINT discount_sale_pkey PRIMARY KEY (id);


--
-- Name: discount_sale_products discount_sale_products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_products
    ADD CONSTRAINT discount_sale_products_pkey PRIMARY KEY (id);


--
-- Name: discount_sale_products discount_sale_products_sale_id_product_id_1c2df1f8_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_products
    ADD CONSTRAINT discount_sale_products_sale_id_product_id_1c2df1f8_uniq UNIQUE (sale_id, product_id);


--
-- Name: discount_saletranslation discount_saletranslation_language_code_sale_id_e956163f_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_saletranslation
    ADD CONSTRAINT discount_saletranslation_language_code_sale_id_e956163f_uniq UNIQUE (language_code, sale_id);


--
-- Name: discount_saletranslation discount_saletranslation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_saletranslation
    ADD CONSTRAINT discount_saletranslation_pkey PRIMARY KEY (id);


--
-- Name: discount_voucher_categories discount_voucher_categor_voucher_id_category_id_bb5f8954_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_categories
    ADD CONSTRAINT discount_voucher_categor_voucher_id_category_id_bb5f8954_uniq UNIQUE (voucher_id, category_id);


--
-- Name: discount_voucher_categories discount_voucher_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_categories
    ADD CONSTRAINT discount_voucher_categories_pkey PRIMARY KEY (id);


--
-- Name: discount_voucher discount_voucher_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher
    ADD CONSTRAINT discount_voucher_code_key UNIQUE (code);


--
-- Name: discount_voucher_collections discount_voucher_collect_voucher_id_collection_id_736b8f24_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_collections
    ADD CONSTRAINT discount_voucher_collect_voucher_id_collection_id_736b8f24_uniq UNIQUE (voucher_id, collection_id);


--
-- Name: discount_voucher_collections discount_voucher_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_collections
    ADD CONSTRAINT discount_voucher_collections_pkey PRIMARY KEY (id);


--
-- Name: discount_voucher discount_voucher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher
    ADD CONSTRAINT discount_voucher_pkey PRIMARY KEY (id);


--
-- Name: discount_voucher_products discount_voucher_products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_products
    ADD CONSTRAINT discount_voucher_products_pkey PRIMARY KEY (id);


--
-- Name: discount_voucher_products discount_voucher_products_voucher_id_product_id_2b092ec4_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_products
    ADD CONSTRAINT discount_voucher_products_voucher_id_product_id_2b092ec4_uniq UNIQUE (voucher_id, product_id);


--
-- Name: discount_vouchertranslation discount_vouchertranslat_language_code_voucher_id_af4428b5_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_vouchertranslation
    ADD CONSTRAINT discount_vouchertranslat_language_code_voucher_id_af4428b5_uniq UNIQUE (language_code, voucher_id);


--
-- Name: discount_vouchertranslation discount_vouchertranslation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_vouchertranslation
    ADD CONSTRAINT discount_vouchertranslation_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_prices_openexchangerates_conversionrate django_prices_openexchangerates_conversionrate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_prices_openexchangerates_conversionrate
    ADD CONSTRAINT django_prices_openexchangerates_conversionrate_pkey PRIMARY KEY (id);


--
-- Name: django_prices_openexchangerates_conversionrate django_prices_openexchangerates_conversionrate_to_currency_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_prices_openexchangerates_conversionrate
    ADD CONSTRAINT django_prices_openexchangerates_conversionrate_to_currency_key UNIQUE (to_currency);


--
-- Name: django_prices_vatlayer_ratetypes django_prices_vatlayer_ratetypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_prices_vatlayer_ratetypes
    ADD CONSTRAINT django_prices_vatlayer_ratetypes_pkey PRIMARY KEY (id);


--
-- Name: django_prices_vatlayer_vat django_prices_vatlayer_vat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_prices_vatlayer_vat
    ADD CONSTRAINT django_prices_vatlayer_vat_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: giftcard_giftcard giftcard_giftcard_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.giftcard_giftcard
    ADD CONSTRAINT giftcard_giftcard_code_key UNIQUE (code);


--
-- Name: giftcard_giftcard giftcard_giftcard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.giftcard_giftcard
    ADD CONSTRAINT giftcard_giftcard_pkey PRIMARY KEY (id);


--
-- Name: impersonate_impersonationlog impersonate_impersonationlog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.impersonate_impersonationlog
    ADD CONSTRAINT impersonate_impersonationlog_pkey PRIMARY KEY (id);


--
-- Name: menu_menu menu_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_menu
    ADD CONSTRAINT menu_menu_pkey PRIMARY KEY (id);


--
-- Name: menu_menuitem menu_menuitem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_menuitem
    ADD CONSTRAINT menu_menuitem_pkey PRIMARY KEY (id);


--
-- Name: menu_menuitemtranslation menu_menuitemtranslation_language_code_menu_item__508dcdd8_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_menuitemtranslation
    ADD CONSTRAINT menu_menuitemtranslation_language_code_menu_item__508dcdd8_uniq UNIQUE (language_code, menu_item_id);


--
-- Name: menu_menuitemtranslation menu_menuitemtranslation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_menuitemtranslation
    ADD CONSTRAINT menu_menuitemtranslation_pkey PRIMARY KEY (id);


--
-- Name: order_fulfillment order_fulfillment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_fulfillment
    ADD CONSTRAINT order_fulfillment_pkey PRIMARY KEY (id);


--
-- Name: order_fulfillmentline order_fulfillmentline_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_fulfillmentline
    ADD CONSTRAINT order_fulfillmentline_pkey PRIMARY KEY (id);


--
-- Name: order_order_gift_cards order_order_gift_cards_order_id_giftcard_id_f58e7356_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_order_gift_cards
    ADD CONSTRAINT order_order_gift_cards_order_id_giftcard_id_f58e7356_uniq UNIQUE (order_id, giftcard_id);


--
-- Name: order_order_gift_cards order_order_gift_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_order_gift_cards
    ADD CONSTRAINT order_order_gift_cards_pkey PRIMARY KEY (id);


--
-- Name: order_order order_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_order
    ADD CONSTRAINT order_order_pkey PRIMARY KEY (id);


--
-- Name: order_order order_order_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_order
    ADD CONSTRAINT order_order_token_key UNIQUE (token);


--
-- Name: order_orderline order_ordereditem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_orderline
    ADD CONSTRAINT order_ordereditem_pkey PRIMARY KEY (id);


--
-- Name: order_orderevent order_orderevent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_orderevent
    ADD CONSTRAINT order_orderevent_pkey PRIMARY KEY (id);


--
-- Name: page_page page_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_page
    ADD CONSTRAINT page_page_pkey PRIMARY KEY (id);


--
-- Name: page_page page_page_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_page
    ADD CONSTRAINT page_page_slug_key UNIQUE (slug);


--
-- Name: page_pagetranslation page_pagetranslation_language_code_page_id_35685962_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_pagetranslation
    ADD CONSTRAINT page_pagetranslation_language_code_page_id_35685962_uniq UNIQUE (language_code, page_id);


--
-- Name: page_pagetranslation page_pagetranslation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_pagetranslation
    ADD CONSTRAINT page_pagetranslation_pkey PRIMARY KEY (id);


--
-- Name: payment_payment payment_paymentmethod_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_payment
    ADD CONSTRAINT payment_paymentmethod_pkey PRIMARY KEY (id);


--
-- Name: payment_transaction payment_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_transaction
    ADD CONSTRAINT payment_transaction_pkey PRIMARY KEY (id);


--
-- Name: portal_carousel portal_carousel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_carousel
    ADD CONSTRAINT portal_carousel_pkey PRIMARY KEY (id);


--
-- Name: portal_carousellinks portal_carousellinks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_carousellinks
    ADD CONSTRAINT portal_carousellinks_pkey PRIMARY KEY (id);


--
-- Name: product_attributevaluetranslation product_attributechoicev_language_code_attribute__9b58af18_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_attributevaluetranslation
    ADD CONSTRAINT product_attributechoicev_language_code_attribute__9b58af18_uniq UNIQUE (language_code, attribute_value_id);


--
-- Name: product_attributevalue product_attributechoicevalue_display_attribute_id_6d8b2d87_uniq; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_attributevalue
    ADD CONSTRAINT product_attributechoicevalue_display_attribute_id_6d8b2d87_uniq UNIQUE (name, attribute_id);


--
-- Name: product_attributevalue product_attributechoicevalue_pkey; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_attributevalue
    ADD CONSTRAINT product_attributechoicevalue_pkey PRIMARY KEY (id);


--
-- Name: product_attributevaluetranslation product_attributechoicevaluetranslation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_attributevaluetranslation
    ADD CONSTRAINT product_attributechoicevaluetranslation_pkey PRIMARY KEY (id);


--
-- Name: product_category product_category_pkey; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_category
    ADD CONSTRAINT product_category_pkey PRIMARY KEY (id);


--
-- Name: product_categorytranslation product_categorytranslat_language_code_category_i_f71fd11d_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categorytranslation
    ADD CONSTRAINT product_categorytranslat_language_code_category_i_f71fd11d_uniq UNIQUE (language_code, category_id);


--
-- Name: product_categorytranslation product_categorytranslation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categorytranslation
    ADD CONSTRAINT product_categorytranslation_pkey PRIMARY KEY (id);


--
-- Name: product_collection product_collection_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_collection
    ADD CONSTRAINT product_collection_name_key UNIQUE (name);


--
-- Name: product_collection product_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_collection
    ADD CONSTRAINT product_collection_pkey PRIMARY KEY (id);


--
-- Name: product_collectionproduct product_collection_products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_collectionproduct
    ADD CONSTRAINT product_collection_products_pkey PRIMARY KEY (id);


--
-- Name: product_collectiontranslation product_collectiontransl_language_code_collection_b1200cd5_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_collectiontranslation
    ADD CONSTRAINT product_collectiontransl_language_code_collection_b1200cd5_uniq UNIQUE (language_code, collection_id);


--
-- Name: product_collectiontranslation product_collectiontranslation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_collectiontranslation
    ADD CONSTRAINT product_collectiontranslation_pkey PRIMARY KEY (id);


--
-- Name: product_digitalcontent product_digitalcontent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_digitalcontent
    ADD CONSTRAINT product_digitalcontent_pkey PRIMARY KEY (id);


--
-- Name: product_digitalcontent product_digitalcontent_product_variant_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_digitalcontent
    ADD CONSTRAINT product_digitalcontent_product_variant_id_key UNIQUE (product_variant_id);


--
-- Name: product_digitalcontenturl product_digitalcontenturl_line_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_digitalcontenturl
    ADD CONSTRAINT product_digitalcontenturl_line_id_key UNIQUE (line_id);


--
-- Name: product_digitalcontenturl product_digitalcontenturl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_digitalcontenturl
    ADD CONSTRAINT product_digitalcontenturl_pkey PRIMARY KEY (id);


--
-- Name: product_digitalcontenturl product_digitalcontenturl_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_digitalcontenturl
    ADD CONSTRAINT product_digitalcontenturl_token_key UNIQUE (token);


--
-- Name: product_product product_product_pkey; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_product
    ADD CONSTRAINT product_product_pkey PRIMARY KEY (id);


--
-- Name: product_attributetranslation product_productattribute_language_code_product_at_58451db2_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_attributetranslation
    ADD CONSTRAINT product_productattribute_language_code_product_at_58451db2_uniq UNIQUE (language_code, attribute_id);


--
-- Name: product_attribute product_productattribute_pkey; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_attribute
    ADD CONSTRAINT product_productattribute_pkey PRIMARY KEY (id);


--
-- Name: product_attributetranslation product_productattributetranslation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_attributetranslation
    ADD CONSTRAINT product_productattributetranslation_pkey PRIMARY KEY (id);


--
-- Name: product_producttype product_productclass_pkey; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_producttype
    ADD CONSTRAINT product_productclass_pkey PRIMARY KEY (id);


--
-- Name: product_productimage product_productimage_pkey; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_productimage
    ADD CONSTRAINT product_productimage_pkey PRIMARY KEY (id);


--
-- Name: product_producttranslation product_producttranslati_language_code_product_id_b06ba774_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_producttranslation
    ADD CONSTRAINT product_producttranslati_language_code_product_id_b06ba774_uniq UNIQUE (language_code, product_id);


--
-- Name: product_producttranslation product_producttranslation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_producttranslation
    ADD CONSTRAINT product_producttranslation_pkey PRIMARY KEY (id);


--
-- Name: product_productvariant product_productvariant_pkey; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_productvariant
    ADD CONSTRAINT product_productvariant_pkey PRIMARY KEY (id);


--
-- Name: product_productvarianttranslation product_productvarianttr_language_code_product_va_cf16d8d0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_productvarianttranslation
    ADD CONSTRAINT product_productvarianttr_language_code_product_va_cf16d8d0_uniq UNIQUE (language_code, product_variant_id);


--
-- Name: product_productvarianttranslation product_productvarianttranslation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_productvarianttranslation
    ADD CONSTRAINT product_productvarianttranslation_pkey PRIMARY KEY (id);


--
-- Name: product_variantimage product_variantimage_pkey; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_variantimage
    ADD CONSTRAINT product_variantimage_pkey PRIMARY KEY (id);


--
-- Name: shipping_shippingcities shipping_shippingcities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingcities
    ADD CONSTRAINT shipping_shippingcities_pkey PRIMARY KEY (id);


--
-- Name: shipping_shippingmethod shipping_shippingmethod_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingmethod
    ADD CONSTRAINT shipping_shippingmethod_pkey PRIMARY KEY (id);


--
-- Name: shipping_shippingmethodtranslation shipping_shippingmethodt_language_code_shipping_m_70e4f786_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingmethodtranslation
    ADD CONSTRAINT shipping_shippingmethodt_language_code_shipping_m_70e4f786_uniq UNIQUE (language_code, shipping_method_id);


--
-- Name: shipping_shippingmethodtranslation shipping_shippingmethodtranslation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingmethodtranslation
    ADD CONSTRAINT shipping_shippingmethodtranslation_pkey PRIMARY KEY (id);


--
-- Name: shipping_shippingprovince shipping_shippingprovince_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingprovince
    ADD CONSTRAINT shipping_shippingprovince_pkey PRIMARY KEY (id);


--
-- Name: shipping_shippingzone shipping_shippingzone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingzone
    ADD CONSTRAINT shipping_shippingzone_pkey PRIMARY KEY (id);


--
-- Name: shipping_usershippingzone shipping_usershippingzone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_usershippingzone
    ADD CONSTRAINT shipping_usershippingzone_pkey PRIMARY KEY (id);


--
-- Name: site_authorizationkey site_authorizationkey_pkey; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.site_authorizationkey
    ADD CONSTRAINT site_authorizationkey_pkey PRIMARY KEY (id);


--
-- Name: site_authorizationkey site_authorizationkey_site_settings_id_name_c5f8d1e6_uniq; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.site_authorizationkey
    ADD CONSTRAINT site_authorizationkey_site_settings_id_name_c5f8d1e6_uniq UNIQUE (site_settings_id, name);


--
-- Name: site_sitesettings site_sitesettings_pkey; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.site_sitesettings
    ADD CONSTRAINT site_sitesettings_pkey PRIMARY KEY (id);


--
-- Name: site_sitesettings site_sitesettings_site_id_key; Type: CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.site_sitesettings
    ADD CONSTRAINT site_sitesettings_site_id_key UNIQUE (site_id);


--
-- Name: site_sitesettingstranslation site_sitesettingstransla_language_code_site_setti_e767d9e7_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_sitesettingstranslation
    ADD CONSTRAINT site_sitesettingstransla_language_code_site_setti_e767d9e7_uniq UNIQUE (language_code, site_settings_id);


--
-- Name: site_sitesettingstranslation site_sitesettingstranslation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_sitesettingstranslation
    ADD CONSTRAINT site_sitesettingstranslation_pkey PRIMARY KEY (id);


--
-- Name: social_auth_association social_auth_association_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_association
    ADD CONSTRAINT social_auth_association_pkey PRIMARY KEY (id);


--
-- Name: social_auth_association social_auth_association_server_url_handle_078befa2_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_association
    ADD CONSTRAINT social_auth_association_server_url_handle_078befa2_uniq UNIQUE (server_url, handle);


--
-- Name: social_auth_code social_auth_code_email_code_801b2d02_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_code
    ADD CONSTRAINT social_auth_code_email_code_801b2d02_uniq UNIQUE (email, code);


--
-- Name: social_auth_code social_auth_code_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_code
    ADD CONSTRAINT social_auth_code_pkey PRIMARY KEY (id);


--
-- Name: social_auth_nonce social_auth_nonce_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_nonce
    ADD CONSTRAINT social_auth_nonce_pkey PRIMARY KEY (id);


--
-- Name: social_auth_nonce social_auth_nonce_server_url_timestamp_salt_f6284463_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_nonce
    ADD CONSTRAINT social_auth_nonce_server_url_timestamp_salt_f6284463_uniq UNIQUE (server_url, "timestamp", salt);


--
-- Name: social_auth_partial social_auth_partial_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_partial
    ADD CONSTRAINT social_auth_partial_pkey PRIMARY KEY (id);


--
-- Name: social_auth_usersocialauth social_auth_usersocialauth_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_usersocialauth
    ADD CONSTRAINT social_auth_usersocialauth_pkey PRIMARY KEY (id);


--
-- Name: social_auth_usersocialauth social_auth_usersocialauth_provider_uid_e6b5e668_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_usersocialauth
    ADD CONSTRAINT social_auth_usersocialauth_provider_uid_e6b5e668_uniq UNIQUE (provider, uid);


--
-- Name: storefront_businessdocument storefront_businessdocument_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_businessdocument
    ADD CONSTRAINT storefront_businessdocument_pkey PRIMARY KEY (id);


--
-- Name: storefront_colorthemes storefront_colorthemes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_colorthemes
    ADD CONSTRAINT storefront_colorthemes_pkey PRIMARY KEY (id);


--
-- Name: storefront_store storefront_store_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_store
    ADD CONSTRAINT storefront_store_pkey PRIMARY KEY (id);


--
-- Name: storefront_store storefront_store_storename_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_store
    ADD CONSTRAINT storefront_store_storename_key UNIQUE (storename);


--
-- Name: storefront_temporaryimage storefront_temporaryimage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_temporaryimage
    ADD CONSTRAINT storefront_temporaryimage_pkey PRIMARY KEY (id);


--
-- Name: account_address userprofile_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_address
    ADD CONSTRAINT userprofile_address_pkey PRIMARY KEY (id);


--
-- Name: account_user_addresses userprofile_user_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_addresses
    ADD CONSTRAINT userprofile_user_addresses_pkey PRIMARY KEY (id);


--
-- Name: account_user_addresses userprofile_user_addresses_user_id_address_id_6cb87bcc_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_addresses
    ADD CONSTRAINT userprofile_user_addresses_user_id_address_id_6cb87bcc_uniq UNIQUE (user_id, address_id);


--
-- Name: account_user userprofile_user_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user
    ADD CONSTRAINT userprofile_user_email_key UNIQUE (email);


--
-- Name: account_user_groups userprofile_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_groups
    ADD CONSTRAINT userprofile_user_groups_pkey PRIMARY KEY (id);


--
-- Name: account_user_groups userprofile_user_groups_user_id_group_id_90ce1781_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_groups
    ADD CONSTRAINT userprofile_user_groups_user_id_group_id_90ce1781_uniq UNIQUE (user_id, group_id);


--
-- Name: account_user userprofile_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user
    ADD CONSTRAINT userprofile_user_pkey PRIMARY KEY (id);


--
-- Name: account_user_user_permissions userprofile_user_user_pe_user_id_permission_id_706d65c8_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_user_permissions
    ADD CONSTRAINT userprofile_user_user_pe_user_id_permission_id_706d65c8_uniq UNIQUE (user_id, permission_id);


--
-- Name: account_user_user_permissions userprofile_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_user_permissions
    ADD CONSTRAINT userprofile_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: account_customerevent_order_id_2d6e2d20; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_customerevent_order_id_2d6e2d20 ON public.account_customerevent USING btree (order_id);


--
-- Name: account_customerevent_user_id_b3d6ec36; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_customerevent_user_id_b3d6ec36 ON public.account_customerevent USING btree (user_id);


--
-- Name: account_customernote_customer_id_ec50cbf6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_customernote_customer_id_ec50cbf6 ON public.account_customernote USING btree (customer_id);


--
-- Name: account_customernote_date_231c3474; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_customernote_date_231c3474 ON public.account_customernote USING btree (date);


--
-- Name: account_customernote_user_id_b10a6c14; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_customernote_user_id_b10a6c14 ON public.account_customernote USING btree (user_id);


--
-- Name: account_userproducts_product_id_13671b4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_userproducts_product_id_13671b4b ON public.account_userproducts USING btree (product_id);


--
-- Name: account_userproducts_user_id_7e0c82f1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_userproducts_user_id_7e0c82f1 ON public.account_userproducts USING btree (user_id);


--
-- Name: account_userrequestform_user_id_58f47e40; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_userrequestform_user_id_58f47e40 ON public.account_userrequestform USING btree (user_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: cart_cart_billing_address_id_9eb62ddd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cart_cart_billing_address_id_9eb62ddd ON public.checkout_checkout USING btree (billing_address_id);


--
-- Name: cart_cart_shipping_address_id_adfddaf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cart_cart_shipping_address_id_adfddaf9 ON public.checkout_checkout USING btree (shipping_address_id);


--
-- Name: cart_cart_shipping_method_id_835c02e0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cart_cart_shipping_method_id_835c02e0 ON public.checkout_checkout USING btree (shipping_method_id);


--
-- Name: cart_cart_user_id_9b4220b9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cart_cart_user_id_9b4220b9 ON public.checkout_checkout USING btree (user_id);


--
-- Name: cart_cartline_cart_id_c7b9981e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cart_cartline_cart_id_c7b9981e ON public.checkout_checkoutline USING btree (checkout_id);


--
-- Name: cart_cartline_product_id_1a54130f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cart_cartline_product_id_1a54130f ON public.checkout_checkoutline USING btree (variant_id);


--
-- Name: checkout_checkout_gift_cards_checkout_id_e314728d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX checkout_checkout_gift_cards_checkout_id_e314728d ON public.checkout_checkout_gift_cards USING btree (checkout_id);


--
-- Name: checkout_checkout_gift_cards_giftcard_id_f5994462; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX checkout_checkout_gift_cards_giftcard_id_f5994462 ON public.checkout_checkout_gift_cards USING btree (giftcard_id);


--
-- Name: discount_sale_categories_category_id_64e132af; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_sale_categories_category_id_64e132af ON public.discount_sale_categories USING btree (category_id);


--
-- Name: discount_sale_categories_sale_id_2aeee4a7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_sale_categories_sale_id_2aeee4a7 ON public.discount_sale_categories USING btree (sale_id);


--
-- Name: discount_sale_collections_collection_id_f66df9d7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_sale_collections_collection_id_f66df9d7 ON public.discount_sale_collections USING btree (collection_id);


--
-- Name: discount_sale_collections_sale_id_a912da4a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_sale_collections_sale_id_a912da4a ON public.discount_sale_collections USING btree (sale_id);


--
-- Name: discount_sale_products_product_id_d42c9636; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_sale_products_product_id_d42c9636 ON public.discount_sale_products USING btree (product_id);


--
-- Name: discount_sale_products_sale_id_10e3a20f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_sale_products_sale_id_10e3a20f ON public.discount_sale_products USING btree (sale_id);


--
-- Name: discount_saletranslation_sale_id_36a69b0a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_saletranslation_sale_id_36a69b0a ON public.discount_saletranslation USING btree (sale_id);


--
-- Name: discount_voucher_categories_category_id_fc9d044a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_voucher_categories_category_id_fc9d044a ON public.discount_voucher_categories USING btree (category_id);


--
-- Name: discount_voucher_categories_voucher_id_19a56338; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_voucher_categories_voucher_id_19a56338 ON public.discount_voucher_categories USING btree (voucher_id);


--
-- Name: discount_voucher_code_ff8dc52c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_voucher_code_ff8dc52c_like ON public.discount_voucher USING btree (code varchar_pattern_ops);


--
-- Name: discount_voucher_collections_collection_id_b9de6b54; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_voucher_collections_collection_id_b9de6b54 ON public.discount_voucher_collections USING btree (collection_id);


--
-- Name: discount_voucher_collections_voucher_id_4ce1fde3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_voucher_collections_voucher_id_4ce1fde3 ON public.discount_voucher_collections USING btree (voucher_id);


--
-- Name: discount_voucher_products_product_id_4a3131ff; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_voucher_products_product_id_4a3131ff ON public.discount_voucher_products USING btree (product_id);


--
-- Name: discount_voucher_products_voucher_id_8a2e6c3a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_voucher_products_voucher_id_8a2e6c3a ON public.discount_voucher_products USING btree (voucher_id);


--
-- Name: discount_vouchertranslation_voucher_id_288246a9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discount_vouchertranslation_voucher_id_288246a9 ON public.discount_vouchertranslation USING btree (voucher_id);


--
-- Name: django_prices_openexchan_to_currency_92c4a4e1_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_prices_openexchan_to_currency_92c4a4e1_like ON public.django_prices_openexchangerates_conversionrate USING btree (to_currency varchar_pattern_ops);


--
-- Name: django_prices_vatlayer_vat_country_code_858b2cc4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_prices_vatlayer_vat_country_code_858b2cc4 ON public.django_prices_vatlayer_vat USING btree (country_code);


--
-- Name: django_prices_vatlayer_vat_country_code_858b2cc4_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_prices_vatlayer_vat_country_code_858b2cc4_like ON public.django_prices_vatlayer_vat USING btree (country_code varchar_pattern_ops);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: giftcard_giftcard_code_f6fb6be8_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX giftcard_giftcard_code_f6fb6be8_like ON public.giftcard_giftcard USING btree (code varchar_pattern_ops);


--
-- Name: giftcard_giftcard_user_id_ce2401b5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX giftcard_giftcard_user_id_ce2401b5 ON public.giftcard_giftcard USING btree (user_id);


--
-- Name: impersonate_impersonationlog_impersonating_id_afd114fc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX impersonate_impersonationlog_impersonating_id_afd114fc ON public.impersonate_impersonationlog USING btree (impersonating_id);


--
-- Name: impersonate_impersonationlog_impersonator_id_1ecfe8ce; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX impersonate_impersonationlog_impersonator_id_1ecfe8ce ON public.impersonate_impersonationlog USING btree (impersonator_id);


--
-- Name: menu_menuitem_category_id_af353a3b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_menuitem_category_id_af353a3b ON public.menu_menuitem USING btree (category_id);


--
-- Name: menu_menuitem_collection_id_b913b19e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_menuitem_collection_id_b913b19e ON public.menu_menuitem USING btree (collection_id);


--
-- Name: menu_menuitem_menu_id_f466b139; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_menuitem_menu_id_f466b139 ON public.menu_menuitem USING btree (menu_id);


--
-- Name: menu_menuitem_page_id_a0c8f92d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_menuitem_page_id_a0c8f92d ON public.menu_menuitem USING btree (page_id);


--
-- Name: menu_menuitem_parent_id_439f55a5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_menuitem_parent_id_439f55a5 ON public.menu_menuitem USING btree (parent_id);


--
-- Name: menu_menuitem_sort_order_f96ed184; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_menuitem_sort_order_f96ed184 ON public.menu_menuitem USING btree (sort_order);


--
-- Name: menu_menuitem_tree_id_0d2e9c9a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_menuitem_tree_id_0d2e9c9a ON public.menu_menuitem USING btree (tree_id);


--
-- Name: menu_menuitemtranslation_menu_item_id_3445926c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_menuitemtranslation_menu_item_id_3445926c ON public.menu_menuitemtranslation USING btree (menu_item_id);


--
-- Name: order_fulfillment_order_id_02695111; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_fulfillment_order_id_02695111 ON public.order_fulfillment USING btree (order_id);


--
-- Name: order_fulfillmentline_fulfillment_id_68f3291d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_fulfillmentline_fulfillment_id_68f3291d ON public.order_fulfillmentline USING btree (fulfillment_id);


--
-- Name: order_fulfillmentline_order_line_id_7d40e054; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_fulfillmentline_order_line_id_7d40e054 ON public.order_fulfillmentline USING btree (order_line_id);


--
-- Name: order_order_billing_address_id_8fe537cf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_order_billing_address_id_8fe537cf ON public.order_order USING btree (billing_address_id);


--
-- Name: order_order_gift_cards_giftcard_id_f6844926; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_order_gift_cards_giftcard_id_f6844926 ON public.order_order_gift_cards USING btree (giftcard_id);


--
-- Name: order_order_gift_cards_order_id_ce5608c4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_order_gift_cards_order_id_ce5608c4 ON public.order_order_gift_cards USING btree (order_id);


--
-- Name: order_order_shipping_address_id_57e64931; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_order_shipping_address_id_57e64931 ON public.order_order USING btree (shipping_address_id);


--
-- Name: order_order_shipping_method_id_2a742834; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_order_shipping_method_id_2a742834 ON public.order_order USING btree (shipping_method_id);


--
-- Name: order_order_token_ddb7fb7b_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_order_token_ddb7fb7b_like ON public.order_order USING btree (token varchar_pattern_ops);


--
-- Name: order_order_user_id_7cf9bc2b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_order_user_id_7cf9bc2b ON public.order_order USING btree (user_id);


--
-- Name: order_order_voucher_id_0748ca22; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_order_voucher_id_0748ca22 ON public.order_order USING btree (voucher_id);


--
-- Name: order_orderevent_order_id_09aa7ccd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_orderevent_order_id_09aa7ccd ON public.order_orderevent USING btree (order_id);


--
-- Name: order_orderevent_user_id_1056ac9c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_orderevent_user_id_1056ac9c ON public.order_orderevent USING btree (user_id);


--
-- Name: order_orderline_order_id_eb04ec2d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_orderline_order_id_eb04ec2d ON public.order_orderline USING btree (order_id);


--
-- Name: order_orderline_variant_id_866774cb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_orderline_variant_id_866774cb ON public.order_orderline USING btree (variant_id);


--
-- Name: page_page_slug_d6b7c8ed_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX page_page_slug_d6b7c8ed_like ON public.page_page USING btree (slug varchar_pattern_ops);


--
-- Name: page_pagetranslation_page_id_60216ef5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX page_pagetranslation_page_id_60216ef5 ON public.page_pagetranslation USING btree (page_id);


--
-- Name: payment_paymentmethod_checkout_id_5c0aae3d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payment_paymentmethod_checkout_id_5c0aae3d ON public.payment_payment USING btree (checkout_id);


--
-- Name: payment_paymentmethod_order_id_58acb979; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payment_paymentmethod_order_id_58acb979 ON public.payment_payment USING btree (order_id);


--
-- Name: payment_transaction_payment_method_id_d35e75c1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payment_transaction_payment_method_id_d35e75c1 ON public.payment_transaction USING btree (payment_id);


--
-- Name: portal_carousellinks_carousel_id_85c22df1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX portal_carousellinks_carousel_id_85c22df1 ON public.portal_carousellinks USING btree (carousel_id);


--
-- Name: product_attribute_product_type_id_95b8020e; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_attribute_product_type_id_95b8020e ON public.product_attribute USING btree (product_type_id);


--
-- Name: product_attribute_product_variant_type_id_504d9ada; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_attribute_product_variant_type_id_504d9ada ON public.product_attribute USING btree (product_variant_type_id);


--
-- Name: product_attribute_slug_a2ba35f2; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_attribute_slug_a2ba35f2 ON public.product_attribute USING btree (slug);


--
-- Name: product_attributechoiceval_attribute_choice_value_id_71c4c0a7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_attributechoiceval_attribute_choice_value_id_71c4c0a7 ON public.product_attributevaluetranslation USING btree (attribute_value_id);


--
-- Name: product_attributechoicevalue_attribute_id_c28c6c92; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_attributechoicevalue_attribute_id_c28c6c92 ON public.product_attributevalue USING btree (attribute_id);


--
-- Name: product_attributechoicevalue_slug_e0d2d25b; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_attributechoicevalue_slug_e0d2d25b ON public.product_attributevalue USING btree (slug);


--
-- Name: product_attributechoicevalue_slug_e0d2d25b_like; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_attributechoicevalue_slug_e0d2d25b_like ON public.product_attributevalue USING btree (slug varchar_pattern_ops);


--
-- Name: product_attributechoicevalue_sort_order_c4c071c4; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_attributechoicevalue_sort_order_c4c071c4 ON public.product_attributevalue USING btree (sort_order);


--
-- Name: product_category_parent_id_f6860923; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_category_parent_id_f6860923 ON public.product_category USING btree (parent_id);


--
-- Name: product_category_slug_e1f8ccc4; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_category_slug_e1f8ccc4 ON public.product_category USING btree (slug);


--
-- Name: product_category_slug_e1f8ccc4_like; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_category_slug_e1f8ccc4_like ON public.product_category USING btree (slug varchar_pattern_ops);


--
-- Name: product_category_tree_id_f3c46461; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_category_tree_id_f3c46461 ON public.product_category USING btree (tree_id);


--
-- Name: product_categorytranslation_category_id_aa8d0917; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_categorytranslation_category_id_aa8d0917 ON public.product_categorytranslation USING btree (category_id);


--
-- Name: product_collection_name_03bb818b_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_collection_name_03bb818b_like ON public.product_collection USING btree (name varchar_pattern_ops);


--
-- Name: product_collection_products_collection_id_0bc817dc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_collection_products_collection_id_0bc817dc ON public.product_collectionproduct USING btree (collection_id);


--
-- Name: product_collection_products_product_id_a45a5b06; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_collection_products_product_id_a45a5b06 ON public.product_collectionproduct USING btree (product_id);


--
-- Name: product_collection_slug_ec186116; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_collection_slug_ec186116 ON public.product_collection USING btree (slug);


--
-- Name: product_collection_slug_ec186116_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_collection_slug_ec186116_like ON public.product_collection USING btree (slug varchar_pattern_ops);


--
-- Name: product_collectionproduct_sort_order_5e7b55bb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_collectionproduct_sort_order_5e7b55bb ON public.product_collectionproduct USING btree (sort_order);


--
-- Name: product_collectiontranslation_collection_id_cfbbd453; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_collectiontranslation_collection_id_cfbbd453 ON public.product_collectiontranslation USING btree (collection_id);


--
-- Name: product_digitalcontenturl_content_id_654197bd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_digitalcontenturl_content_id_654197bd ON public.product_digitalcontenturl USING btree (content_id);


--
-- Name: product_product_category_id_0c725779; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_product_category_id_0c725779 ON public.product_product USING btree (category_id);


--
-- Name: product_product_product_class_id_0547c998; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_product_product_class_id_0547c998 ON public.product_product USING btree (product_type_id);


--
-- Name: product_productattribute_name_97ca2b51_like; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_productattribute_name_97ca2b51_like ON public.product_attribute USING btree (slug varchar_pattern_ops);


--
-- Name: product_productattributetr_product_attribute_id_56b48511; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_productattributetr_product_attribute_id_56b48511 ON public.product_attributetranslation USING btree (attribute_id);


--
-- Name: product_productimage_product_id_544084bb; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_productimage_product_id_544084bb ON public.product_productimage USING btree (product_id);


--
-- Name: product_productimage_sort_order_dfda9c19; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_productimage_sort_order_dfda9c19 ON public.product_productimage USING btree (sort_order);


--
-- Name: product_producttranslation_product_id_2c2c7532; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_producttranslation_product_id_2c2c7532 ON public.product_producttranslation USING btree (product_id);


--
-- Name: product_producttype_user_id_62a5700c; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_producttype_user_id_62a5700c ON public.product_producttype USING btree (user_id);


--
-- Name: product_productvariant_product_id_43c5a310; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_productvariant_product_id_43c5a310 ON public.product_productvariant USING btree (product_id);


--
-- Name: product_productvarianttranslation_product_variant_id_1b144a85; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_productvarianttranslation_product_variant_id_1b144a85 ON public.product_productvarianttranslation USING btree (product_variant_id);


--
-- Name: product_variantimage_image_id_bef14106; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_variantimage_image_id_bef14106 ON public.product_variantimage USING btree (image_id);


--
-- Name: product_variantimage_variant_id_81123814; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX product_variantimage_variant_id_81123814 ON public.product_variantimage USING btree (variant_id);


--
-- Name: shipping_shippingcities_shipping_province_id_cae4ce8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shipping_shippingcities_shipping_province_id_cae4ce8b ON public.shipping_shippingcities USING btree (shipping_province_id);


--
-- Name: shipping_shippingmethod_shipping_zone_id_265b7413; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shipping_shippingmethod_shipping_zone_id_265b7413 ON public.shipping_shippingmethod USING btree (shipping_zone_id);


--
-- Name: shipping_shippingmethodtranslation_shipping_method_id_31d925d2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shipping_shippingmethodtranslation_shipping_method_id_31d925d2 ON public.shipping_shippingmethodtranslation USING btree (shipping_method_id);


--
-- Name: shipping_shippingprovince_shipping_zone_id_2c2f5906; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shipping_shippingprovince_shipping_zone_id_2c2f5906 ON public.shipping_shippingprovince USING btree (shipping_zone_id);


--
-- Name: shipping_usershippingzone_shipping_zone_id_1cc4af82; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shipping_usershippingzone_shipping_zone_id_1cc4af82 ON public.shipping_usershippingzone USING btree (shipping_zone_id);


--
-- Name: shipping_usershippingzone_user_id_d93e5699; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shipping_usershippingzone_user_id_d93e5699 ON public.shipping_usershippingzone USING btree (user_id);


--
-- Name: site_authorizationkey_site_settings_id_d8397c0f; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX site_authorizationkey_site_settings_id_d8397c0f ON public.site_authorizationkey USING btree (site_settings_id);


--
-- Name: site_sitesettings_bottom_menu_id_e2a78098; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX site_sitesettings_bottom_menu_id_e2a78098 ON public.site_sitesettings USING btree (bottom_menu_id);


--
-- Name: site_sitesettings_company_address_id_f0825427; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX site_sitesettings_company_address_id_f0825427 ON public.site_sitesettings USING btree (company_address_id);


--
-- Name: site_sitesettings_homepage_collection_id_82f45d33; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX site_sitesettings_homepage_collection_id_82f45d33 ON public.site_sitesettings USING btree (homepage_collection_id);


--
-- Name: site_sitesettings_top_menu_id_ab6f8c46; Type: INDEX; Schema: public; Owner: drupphuser1
--

CREATE INDEX site_sitesettings_top_menu_id_ab6f8c46 ON public.site_sitesettings USING btree (top_menu_id);


--
-- Name: site_sitesettingstranslation_site_settings_id_ca085ff6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX site_sitesettingstranslation_site_settings_id_ca085ff6 ON public.site_sitesettingstranslation USING btree (site_settings_id);


--
-- Name: social_auth_code_code_a2393167; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX social_auth_code_code_a2393167 ON public.social_auth_code USING btree (code);


--
-- Name: social_auth_code_code_a2393167_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX social_auth_code_code_a2393167_like ON public.social_auth_code USING btree (code varchar_pattern_ops);


--
-- Name: social_auth_code_timestamp_176b341f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX social_auth_code_timestamp_176b341f ON public.social_auth_code USING btree ("timestamp");


--
-- Name: social_auth_partial_timestamp_50f2119f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX social_auth_partial_timestamp_50f2119f ON public.social_auth_partial USING btree ("timestamp");


--
-- Name: social_auth_partial_token_3017fea3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX social_auth_partial_token_3017fea3 ON public.social_auth_partial USING btree (token);


--
-- Name: social_auth_partial_token_3017fea3_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX social_auth_partial_token_3017fea3_like ON public.social_auth_partial USING btree (token varchar_pattern_ops);


--
-- Name: social_auth_usersocialauth_user_id_17d28448; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX social_auth_usersocialauth_user_id_17d28448 ON public.social_auth_usersocialauth USING btree (user_id);


--
-- Name: storefront_businessdocument_store_id_1c2acb77; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX storefront_businessdocument_store_id_1c2acb77 ON public.storefront_businessdocument USING btree (store_id);


--
-- Name: storefront_store_color_themes_id_4d637a45; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX storefront_store_color_themes_id_4d637a45 ON public.storefront_store USING btree (color_themes_id);


--
-- Name: storefront_store_owner_id_3ebd3879; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX storefront_store_owner_id_3ebd3879 ON public.storefront_store USING btree (owner_id);


--
-- Name: storefront_store_storeaddress_id_7d16fbaf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX storefront_store_storeaddress_id_7d16fbaf ON public.storefront_store USING btree (storeaddress_id);


--
-- Name: storefront_store_storename_b3a69a43_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX storefront_store_storename_b3a69a43_like ON public.storefront_store USING btree (storename varchar_pattern_ops);


--
-- Name: storefront_temporaryimage_store_id_1a80ba33; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX storefront_temporaryimage_store_id_1a80ba33 ON public.storefront_temporaryimage USING btree (store_id);


--
-- Name: userprofile_user_addresses_address_id_ad7646b4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX userprofile_user_addresses_address_id_ad7646b4 ON public.account_user_addresses USING btree (address_id);


--
-- Name: userprofile_user_addresses_user_id_bb5aa55e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX userprofile_user_addresses_user_id_bb5aa55e ON public.account_user_addresses USING btree (user_id);


--
-- Name: userprofile_user_default_billing_address_id_0489abf1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX userprofile_user_default_billing_address_id_0489abf1 ON public.account_user USING btree (default_billing_address_id);


--
-- Name: userprofile_user_default_shipping_address_id_aae7a203; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX userprofile_user_default_shipping_address_id_aae7a203 ON public.account_user USING btree (default_shipping_address_id);


--
-- Name: userprofile_user_email_b0fb0137_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX userprofile_user_email_b0fb0137_like ON public.account_user USING btree (email varchar_pattern_ops);


--
-- Name: userprofile_user_groups_group_id_c7eec74e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX userprofile_user_groups_group_id_c7eec74e ON public.account_user_groups USING btree (group_id);


--
-- Name: userprofile_user_groups_user_id_5e712a24; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX userprofile_user_groups_user_id_5e712a24 ON public.account_user_groups USING btree (user_id);


--
-- Name: userprofile_user_user_permissions_permission_id_1caa8a71; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX userprofile_user_user_permissions_permission_id_1caa8a71 ON public.account_user_user_permissions USING btree (permission_id);


--
-- Name: userprofile_user_user_permissions_user_id_6d654469; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX userprofile_user_user_permissions_user_id_6d654469 ON public.account_user_user_permissions USING btree (user_id);


--
-- Name: account_customerevent account_customerevent_order_id_2d6e2d20_fk_order_order_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_customerevent
    ADD CONSTRAINT account_customerevent_order_id_2d6e2d20_fk_order_order_id FOREIGN KEY (order_id) REFERENCES public.order_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_customerevent account_customerevent_user_id_b3d6ec36_fk_account_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_customerevent
    ADD CONSTRAINT account_customerevent_user_id_b3d6ec36_fk_account_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_customernote account_customernote_customer_id_ec50cbf6_fk_account_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_customernote
    ADD CONSTRAINT account_customernote_customer_id_ec50cbf6_fk_account_user_id FOREIGN KEY (customer_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_customernote account_customernote_user_id_b10a6c14_fk_account_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_customernote
    ADD CONSTRAINT account_customernote_user_id_b10a6c14_fk_account_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user_addresses account_user_address_address_id_d218822a_fk_account_a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_addresses
    ADD CONSTRAINT account_user_address_address_id_d218822a_fk_account_a FOREIGN KEY (address_id) REFERENCES public.account_address(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user_addresses account_user_addresses_user_id_2fcc8301_fk_account_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_addresses
    ADD CONSTRAINT account_user_addresses_user_id_2fcc8301_fk_account_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_userproducts account_userproducts_product_id_13671b4b_fk_product_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_userproducts
    ADD CONSTRAINT account_userproducts_product_id_13671b4b_fk_product_product_id FOREIGN KEY (product_id) REFERENCES public.product_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_userproducts account_userproducts_user_id_7e0c82f1_fk_account_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_userproducts
    ADD CONSTRAINT account_userproducts_user_id_7e0c82f1_fk_account_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_userrequestform account_userrequestform_user_id_58f47e40_fk_account_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_userrequestform
    ADD CONSTRAINT account_userrequestform_user_id_58f47e40_fk_account_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_account_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_account_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkout cart_cart_billing_address_id_9eb62ddd_fk_account_address_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkout
    ADD CONSTRAINT cart_cart_billing_address_id_9eb62ddd_fk_account_address_id FOREIGN KEY (billing_address_id) REFERENCES public.account_address(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkout cart_cart_shipping_address_id_adfddaf9_fk_account_address_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkout
    ADD CONSTRAINT cart_cart_shipping_address_id_adfddaf9_fk_account_address_id FOREIGN KEY (shipping_address_id) REFERENCES public.account_address(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkoutline cart_cartline_variant_id_dbca56c9_fk_product_productvariant_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkoutline
    ADD CONSTRAINT cart_cartline_variant_id_dbca56c9_fk_product_productvariant_id FOREIGN KEY (variant_id) REFERENCES public.product_productvariant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkoutline checkout_cartline_checkout_id_41d95a5d_fk_checkout_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkoutline
    ADD CONSTRAINT checkout_cartline_checkout_id_41d95a5d_fk_checkout_ FOREIGN KEY (checkout_id) REFERENCES public.checkout_checkout(token) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkout_gift_cards checkout_checkout_gi_checkout_id_e314728d_fk_checkout_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkout_gift_cards
    ADD CONSTRAINT checkout_checkout_gi_checkout_id_e314728d_fk_checkout_ FOREIGN KEY (checkout_id) REFERENCES public.checkout_checkout(token) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkout_gift_cards checkout_checkout_gi_giftcard_id_f5994462_fk_giftcard_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkout_gift_cards
    ADD CONSTRAINT checkout_checkout_gi_giftcard_id_f5994462_fk_giftcard_ FOREIGN KEY (giftcard_id) REFERENCES public.giftcard_giftcard(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkout checkout_checkout_shipping_method_id_8796abd0_fk_shipping_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkout
    ADD CONSTRAINT checkout_checkout_shipping_method_id_8796abd0_fk_shipping_ FOREIGN KEY (shipping_method_id) REFERENCES public.shipping_shippingmethod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkout checkout_checkout_user_id_8b2fe298_fk_account_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkout_checkout
    ADD CONSTRAINT checkout_checkout_user_id_8b2fe298_fk_account_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_sale_categories discount_sale_catego_category_id_64e132af_fk_product_c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_categories
    ADD CONSTRAINT discount_sale_catego_category_id_64e132af_fk_product_c FOREIGN KEY (category_id) REFERENCES public.product_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_sale_categories discount_sale_categories_sale_id_2aeee4a7_fk_discount_sale_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_categories
    ADD CONSTRAINT discount_sale_categories_sale_id_2aeee4a7_fk_discount_sale_id FOREIGN KEY (sale_id) REFERENCES public.discount_sale(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_sale_collections discount_sale_collec_collection_id_f66df9d7_fk_product_c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_collections
    ADD CONSTRAINT discount_sale_collec_collection_id_f66df9d7_fk_product_c FOREIGN KEY (collection_id) REFERENCES public.product_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_sale_collections discount_sale_collections_sale_id_a912da4a_fk_discount_sale_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_collections
    ADD CONSTRAINT discount_sale_collections_sale_id_a912da4a_fk_discount_sale_id FOREIGN KEY (sale_id) REFERENCES public.discount_sale(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_sale_products discount_sale_produc_product_id_d42c9636_fk_product_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_products
    ADD CONSTRAINT discount_sale_produc_product_id_d42c9636_fk_product_p FOREIGN KEY (product_id) REFERENCES public.product_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_sale_products discount_sale_products_sale_id_10e3a20f_fk_discount_sale_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_sale_products
    ADD CONSTRAINT discount_sale_products_sale_id_10e3a20f_fk_discount_sale_id FOREIGN KEY (sale_id) REFERENCES public.discount_sale(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_saletranslation discount_saletranslation_sale_id_36a69b0a_fk_discount_sale_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_saletranslation
    ADD CONSTRAINT discount_saletranslation_sale_id_36a69b0a_fk_discount_sale_id FOREIGN KEY (sale_id) REFERENCES public.discount_sale(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_voucher_categories discount_voucher_cat_category_id_fc9d044a_fk_product_c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_categories
    ADD CONSTRAINT discount_voucher_cat_category_id_fc9d044a_fk_product_c FOREIGN KEY (category_id) REFERENCES public.product_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_voucher_categories discount_voucher_cat_voucher_id_19a56338_fk_discount_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_categories
    ADD CONSTRAINT discount_voucher_cat_voucher_id_19a56338_fk_discount_ FOREIGN KEY (voucher_id) REFERENCES public.discount_voucher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_voucher_collections discount_voucher_col_collection_id_b9de6b54_fk_product_c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_collections
    ADD CONSTRAINT discount_voucher_col_collection_id_b9de6b54_fk_product_c FOREIGN KEY (collection_id) REFERENCES public.product_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_voucher_collections discount_voucher_col_voucher_id_4ce1fde3_fk_discount_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_collections
    ADD CONSTRAINT discount_voucher_col_voucher_id_4ce1fde3_fk_discount_ FOREIGN KEY (voucher_id) REFERENCES public.discount_voucher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_voucher_products discount_voucher_pro_product_id_4a3131ff_fk_product_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_products
    ADD CONSTRAINT discount_voucher_pro_product_id_4a3131ff_fk_product_p FOREIGN KEY (product_id) REFERENCES public.product_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_voucher_products discount_voucher_pro_voucher_id_8a2e6c3a_fk_discount_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_voucher_products
    ADD CONSTRAINT discount_voucher_pro_voucher_id_8a2e6c3a_fk_discount_ FOREIGN KEY (voucher_id) REFERENCES public.discount_voucher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_vouchertranslation discount_vouchertran_voucher_id_288246a9_fk_discount_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_vouchertranslation
    ADD CONSTRAINT discount_vouchertran_voucher_id_288246a9_fk_discount_ FOREIGN KEY (voucher_id) REFERENCES public.discount_voucher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: giftcard_giftcard giftcard_giftcard_user_id_ce2401b5_fk_account_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.giftcard_giftcard
    ADD CONSTRAINT giftcard_giftcard_user_id_ce2401b5_fk_account_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: impersonate_impersonationlog impersonate_imperson_impersonating_id_afd114fc_fk_account_u; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.impersonate_impersonationlog
    ADD CONSTRAINT impersonate_imperson_impersonating_id_afd114fc_fk_account_u FOREIGN KEY (impersonating_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: impersonate_impersonationlog impersonate_imperson_impersonator_id_1ecfe8ce_fk_account_u; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.impersonate_impersonationlog
    ADD CONSTRAINT impersonate_imperson_impersonator_id_1ecfe8ce_fk_account_u FOREIGN KEY (impersonator_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: menu_menuitem menu_menuitem_category_id_af353a3b_fk_product_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_menuitem
    ADD CONSTRAINT menu_menuitem_category_id_af353a3b_fk_product_category_id FOREIGN KEY (category_id) REFERENCES public.product_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: menu_menuitem menu_menuitem_collection_id_b913b19e_fk_product_collection_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_menuitem
    ADD CONSTRAINT menu_menuitem_collection_id_b913b19e_fk_product_collection_id FOREIGN KEY (collection_id) REFERENCES public.product_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: menu_menuitem menu_menuitem_menu_id_f466b139_fk_menu_menu_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_menuitem
    ADD CONSTRAINT menu_menuitem_menu_id_f466b139_fk_menu_menu_id FOREIGN KEY (menu_id) REFERENCES public.menu_menu(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: menu_menuitem menu_menuitem_page_id_a0c8f92d_fk_page_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_menuitem
    ADD CONSTRAINT menu_menuitem_page_id_a0c8f92d_fk_page_page_id FOREIGN KEY (page_id) REFERENCES public.page_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: menu_menuitem menu_menuitem_parent_id_439f55a5_fk_menu_menuitem_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_menuitem
    ADD CONSTRAINT menu_menuitem_parent_id_439f55a5_fk_menu_menuitem_id FOREIGN KEY (parent_id) REFERENCES public.menu_menuitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: menu_menuitemtranslation menu_menuitemtransla_menu_item_id_3445926c_fk_menu_menu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_menuitemtranslation
    ADD CONSTRAINT menu_menuitemtransla_menu_item_id_3445926c_fk_menu_menu FOREIGN KEY (menu_item_id) REFERENCES public.menu_menuitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_fulfillment order_fulfillment_order_id_02695111_fk_order_order_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_fulfillment
    ADD CONSTRAINT order_fulfillment_order_id_02695111_fk_order_order_id FOREIGN KEY (order_id) REFERENCES public.order_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_fulfillmentline order_fulfillmentlin_fulfillment_id_68f3291d_fk_order_ful; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_fulfillmentline
    ADD CONSTRAINT order_fulfillmentlin_fulfillment_id_68f3291d_fk_order_ful FOREIGN KEY (fulfillment_id) REFERENCES public.order_fulfillment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_fulfillmentline order_fulfillmentlin_order_line_id_7d40e054_fk_order_ord; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_fulfillmentline
    ADD CONSTRAINT order_fulfillmentlin_order_line_id_7d40e054_fk_order_ord FOREIGN KEY (order_line_id) REFERENCES public.order_orderline(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order order_order_billing_address_id_8fe537cf_fk_userprofi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_order
    ADD CONSTRAINT order_order_billing_address_id_8fe537cf_fk_userprofi FOREIGN KEY (billing_address_id) REFERENCES public.account_address(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order_gift_cards order_order_gift_car_giftcard_id_f6844926_fk_giftcard_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_order_gift_cards
    ADD CONSTRAINT order_order_gift_car_giftcard_id_f6844926_fk_giftcard_ FOREIGN KEY (giftcard_id) REFERENCES public.giftcard_giftcard(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order_gift_cards order_order_gift_cards_order_id_ce5608c4_fk_order_order_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_order_gift_cards
    ADD CONSTRAINT order_order_gift_cards_order_id_ce5608c4_fk_order_order_id FOREIGN KEY (order_id) REFERENCES public.order_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order order_order_shipping_address_id_57e64931_fk_userprofi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_order
    ADD CONSTRAINT order_order_shipping_address_id_57e64931_fk_userprofi FOREIGN KEY (shipping_address_id) REFERENCES public.account_address(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order order_order_shipping_method_id_2a742834_fk_shipping_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_order
    ADD CONSTRAINT order_order_shipping_method_id_2a742834_fk_shipping_ FOREIGN KEY (shipping_method_id) REFERENCES public.shipping_shippingmethod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order order_order_user_id_7cf9bc2b_fk_userprofile_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_order
    ADD CONSTRAINT order_order_user_id_7cf9bc2b_fk_userprofile_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order order_order_voucher_id_0748ca22_fk_discount_voucher_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_order
    ADD CONSTRAINT order_order_voucher_id_0748ca22_fk_discount_voucher_id FOREIGN KEY (voucher_id) REFERENCES public.discount_voucher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_orderevent order_orderevent_order_id_09aa7ccd_fk_order_order_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_orderevent
    ADD CONSTRAINT order_orderevent_order_id_09aa7ccd_fk_order_order_id FOREIGN KEY (order_id) REFERENCES public.order_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_orderevent order_orderevent_user_id_1056ac9c_fk_userprofile_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_orderevent
    ADD CONSTRAINT order_orderevent_user_id_1056ac9c_fk_userprofile_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_orderline order_orderline_order_id_eb04ec2d_fk_order_order_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_orderline
    ADD CONSTRAINT order_orderline_order_id_eb04ec2d_fk_order_order_id FOREIGN KEY (order_id) REFERENCES public.order_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_orderline order_orderline_variant_id_866774cb_fk_product_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_orderline
    ADD CONSTRAINT order_orderline_variant_id_866774cb_fk_product_p FOREIGN KEY (variant_id) REFERENCES public.product_productvariant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_pagetranslation page_pagetranslation_page_id_60216ef5_fk_page_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_pagetranslation
    ADD CONSTRAINT page_pagetranslation_page_id_60216ef5_fk_page_page_id FOREIGN KEY (page_id) REFERENCES public.page_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: payment_payment payment_payment_checkout_id_1f32e1ab_fk_checkout_checkout_token; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_payment
    ADD CONSTRAINT payment_payment_checkout_id_1f32e1ab_fk_checkout_checkout_token FOREIGN KEY (checkout_id) REFERENCES public.checkout_checkout(token) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: payment_payment payment_payment_order_id_22b45881_fk_order_order_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_payment
    ADD CONSTRAINT payment_payment_order_id_22b45881_fk_order_order_id FOREIGN KEY (order_id) REFERENCES public.order_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: payment_transaction payment_transaction_payment_id_df9808d7_fk_payment_payment_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_transaction
    ADD CONSTRAINT payment_transaction_payment_id_df9808d7_fk_payment_payment_id FOREIGN KEY (payment_id) REFERENCES public.payment_payment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: portal_carousellinks portal_carousellinks_carousel_id_85c22df1_fk_portal_carousel_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_carousellinks
    ADD CONSTRAINT portal_carousellinks_carousel_id_85c22df1_fk_portal_carousel_id FOREIGN KEY (carousel_id) REFERENCES public.portal_carousel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_attribute product_attribute_product_type_id_95b8020e_fk_product_p; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_attribute
    ADD CONSTRAINT product_attribute_product_type_id_95b8020e_fk_product_p FOREIGN KEY (product_type_id) REFERENCES public.product_producttype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_attribute product_attribute_product_variant_type_504d9ada_fk_product_p; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_attribute
    ADD CONSTRAINT product_attribute_product_variant_type_504d9ada_fk_product_p FOREIGN KEY (product_variant_type_id) REFERENCES public.product_producttype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_attributevalue product_attributecho_attribute_id_c28c6c92_fk_product_a; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_attributevalue
    ADD CONSTRAINT product_attributecho_attribute_id_c28c6c92_fk_product_a FOREIGN KEY (attribute_id) REFERENCES public.product_attribute(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_attributetranslation product_attributetra_attribute_id_238dabfc_fk_product_a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_attributetranslation
    ADD CONSTRAINT product_attributetra_attribute_id_238dabfc_fk_product_a FOREIGN KEY (attribute_id) REFERENCES public.product_attribute(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_attributevaluetranslation product_attributeval_attribute_value_id_8b2cb275_fk_product_a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_attributevaluetranslation
    ADD CONSTRAINT product_attributeval_attribute_value_id_8b2cb275_fk_product_a FOREIGN KEY (attribute_value_id) REFERENCES public.product_attributevalue(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_category product_category_parent_id_f6860923_fk_product_category_id; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_category
    ADD CONSTRAINT product_category_parent_id_f6860923_fk_product_category_id FOREIGN KEY (parent_id) REFERENCES public.product_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_categorytranslation product_categorytran_category_id_aa8d0917_fk_product_c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categorytranslation
    ADD CONSTRAINT product_categorytran_category_id_aa8d0917_fk_product_c FOREIGN KEY (category_id) REFERENCES public.product_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_collectionproduct product_collection_p_collection_id_0bc817dc_fk_product_c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_collectionproduct
    ADD CONSTRAINT product_collection_p_collection_id_0bc817dc_fk_product_c FOREIGN KEY (collection_id) REFERENCES public.product_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_collectionproduct product_collection_p_product_id_a45a5b06_fk_product_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_collectionproduct
    ADD CONSTRAINT product_collection_p_product_id_a45a5b06_fk_product_p FOREIGN KEY (product_id) REFERENCES public.product_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_collectiontranslation product_collectiontr_collection_id_cfbbd453_fk_product_c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_collectiontranslation
    ADD CONSTRAINT product_collectiontr_collection_id_cfbbd453_fk_product_c FOREIGN KEY (collection_id) REFERENCES public.product_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_digitalcontenturl product_digitalconte_content_id_654197bd_fk_product_d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_digitalcontenturl
    ADD CONSTRAINT product_digitalconte_content_id_654197bd_fk_product_d FOREIGN KEY (content_id) REFERENCES public.product_digitalcontent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_digitalcontenturl product_digitalconte_line_id_82056694_fk_order_ord; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_digitalcontenturl
    ADD CONSTRAINT product_digitalconte_line_id_82056694_fk_order_ord FOREIGN KEY (line_id) REFERENCES public.order_orderline(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_digitalcontent product_digitalconte_product_variant_id_211462a5_fk_product_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_digitalcontent
    ADD CONSTRAINT product_digitalconte_product_variant_id_211462a5_fk_product_p FOREIGN KEY (product_variant_id) REFERENCES public.product_productvariant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_product product_product_category_id_0c725779_fk_product_category_id; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_product
    ADD CONSTRAINT product_product_category_id_0c725779_fk_product_category_id FOREIGN KEY (category_id) REFERENCES public.product_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_product product_product_product_type_id_4bfbbfda_fk_product_p; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_product
    ADD CONSTRAINT product_product_product_type_id_4bfbbfda_fk_product_p FOREIGN KEY (product_type_id) REFERENCES public.product_producttype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_productimage product_productimage_product_id_544084bb_fk_product_product_id; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_productimage
    ADD CONSTRAINT product_productimage_product_id_544084bb_fk_product_product_id FOREIGN KEY (product_id) REFERENCES public.product_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_producttranslation product_producttrans_product_id_2c2c7532_fk_product_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_producttranslation
    ADD CONSTRAINT product_producttrans_product_id_2c2c7532_fk_product_p FOREIGN KEY (product_id) REFERENCES public.product_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_producttype product_producttype_user_id_62a5700c_fk_account_user_id; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_producttype
    ADD CONSTRAINT product_producttype_user_id_62a5700c_fk_account_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_productvariant product_productvaria_product_id_43c5a310_fk_product_p; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_productvariant
    ADD CONSTRAINT product_productvaria_product_id_43c5a310_fk_product_p FOREIGN KEY (product_id) REFERENCES public.product_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_productvarianttranslation product_productvaria_product_variant_id_1b144a85_fk_product_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_productvarianttranslation
    ADD CONSTRAINT product_productvaria_product_variant_id_1b144a85_fk_product_p FOREIGN KEY (product_variant_id) REFERENCES public.product_productvariant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_variantimage product_variantimage_image_id_bef14106_fk_product_p; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_variantimage
    ADD CONSTRAINT product_variantimage_image_id_bef14106_fk_product_p FOREIGN KEY (image_id) REFERENCES public.product_productimage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_variantimage product_variantimage_variant_id_81123814_fk_product_p; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.product_variantimage
    ADD CONSTRAINT product_variantimage_variant_id_81123814_fk_product_p FOREIGN KEY (variant_id) REFERENCES public.product_productvariant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shipping_shippingcities shipping_shippingcit_shipping_province_id_cae4ce8b_fk_shipping_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingcities
    ADD CONSTRAINT shipping_shippingcit_shipping_province_id_cae4ce8b_fk_shipping_ FOREIGN KEY (shipping_province_id) REFERENCES public.shipping_shippingprovince(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shipping_shippingmethodtranslation shipping_shippingmet_shipping_method_id_31d925d2_fk_shipping_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingmethodtranslation
    ADD CONSTRAINT shipping_shippingmet_shipping_method_id_31d925d2_fk_shipping_ FOREIGN KEY (shipping_method_id) REFERENCES public.shipping_shippingmethod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shipping_shippingmethod shipping_shippingmet_shipping_zone_id_265b7413_fk_shipping_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingmethod
    ADD CONSTRAINT shipping_shippingmet_shipping_zone_id_265b7413_fk_shipping_ FOREIGN KEY (shipping_zone_id) REFERENCES public.shipping_shippingzone(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shipping_shippingprovince shipping_shippingpro_shipping_zone_id_2c2f5906_fk_shipping_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shippingprovince
    ADD CONSTRAINT shipping_shippingpro_shipping_zone_id_2c2f5906_fk_shipping_ FOREIGN KEY (shipping_zone_id) REFERENCES public.shipping_shippingzone(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shipping_usershippingzone shipping_usershippin_shipping_zone_id_1cc4af82_fk_shipping_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_usershippingzone
    ADD CONSTRAINT shipping_usershippin_shipping_zone_id_1cc4af82_fk_shipping_ FOREIGN KEY (shipping_zone_id) REFERENCES public.shipping_shippingzone(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shipping_usershippingzone shipping_usershippingzone_user_id_d93e5699_fk_account_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_usershippingzone
    ADD CONSTRAINT shipping_usershippingzone_user_id_d93e5699_fk_account_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_authorizationkey site_authorizationke_site_settings_id_d8397c0f_fk_site_site; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.site_authorizationkey
    ADD CONSTRAINT site_authorizationke_site_settings_id_d8397c0f_fk_site_site FOREIGN KEY (site_settings_id) REFERENCES public.site_sitesettings(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_sitesettings site_sitesettings_bottom_menu_id_e2a78098_fk_menu_menu_id; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.site_sitesettings
    ADD CONSTRAINT site_sitesettings_bottom_menu_id_e2a78098_fk_menu_menu_id FOREIGN KEY (bottom_menu_id) REFERENCES public.menu_menu(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_sitesettings site_sitesettings_company_address_id_f0825427_fk_account_a; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.site_sitesettings
    ADD CONSTRAINT site_sitesettings_company_address_id_f0825427_fk_account_a FOREIGN KEY (company_address_id) REFERENCES public.account_address(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_sitesettings site_sitesettings_homepage_collection__82f45d33_fk_product_c; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.site_sitesettings
    ADD CONSTRAINT site_sitesettings_homepage_collection__82f45d33_fk_product_c FOREIGN KEY (homepage_collection_id) REFERENCES public.product_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_sitesettings site_sitesettings_site_id_64dd8ff8_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.site_sitesettings
    ADD CONSTRAINT site_sitesettings_site_id_64dd8ff8_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_sitesettings site_sitesettings_top_menu_id_ab6f8c46_fk_menu_menu_id; Type: FK CONSTRAINT; Schema: public; Owner: drupphuser1
--

ALTER TABLE ONLY public.site_sitesettings
    ADD CONSTRAINT site_sitesettings_top_menu_id_ab6f8c46_fk_menu_menu_id FOREIGN KEY (top_menu_id) REFERENCES public.menu_menu(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_sitesettingstranslation site_sitesettingstra_site_settings_id_ca085ff6_fk_site_site; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_sitesettingstranslation
    ADD CONSTRAINT site_sitesettingstra_site_settings_id_ca085ff6_fk_site_site FOREIGN KEY (site_settings_id) REFERENCES public.site_sitesettings(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: social_auth_usersocialauth social_auth_usersocialauth_user_id_17d28448_fk_account_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_auth_usersocialauth
    ADD CONSTRAINT social_auth_usersocialauth_user_id_17d28448_fk_account_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: storefront_businessdocument storefront_businessd_store_id_1c2acb77_fk_storefron; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_businessdocument
    ADD CONSTRAINT storefront_businessd_store_id_1c2acb77_fk_storefron FOREIGN KEY (store_id) REFERENCES public.storefront_store(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: storefront_store storefront_store_color_themes_id_4d637a45_fk_storefron; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_store
    ADD CONSTRAINT storefront_store_color_themes_id_4d637a45_fk_storefron FOREIGN KEY (color_themes_id) REFERENCES public.storefront_colorthemes(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: storefront_store storefront_store_owner_id_3ebd3879_fk_account_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_store
    ADD CONSTRAINT storefront_store_owner_id_3ebd3879_fk_account_user_id FOREIGN KEY (owner_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: storefront_store storefront_store_storeaddress_id_7d16fbaf_fk_account_address_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_store
    ADD CONSTRAINT storefront_store_storeaddress_id_7d16fbaf_fk_account_address_id FOREIGN KEY (storeaddress_id) REFERENCES public.account_address(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: storefront_temporaryimage storefront_temporary_store_id_1a80ba33_fk_storefron; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storefront_temporaryimage
    ADD CONSTRAINT storefront_temporary_store_id_1a80ba33_fk_storefron FOREIGN KEY (store_id) REFERENCES public.storefront_store(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user userprofile_user_default_billing_addr_0489abf1_fk_userprofi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user
    ADD CONSTRAINT userprofile_user_default_billing_addr_0489abf1_fk_userprofi FOREIGN KEY (default_billing_address_id) REFERENCES public.account_address(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user userprofile_user_default_shipping_add_aae7a203_fk_userprofi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user
    ADD CONSTRAINT userprofile_user_default_shipping_add_aae7a203_fk_userprofi FOREIGN KEY (default_shipping_address_id) REFERENCES public.account_address(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user_groups userprofile_user_groups_group_id_c7eec74e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_groups
    ADD CONSTRAINT userprofile_user_groups_group_id_c7eec74e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user_groups userprofile_user_groups_user_id_5e712a24_fk_userprofile_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_groups
    ADD CONSTRAINT userprofile_user_groups_user_id_5e712a24_fk_userprofile_user_id FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user_user_permissions userprofile_user_use_permission_id_1caa8a71_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_user_permissions
    ADD CONSTRAINT userprofile_user_use_permission_id_1caa8a71_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user_user_permissions userprofile_user_use_user_id_6d654469_fk_userprofi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_user_user_permissions
    ADD CONSTRAINT userprofile_user_use_user_id_6d654469_fk_userprofi FOREIGN KEY (user_id) REFERENCES public.account_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

